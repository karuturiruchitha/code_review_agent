# Code Review Agent

Automatic code review for Azure DevOps using **fixed rules**.
**No AI, no API key, no tokens, and no code leaves the build agent.** The same code always gives the same result.

It checks **97 rules** (66 of them security rules mapped to the **OWASP Top 10:2025** and to **CWE** numbers) across
Java / Spring Boot, React / JavaScript, MySQL scripts and stored procedures, configuration files, Docker, `pom.xml`,
`package.json`, and committed secrets in any file.

## Scenarios at a glance

| I want to... | Run | You get |
|---|---|---|
| Review every **pull request** | PR pipeline (`pipeline/rule-review.example.yml`) | One comment on the PR, updated on each push |
| Get line-level comments too | `inline_comments.enabled: true` in `.codereview.yml` | A comment on each serious line (opt-in) |
| Know how healthy the **existing** code is | `python agent/rule_review.py --repo-dir . --all-files` | HTML / JSON / SARIF / Markdown report with a score and grade |
| Run that every night | `pipeline/full-scan.example.yml` | Scheduled scan, reports published as artifacts |
| Stop old problems drowning the team | `--write-baseline`, then `baseline:` in `.codereview.yml` | Only **new** problems are reported afterwards |
| Tune it for one repository | `.codereview.yml` (template: `codereview.example.yml`) | Disabled rules, changed severities, excluded folders, thresholds |
| Check vulnerable libraries | Built-in list, `npm audit` and Dependency-Check reports | Findings under OWASP A03 |
| Block bad PRs | `RULE_FAIL_ON=critical` (later `high`) | The build fails at that severity or above |

Every scenario has an automated end-to-end test: see [`docs/scenarios.md`](docs/scenarios.md).

## Quick start

```bash
pip install -r requirements.txt
python -m pytest -q tests                                          # self-test, no network needed

# pull-request mode (compare with main) and print instead of posting
python agent/rule_review.py --repo-dir . --target-branch main --dry-run

# full scan of the whole repository
python agent/rule_review.py --repo-dir . --all-files --report-dir review_output
```
On a team repository, use the pipelines in [`pipeline/`](pipeline) (setup steps are in the files).

## Example comment

```
## ⚠️ Code review: 2 finding(s) (1 critical, 1 high) · advisory
**OWASP Top 10:2025:** A05:2025 Injection ×1, A07:2025 Authentication Failures ×1
### 🔴 CRITICAL · JAVA_HARDCODED_CREDENTIAL_CHECK: Password / CAPTCHA / OTP compared with a fixed value (backdoor)
`src/main/java/.../LoginService.java:42` · security · A07:2025 Authentication Failures · CWE-798
- Code: `if (captcha.equals("1234")) {`
- Why it matters: ...      - Fix: ...
```

## Per-repository settings: `.codereview.yml`

Put it in the root of the repository being reviewed (template: [`codereview.example.yml`](codereview.example.yml)). All keys are optional.

```yaml
fail_on: none                  # none | low | medium | high | critical   (command line / RULE_FAIL_ON wins)
disable: [JS_CONSOLE_LOG]      # rule ids: docs/rules.md
severity: { JAVA_PRINT_STACKTRACE: high }
exclude_paths: ["legacy/**"]
test_paths: ["qa/**"]          # extra test code: security findings there are reported as low
baseline: .codereview-baseline.json
dependencies: { npm_audit: npm-audit.json, dependency_check: dependency-check-report.json }
inline_comments: { enabled: true, min_severity: high, max: 15 }
```
A mistake in this file (unknown rule id, wrong severity, broken YAML) never breaks a review: it becomes a **warning shown in the PR comment**
and the defaults are used.

## Baseline: adopt it on an existing codebase

1. Run the **full-scan pipeline once** with `writeBaseline = true` (or `--all-files --write-baseline .codereview-baseline.json`).
2. Commit the generated file and add `baseline: .codereview-baseline.json` to `.codereview.yml`.
3. From now on only **new** findings are reported. A finding is identified by its rule, its file and its code text, **not its line number**,
   so editing code above it does not bring it back. Identical lines are counted one by one.

## Dependencies (OWASP A03)

| Source | What it covers | Notes |
|---|---|---|
| Built-in list (`pom.xml`) | log4j-core (Log4Shell and follow-ups), Spring Framework / Spring Boot (Spring4Shell), commons-text (Text4Shell), SnakeYAML, commons-collections | Version boundaries come from public advisories. `${property}` versions are resolved; a version that cannot be resolved is skipped |
| `npm audit --json` | Everything npm knows about | Live advisory data comes from npm; the agent only reads the report |
| OWASP Dependency-Check JSON report | Everything Dependency-Check knows about | Live NVD data comes from the tool; the agent only reads the report |

In a **pull request**, built-in findings appear only for dependencies whose lines the PR changed, and a tool report appears only when the PR
changes the matching `package.json` / `pom.xml`, so an unrelated PR is not flooded with old findings. A full scan always reports everything.

## Outputs (written to `OUTPUT_DIR` or `--report-dir`)

| File | Use |
|---|---|
| `rule_review_report.md` | The PR comment (PR mode) or the full-scan summary |
| `rule_review_report.html` | Self-contained report: severity filters, findings by file, OWASP table, score |
| `rule_review_report.json` | Machine-readable findings and summary |
| `rule_review.sarif` | SARIF 2.1.0 for security dashboards |

Reports contain no timestamps: the same code gives byte-identical reports. Secret values are never printed.

## What it checks

Full catalogue with OWASP and CWE: [`docs/rules.md`](docs/rules.md).

| Area | Examples |
|---|---|
| Java / Spring Boot | SQL built by concatenation (also across many lines), SQL passed to `execute(variable)`, endpoints without authorization, IDOR, hard-coded login/CAPTCHA values, NoOp password encoder, JWT without expiry / unsigned, weak ciphers and hashes, hard-coded keys, XXE, deserialization, exception text returned to users, empty catch, N+1 database calls, money in `double`, shared `SimpleDateFormat` |
| React / JavaScript | `dangerouslySetInnerHTML`, `eval`, SQL in templates, tokens in `localStorage`, `useEffect` request races / missing dependency array / timers without cleanup, async functions with no error handling, `postMessage` without origin check, `.only` tests |
| MySQL | `UPDATE`/`DELETE` without `WHERE` (also when someone **deletes** the `WHERE` line), procedures with no error handler, DML inside loops, dynamic `CONCAT` SQL, division without `NULLIF`, money in `FLOAT`, `NOT IN (SELECT ...)`, `ORDER BY RAND()`, leading-wildcard `LIKE`, `DROP`/`TRUNCATE`, `GRANT ALL` |
| Configuration | Passwords and secrets in `.properties` / `.yml` / `.env` / compose / Kubernetes files (values never printed), `ddl-auto` that can wipe the schema, JDBC `useSSL=false`, actuator exposed, stack traces to users, H2 console, debug logging, TLS disabled |
| Docker / build | Container as root, unpinned images, download-and-run scripts, http Maven repositories, unpinned npm versions |
| Any file | Committed keys and tokens (AWS, GitHub, Slack, Google, Stripe, SendGrid, Azure, private keys, JWTs, passwords) |

False alarm? Add `// review-ignore: RULE_ID reason` (or `-- ` / `# ` / `<!-- -->`) on the line or the line above.
Test code: security findings in test files are shown as **low**, never hidden. Generated, vendored and lock files are skipped.

## Add a rule

Edit [`rules/rules.yml`](rules/rules.yml). Every rule must include example lines that **must** match (`bad`) and **must not** match (`good`);
the tests check them. Security rules also need an OWASP category and a CWE number. Then run `python tools/generate_rules_doc.py` and the tests.

## Validation

- **246 automated tests** on Python 3.11 and 3.12, using real git repositories. 28 are end-to-end scenario tests (`tests/test_scenarios.py`).
- **Deliberate-breakage checks:** key pieces of the logic (settings precedence, baseline fingerprints, score cap, dependency scoping, inline-comment filters, HTML escaping, binary-file skipping and more) were broken one at a time; each breakage made a test fail.
- **Real code:** full scans of OWASP WebGoat (750 files in 7 s), Spring Boot RealWorld and PetClinic with React RealWorld. A baseline round trip on WebGoat accepted 527 findings, a rescan reported 0, and after code moved and one vulnerable file was added it reported exactly that one new finding.
- **Real tool output:** the `npm audit` reader is tested with genuine `npm audit --json` output (`tests/fixtures/npm-audit-v2.json`).
- **Independent implementation:** the rules were also written in JavaScript; on more than 1,000 real files both implementations produced identical findings.
- **Azure DevOps integration:** reading the PR and posting or updating comments (including inline comments) is exercised with a simulated service in the tests.

Design, scenarios and the rule catalogue: [`docs/architecture.md`](docs/architecture.md), [`docs/scenarios.md`](docs/scenarios.md), [`docs/rules.md`](docs/rules.md).

## Layout

```
agent/      rule_review.py (entry point) · rules_engine.py · scan.py · settings.py · baseline.py · scoring.py
            dependencies.py · reports.py · secret_scan.py · diff_utils.py · azure_devops.py · config.py
rules/      rules.yml: the line rules (with mandatory examples)
pipeline/   rule-review.example.yml (PR) · full-scan.example.yml (nightly + baseline) · azure-pipeline.yml (this repo's tests)
docs/       architecture.md · scenarios.md · rules.md (generated)
tools/      generate_rules_doc.py
tests/      246 tests (+ fixtures)
codereview.example.yml   template for .codereview.yml
```
