# Code Review Agent: Architecture

## 1. Purpose

The Code Review Agent is an automated reviewer that runs inside Azure DevOps pipelines. When a pull request is created or updated, the agent checks the changed code against a set of fixed rules and posts **one** review comment with the findings. It can also scan a whole repository on demand or on a schedule.

It was designed around the PPM stack (Java / Spring Boot, React, MySQL, Docker, Azure DevOps). The rules are general, so it applies to any project that uses the same technologies.

| Property | Description |
|---|---|
| Rule based | 97 fixed rules (66 security rules) mapped to the OWASP Top 10:2025 and to CWE numbers |
| No AI, no tokens | Analysis is plain text and pattern matching; no model and no external service is called |
| Deterministic | The same code always gives the same findings, reports and score |
| Private | Code is read on the pipeline agent only; the only outside call is to Azure DevOps to read the PR and post comments |
| Safe by default | Advisory (comments only) unless a threshold is configured; an internal error never blocks a merge |
| Fast | About 0.25 s for a typical pull request; 7 s for a 750-file, 94,000-line repository |

## 2. Where it fits

```
 Developer opens or updates a pull request
                    |
                    v
 Branch policy (Build validation) starts the review pipeline
                    |
                    v
 Pipeline checks out two repositories:  the team repository  +  the code-review-agent repository
                    |
                    v
 python agent/rule_review.py  -->  reads the diff, applies the rules, writes the results
                    |
        +-----------+---------------------------+
        v                                       v
 ONE comment on the PR                  Reports published as pipeline artifacts
 (updated on every push;                (HTML, JSON, SARIF, Markdown)
  optional line-level comments)
```

Integration requirements:
- The agent repository (`code-review-agent`) in the same Azure DevOps project.
- The review pipeline in the team repository (`pipeline/rule-review.example.yml`), checking out the team repository with `fetchDepth: 0` so the target branch history is available.
- A branch policy (Build validation) on the target branch, since Azure Repos Git runs PR builds through branch policies.
- The project's Build Service identity with the **Contribute to pull requests** permission, so it can post comments.

## 3. Run modes

| Mode | Command | Reviews | Output |
|---|---|---|---|
| Pull request review (default) | `python agent/rule_review.py --repo-dir <repo>` | Only the lines the pull request changed | One PR comment plus reports |
| Full repository scan | `python agent/rule_review.py --repo-dir <repo> --all-files` | Every tracked file | Reports with a score and grade |

A full scan can also record a **baseline** (`--write-baseline`) so that later reviews report only new findings.

## 4. Processing flow

```
 pull-request mode                                         full-scan mode (--all-files)
 skip if: draft PR, commit already reviewed,               every tracked file; binary, oversized,
 kill switch.  git diff target...HEAD                      generated and lock files are skipped
 -> added lines + positions of pure deletions              -> every line counts as "changed"
                         \                                  /
                          v                                v
 .codereview.yml (settings)  --->  for each file:
                                     line rules (rules/rules.yml)
                                     multi-line checks (rules_engine.py)
                                     secret scan (any text file, values redacted)
                                     built-in dependency list for pom.xml (PR: changed dependencies only)
                                   reports from "npm audit --json" and OWASP Dependency-Check (PR: when the manifest changed)
                                                   |
                                                   v
 finalize: exclude_paths, disabled rules, test-code findings -> low, severity overrides, de-duplication
                                                   |
                                                   v
 baseline (optional): remove accepted findings by fingerprint (rule + file + code text)
                                                   |
                                                   v
 stale-run check -> post or update ONE PR comment (+ inline comments, optional)   |   print + reports
                                                   |
                                                   v
 HTML, JSON, SARIF, Markdown  ->  exit 0 (advisory)  or  exit 1 if fail_on is set and a finding is at or above it
 Any internal error -> warning and exit 0, so the agent never blocks a merge because of its own failure
```

## 5. Components

| File | Responsibility |
|---|---|
| `agent/rule_review.py` | Entry point and flow: modes, settings, analysis, dependency step, baseline, posting, reports, exit code |
| `agent/scan.py` | Chooses the lines to review: the PR diff (added lines plus pure deletions) or the whole repository |
| `agent/rules_engine.py` | Loads the line rules and implements the multi-line checks (SQL concatenation chains, `execute(variable)`, endpoint authorization, IDOR, JWT expiry, XXE, empty catch, N+1 database calls, React effects, SQL statements and procedures, Docker `USER`) |
| `agent/secret_scan.py` | Secret detection and redaction |
| `agent/dependencies.py` | Built-in list for `pom.xml` (with `${property}` resolution) and parsers for `npm audit --json` and Dependency-Check JSON |
| `agent/settings.py` | `.codereview.yml`: validation, precedence, warnings instead of failures |
| `agent/baseline.py` | Fingerprints; writing and applying a baseline |
| `agent/scoring.py` | Deterministic score with a per-rule penalty cap |
| `agent/reports.py` | PR comment, full-scan summary, HTML, SARIF 2.1.0, JSON |
| `agent/azure_devops.py` | Reads the PR; finds and updates the agent's own comment (identified by a hidden marker); inline comments |
| `agent/diff_utils.py` | `git diff` and parsing into added lines and deletion positions |
| `rules/rules.yml` | Line rules with OWASP and CWE mapping and mandatory examples |

## 6. The rule engine

| Rule type | How it works | Examples |
|---|---|---|
| Line rules (72) | A pattern applied to each changed line, after comments and trailing comments are removed | Weak hashes, `eval`, `console.log`, passwords in config files |
| Multi-line checks (21) | Read a whole statement, method, block or file | A query built over several lines; a web endpoint judged from its annotations and body; an `UPDATE` inside a stored procedure; a React effect with its dependency list |
| Secret scan | Patterns for keys, tokens and passwords in **any** text file | AWS, GitHub, Slack, Google, Stripe, SendGrid and Azure keys; private keys; JWTs |
| Dependency checks (3) | Built-in list, `npm audit` report, Dependency-Check report | Log4Shell, Spring4Shell, Text4Shell |

Every line rule carries example lines that must match and example lines that must not match. The automated tests execute those examples, so a rule is always accompanied by evidence of its behaviour. Security rules also carry an OWASP category and a CWE number.

Conditions applied to every finding, in order: skipped files, known file type, changed line, comment lines, pattern match, test code (security findings shown as low), `review-ignore` comments, repository settings, baseline, dependency scope, and the `fail_on` threshold.

## 7. Configuration

Per-repository settings live in `.codereview.yml` at the root of the reviewed repository (template: `codereview.example.yml`). All keys are optional.

| Key | Purpose |
|---|---|
| `fail_on` | `none` (default), `low`, `medium`, `high` or `critical`: fail the run at that severity or above |
| `disable` | Rule ids to turn off for this repository |
| `severity` | Change the severity of a rule for this repository |
| `exclude_paths` | Folders or files to skip |
| `test_paths` | Additional paths treated as test code |
| `baseline` | Path of the baseline file |
| `dependencies` | Paths of the `npm audit` and Dependency-Check reports, and their manifests |
| `inline_comments` | Line-level comments: `enabled`, `min_severity`, `max` |

Precedence: command line and environment variables, then the settings file, then defaults. A mistake in the settings file (unknown rule id, invalid severity, unreadable YAML) produces a warning in the PR comment and the defaults are used.

Environment variables: `RULE_FAIL_ON`, `RULES_DISABLE`, `INLINE_COMMENTS`, `NPM_AUDIT_REPORT`, `DEPENDENCY_CHECK_REPORT`, `OUTPUT_DIR`, `RULE_REVIEW_ENABLED` (kill switch).

## 8. Baseline

A baseline records the findings that already exist so that reviews report only new ones. A finding is identified by its **rule, file and code text, not its line number**, so editing code above a finding does not bring it back. Identical lines in a file are counted one by one.

## 9. Dependency analysis (OWASP A03)

| Source | Coverage |
|---|---|
| Built-in list (`pom.xml`) | `log4j-core`, Spring Framework and Spring Boot, `commons-text`, SnakeYAML and `commons-collections`. Version boundaries come from public advisories. Versions defined as `${properties}` are resolved |
| `npm audit --json` | Everything npm reports; the agent reads the report |
| OWASP Dependency-Check JSON report | Everything Dependency-Check reports; the agent reads the report |

In a pull request, built-in findings are shown for dependencies whose lines changed, and a tool report is shown when the matching manifest changed. A full scan reports everything.

## 10. Outputs

| File | Content |
|---|---|
| `rule_review_report.md` | The PR comment, or the full-scan summary |
| `rule_review_report.html` | Self-contained report with severity filters, findings by file, OWASP table and score |
| `rule_review_report.json` | Machine-readable findings and summary |
| `rule_review.sarif` | SARIF 2.1.0 for security dashboards |

Reports contain no timestamps, so identical findings produce identical files. Secret values never appear in any output.

## 11. Design principles

- **Deletions count.** Removing a `WHERE` clause is detected because the line before a pure deletion counts as changed. A replaced line does not mark its neighbours.
- **Fingerprints ignore line numbers**, so a baseline remains valid when code moves.
- **Nothing is guessed.** A dependency version that cannot be resolved is skipped; an unreadable settings or baseline file becomes a warning.
- **Scoped dependency findings.** In a pull request, existing dependency findings appear only when the PR touches that dependency or manifest.
- **Read-only.** The agent never edits code or the repository; it reads files, calls the Azure DevOps comment API and writes reports.
- **Fail safe.** Draft PRs, an already reviewed commit and a superseded run are skipped, and any internal error exits with success.

## 12. Coverage

| OWASP Top 10:2025 | Rules | Examples |
|---|---|---|
| A01 Broken Access Control | 9 | Missing authorization on write endpoints, IDOR, CSRF disabled, path traversal, open redirect, SSRF, `GRANT ALL` |
| A02 Security Misconfiguration | 15 | CORS, cookies, actuator, H2 console, stack traces to users, `ddl-auto`, XXE, container as root |
| A03 Software Supply Chain Failures | 6 | Vulnerable libraries, unpinned images and npm versions, http Maven repositories |
| A04 Cryptographic Failures | 10 | Weak ciphers and hashes, hard-coded keys, TLS checks off, JDBC without SSL |
| A05 Injection | 12 | SQL concatenation (also across lines), `execute(variable)`, XSS, `eval`, command execution |
| A06 Insecure Design | - | Covered by design review |
| A07 Authentication Failures | 8 | Hard-coded credential checks, plain-text passwords, JWT without expiry, secrets in configuration |
| A08 Software or Data Integrity Failures | 4 | Deserialization, download-and-run scripts |
| A09 Logging & Alerting Failures | 2 | Secrets in logs, `printStackTrace` |
| A10 Mishandling of Exceptional Conditions | 9 | Empty catch, exception text sent to users, procedures without error handlers, division by zero |

The full catalogue with CWE numbers is in `rules.md`. Beyond security, the agent also checks data-correctness patterns (`UPDATE` / `DELETE` without `WHERE`, money in `double` or `FLOAT`), performance patterns (N+1 database calls, row-by-row SQL in loops) and React effect handling.

## 13. Performance

| Run | Time |
|---|---|
| Small pull request, whole command line (Python 3.11) | about 0.25 s |
| Full scan of OWASP WebGoat (750 files, about 94,000 lines) | 7.1 s |
| Full scan of two ~120-file sample applications | about 1.1 s each |

In a pipeline most of the time is checkout and installing the three Python libraries.

## 14. Validation

- 246 automated tests on Python 3.11 and 3.12 using real git repositories, including 28 end-to-end scenario tests (`scenarios.md`).
- The new logic was exercised with deliberate breakages; each one made a test fail.
- Full scans of OWASP WebGoat, Spring Boot RealWorld and PetClinic with React RealWorld. On WebGoat a baseline accepted 527 findings, a rescan reported 0, and after code moved and one new vulnerable file was added it reported exactly that one new finding.
- The `npm audit` reader is tested with genuine `npm audit --json` output.
- The rules were also implemented independently in JavaScript; on more than 1,000 real files both implementations produced identical findings.
- Azure DevOps calls (reading the PR, posting and updating comments, inline comments) are exercised with a simulated service in the automated tests.

## 15. Rollout approach

| Phase | Activity |
|---|---|
| 1. Baseline | Run the full scan once, review the report, and record a baseline for existing code |
| 2. Pilot | Enable the PR review as an optional policy on one repository; the team marks findings as real or false alarms and tunes `.codereview.yml` |
| 3. Team-wide | Enable on all repositories in advisory mode; optionally add inline comments for high findings |
| 4. Nightly scan | Schedule `full-scan.example.yml` and follow the score |
| 5. Thresholds | Set `fail_on: critical`, then `high` when the false-alarm rate is low |

A kill switch (`RULE_REVIEW_ENABLED=false`) stops the agent at any time.

## 16. Extending the agent

- **New line rule:** add it to `rules/rules.yml` with example lines (must match / must not match) and, for security rules, an OWASP category and a CWE number.
- **New multi-line check:** implement it in `agent/rules_engine.py` and register it with its metadata.
- Run `python tools/generate_rules_doc.py` to refresh `rules.md`, then the tests.
