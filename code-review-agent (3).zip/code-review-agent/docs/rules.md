# Code Review Agent: Rule Catalogue

The agent applies **97 fixed rules** (66 of them security rules). Security rules are mapped to the **OWASP Top 10:2025** and to **CWE** numbers. The same code always gives the same result: no AI and no tokens are used.

Generated from the rule definitions by `tools/generate_rules_doc.py`, so it always matches the code.

## Severity levels

| Severity | Meaning | Typical handling |
|---|---|---|
| critical | Can be exploited directly, or a secret is exposed | Fix before merge; rotate any exposed secret |
| high | A serious weakness | Fix before merge |
| medium | Likely a real problem, depends on context | Fix, or document why it is acceptable |
| low | Maintainability or lower risk | Optional |

## Rule types

| Type | Description |
|---|---|
| line | Evaluated on one changed line at a time |
| multi-line | Reads a whole statement, method or file (for example a query built over several lines, or a web endpoint with its annotations) |
| secret scan | Looks for keys, tokens and passwords in any text file; values are always hidden in output |
| dependency | Known-vulnerable libraries from the built-in list and from `npm audit` / Dependency-Check reports |

## Coverage by OWASP Top 10:2025

| Category | Automated rules | Rules | Also handled in human review |
|---|---|---|---|
| **A01:2025 Broken Access Control** | 9 | `JAVA_CSRF_DISABLED`, `JAVA_ENDPOINT_NO_AUTHZ`, `JAVA_IDOR_RISK`, `JAVA_OPEN_REDIRECT`, `JAVA_PATH_TRAVERSAL`, `JAVA_PERMIT_ALL`, `JAVA_SSRF`, `JS_POSTMESSAGE_NO_ORIGIN`, `SQL_GRANT_ALL` | Ownership checks in the service layer, role design, and tenant or customer data separation. |
| **A02:2025 Security Misconfiguration** | 15 | `CONFIG_ACTUATOR_EXPOSE_ALL`, `CONFIG_ACTUATOR_EXPOSE_ALL_YAML`, `CONFIG_DDL_AUTO_PROPS`, `CONFIG_DDL_AUTO_YAML`, `CONFIG_DEBUG_LOGGING`, `CONFIG_ERROR_DETAILS_EXPOSED`, `CONFIG_H2_CONSOLE`, `CONFIG_HEALTH_DETAILS_PROPS`, `CONFIG_HEALTH_DETAILS_YAML`, `DOCKER_NO_USER`, `DOCKER_USER_ROOT`, `JAVA_COOKIE_INSECURE`, `JAVA_CROSS_ORIGIN_DEFAULT`, `JAVA_CROSS_ORIGIN_WILDCARD`, `JAVA_XXE` | Server and proxy hardening, TLS settings, security headers, and per-environment profiles. |
| **A03:2025 Software Supply Chain Failures** | 6 | `DEP_CHECK`, `DEP_NPM_AUDIT`, `DEP_VULNERABLE_LIBRARY`, `DOCKER_UNPINNED_IMAGE`, `JSON_UNPINNED_DEPENDENCY`, `XML_HTTP_REPOSITORY` | Library versions beyond the built-in list are covered by the npm audit and Dependency-Check reports the agent reads. |
| **A04:2025 Cryptographic Failures** | 10 | `ANY_INSECURE_URL`, `CONFIG_JDBC_SSL_OFF`, `CONFIG_SSL_DISABLED`, `JAVA_HARDCODED_KEY`, `JAVA_INSECURE_RANDOM`, `JAVA_TRUST_ALL_TLS`, `JAVA_WEAK_CIPHER`, `JAVA_WEAK_HASH`, `JS_INSECURE_RANDOM_TOKEN`, `PY_VERIFY_FALSE` | Key management and rotation, and the choice of which data to encrypt. |
| **A05:2025 Injection** | 12 | `JAVA_COMMAND_EXEC`, `JAVA_RAW_STATEMENT`, `JAVA_SPEL_INJECTION`, `JAVA_SQL_CONCAT`, `JAVA_SQL_FORMAT`, `JS_DANGEROUS_HTML`, `JS_EVAL`, `JS_SQL_TEMPLATE`, `PY_EVAL_EXEC`, `PY_SHELL`, `PY_SQL_FORMAT`, `SQL_DYNAMIC_CONCAT` | Data that travels through several methods before it reaches a query. |
| **A06:2025 Insecure Design** | - | Reviewed through design review | Design review: abuse cases, approval flows, rate limits and business rules. |
| **A07:2025 Authentication Failures** | 8 | `CONFIG_PLAINTEXT_SECRET`, `JAVA_HARDCODED_CREDENTIAL_CHECK`, `JAVA_JWT_NO_EXPIRY`, `JAVA_JWT_WEAK`, `JAVA_NOOP_PASSWORD_ENCODER`, `JAVA_PLAIN_PASSWORD_COMPARE`, `JS_TOKEN_IN_STORAGE`, `SECRET_SCAN` | Session timeout, multi-factor sign-in, account lock-out and SSO configuration. |
| **A08:2025 Software or Data Integrity Failures** | 4 | `CURL_PIPE_SHELL`, `JAVA_DESERIALIZATION`, `PY_PICKLE`, `PY_YAML_LOAD` | Signed builds and artifacts, and who can change the pipeline. |
| **A09:2025 Logging & Alerting Failures** | 2 | `JAVA_LOG_SECRET`, `JAVA_PRINT_STACKTRACE` | Which security events are logged and alerted on. |
| **A10:2025 Mishandling of Exceptional Conditions** | 9 | `EMPTY_CATCH`, `JAVA_EXCEPTION_DETAILS_TO_CLIENT`, `JAVA_GENERIC_CATCH`, `JS_ASYNC_NO_ERROR_HANDLING`, `PY_BARE_EXCEPT`, `PY_EMPTY_EXCEPT`, `REACT_EFFECT_NO_CLEANUP`, `SQL_DIVISION_NO_NULLIF`, `SQL_PROC_NO_HANDLER` | Transaction boundaries and handling of partial failures across services. |

## Full catalogue


### Java / Spring Boot

| Rule | Severity | Category | OWASP 2025 | CWE | What it detects | Type |
|---|---|---|---|---|---|---|
| `JAVA_HARDCODED_CREDENTIAL_CHECK` | critical | security | A07:2025 Authentication Failures | CWE-798 | Password / CAPTCHA / OTP compared with a fixed value (backdoor) | line |
| `JAVA_NOOP_PASSWORD_ENCODER` | critical | security | A07:2025 Authentication Failures | CWE-256 | Passwords stored or checked in plain text | line |
| `JAVA_DESERIALIZATION` | high | security | A08:2025 Software or Data Integrity Failures | CWE-502 | Unsafe Java deserialization | line |
| `JAVA_HARDCODED_KEY` | high | security | A04:2025 Cryptographic Failures | CWE-321 | Encryption key or IV written in the code | line |
| `JAVA_JWT_WEAK` | high | security | A07:2025 Authentication Failures | CWE-347 | JWT accepted unsigned, or signed with a key in the code | line |
| `JAVA_PLAIN_PASSWORD_COMPARE` | high | security | A07:2025 Authentication Failures | CWE-256 | Password compared with equals() instead of the encoder | line |
| `JAVA_SQL_CONCAT` | high | security | A05:2025 Injection | CWE-89 | SQL / JPQL built by string concatenation | multi-line |
| `JAVA_SQL_FORMAT` | high | security | A05:2025 Injection | CWE-89 | SQL built with String.format | line |
| `JAVA_TRUST_ALL_TLS` | high | security | A04:2025 Cryptographic Failures | CWE-295 | TLS certificate / hostname checks disabled | line |
| `JAVA_WEAK_CIPHER` | high | security | A04:2025 Cryptographic Failures | CWE-327 | Weak or unsafe encryption mode (DES, Blowfish, RC4, ECB) | line |
| `JAVA_WEAK_HASH` | high | security | A04:2025 Cryptographic Failures | CWE-328 | Weak hash algorithm (MD5 / SHA-1) | line |
| `JAVA_XXE` | high | security | A02:2025 Security Misconfiguration | CWE-611 | XML parser without protection against external entities (XXE) | multi-line |
| `ANY_INSECURE_URL` | medium | security | A04:2025 Cryptographic Failures | CWE-319 | Hard-coded http:// URL | line |
| `EMPTY_CATCH` | medium | bug | A10:2025 Mishandling of Exceptional Conditions | CWE-390 | Empty catch block swallows the error | multi-line |
| `JAVA_COMMAND_EXEC` | medium | security | A05:2025 Injection | CWE-78 | Operating-system command execution | line |
| `JAVA_COOKIE_INSECURE` | medium | security | A02:2025 Security Misconfiguration | CWE-614 | Cookie without Secure / HttpOnly | line |
| `JAVA_CROSS_ORIGIN_DEFAULT` | medium | security | A02:2025 Security Misconfiguration | CWE-942 | CrossOrigin annotation with no origins (allows all) | line |
| `JAVA_CROSS_ORIGIN_WILDCARD` | medium | security | A02:2025 Security Misconfiguration | CWE-942 | CORS open to every origin | line |
| `JAVA_CSRF_DISABLED` | medium | security | A01:2025 Broken Access Control | CWE-352 | CSRF protection disabled | line |
| `JAVA_DB_CALL_IN_LOOP` | medium | performance | - | - | Database or remote call inside a loop (N+1) | multi-line |
| `JAVA_ENDPOINT_NO_AUTHZ` | medium | security | A01:2025 Broken Access Control | CWE-862 | Data-changing endpoint without an authorization check | multi-line |
| `JAVA_EXCEPTION_DETAILS_TO_CLIENT` | medium | security | A10:2025 Mishandling of Exceptional Conditions | CWE-209 | Exception message returned to the caller | line |
| `JAVA_FLOAT_MONEY` | medium | bug | - | - | Money held in double / float | line |
| `JAVA_IDOR_RISK` | medium | security | A01:2025 Broken Access Control | CWE-639 | Record fetched by id with no ownership check (IDOR) | multi-line |
| `JAVA_JWT_NO_EXPIRY` | medium | security | A07:2025 Authentication Failures | CWE-613 | JWT created without an expiry | multi-line |
| `JAVA_LOG_SECRET` | medium | security | A09:2025 Logging & Alerting Failures | CWE-532 | Possible secret written to the log | line |
| `JAVA_OPEN_REDIRECT` | medium | security | A01:2025 Broken Access Control | CWE-601 | Redirect to an address taken from a variable | line |
| `JAVA_PATH_TRAVERSAL` | medium | security | A01:2025 Broken Access Control | CWE-22 | File path built from a variable (path traversal) | line |
| `JAVA_PRINT_STACKTRACE` | medium | debt | A09:2025 Logging & Alerting Failures | CWE-778 | printStackTrace() instead of logging | line |
| `JAVA_RAW_STATEMENT` | medium | security | A05:2025 Injection | CWE-89 | SQL text passed to execute() as a variable (no placeholders) | multi-line |
| `JAVA_SPEL_INJECTION` | medium | security | A05:2025 Injection | CWE-917 | Spring expression parsed from a variable | line |
| `ANY_COMMENTED_OUT_CODE` | low | debt | - | - | Commented-out code | line |
| `ANY_TODO` | low | debt | - | - | TODO / FIXME / HACK added | line |
| `JAVA_GENERIC_CATCH` | low | debt | A10:2025 Mishandling of Exceptional Conditions | CWE-396 | Catching Exception / Throwable | line |
| `JAVA_INSECURE_RANDOM` | low | security | A04:2025 Cryptographic Failures | CWE-330 | Non-cryptographic random number generator | line |
| `JAVA_LONG_METHOD` | low | debt | - | - | Method longer than 80 lines | multi-line |
| `JAVA_PERMIT_ALL` | low | security | A01:2025 Broken Access Control | CWE-284 | Endpoint opened to everyone (permitAll) | line |
| `JAVA_SIMPLEDATEFORMAT_STATIC` | low | bug | - | CWE-362 | Shared static SimpleDateFormat (not thread-safe) | line |
| `JAVA_SSRF` | low | security | A01:2025 Broken Access Control | CWE-918 | Outgoing request to an address held in a variable | line |
| `JAVA_SYSTEM_OUT` | low | debt | - | - | System.out / System.err in application code | line |

### React / JavaScript

| Rule | Severity | Category | OWASP 2025 | CWE | What it detects | Type |
|---|---|---|---|---|---|---|
| `JS_DANGEROUS_HTML` | high | security | A05:2025 Injection | CWE-79 | Raw HTML injected into the page | line |
| `JS_EVAL` | high | security | A05:2025 Injection | CWE-95 | eval() / new Function() | line |
| `JS_SQL_TEMPLATE` | high | security | A05:2025 Injection | CWE-89 | SQL built with a template string | line |
| `JS_TEST_ONLY` | high | bug | - | - | Focused test (.only) committed | line |
| `REACT_EFFECT_NO_DEPS` | high | bug | - | - | useEffect with a request and no dependency array | multi-line |
| `JS_DEBUGGER` | medium | debt | - | - | debugger statement | line |
| `JS_INSECURE_RANDOM_TOKEN` | medium | security | A04:2025 Cryptographic Failures | CWE-338 | Math.random() used for a token, OTP or secret | line |
| `JS_POSTMESSAGE_NO_ORIGIN` | medium | security | A01:2025 Broken Access Control | CWE-346 | postMessage handler does not check event.origin | multi-line |
| `JS_TOKEN_IN_STORAGE` | medium | security | A07:2025 Authentication Failures | CWE-922 | Token or password stored in browser storage | line |
| `REACT_EFFECT_NO_CLEANUP` | medium | bug | A10:2025 Mishandling of Exceptional Conditions | CWE-772 | useEffect starts a timer, listener or subscription without cleanup | multi-line |
| `REACT_EFFECT_RACE` | medium | bug | - | - | Request in useEffect without cleanup (stale responses) | multi-line |
| `JS_ASYNC_NO_ERROR_HANDLING` | low | bug | A10:2025 Mishandling of Exceptional Conditions | CWE-248 | async function awaits with no try/catch or .catch() | multi-line |
| `JS_CONSOLE_LOG` | low | debt | - | - | console.log left in code | line |

### MySQL scripts and procedures

| Rule | Severity | Category | OWASP 2025 | CWE | What it detects | Type |
|---|---|---|---|---|---|---|
| `SQL_DELETE_NO_WHERE` | high | bug | - | - | DELETE without WHERE | multi-line |
| `SQL_GRANT_ALL` | high | security | A01:2025 Broken Access Control | CWE-269 | GRANT ALL privileges | line |
| `SQL_UPDATE_NO_WHERE` | high | bug | - | - | UPDATE without WHERE | multi-line |
| `SQL_DIVISION_NO_NULLIF` | medium | bug | A10:2025 Mishandling of Exceptional Conditions | CWE-369 | Division by a column or expression without NULLIF | line |
| `SQL_DROP_TRUNCATE` | medium | bug | - | - | Destructive DROP / TRUNCATE | multi-line |
| `SQL_DYNAMIC_CONCAT` | medium | security | A05:2025 Injection | CWE-89 | Dynamic SQL built with CONCAT inside a procedure | line |
| `SQL_FLOAT_MONEY` | medium | bug | - | - | Money column declared FLOAT / DOUBLE | line |
| `SQL_NOT_IN_SUBQUERY` | medium | bug | - | CWE-476 | NOT IN (SELECT ...) returns nothing if the subquery has a NULL | line |
| `SQL_PROC_NO_HANDLER` | medium | bug | A10:2025 Mishandling of Exceptional Conditions | CWE-755 | Stored procedure changes data but has no error handler | multi-line |
| `SQL_DML_IN_LOOP` | low | performance | - | - | INSERT/UPDATE/DELETE inside a loop in a procedure | multi-line |
| `SQL_LEADING_WILDCARD` | low | performance | - | - | LIKE with a leading wildcard ('%text') | line |
| `SQL_ORDER_BY_RAND` | low | performance | - | - | ORDER BY RAND() | line |
| `SQL_SELECT_STAR` | low | debt | - | - | SELECT * in a script, view or procedure | line |

### Configuration files

| Rule | Severity | Category | OWASP 2025 | CWE | What it detects | Type |
|---|---|---|---|---|---|---|
| `CONFIG_ACTUATOR_EXPOSE_ALL` | high | security | A02:2025 Security Misconfiguration | CWE-200 | All Spring Boot actuator endpoints exposed | line |
| `CONFIG_H2_CONSOLE` | high | security | A02:2025 Security Misconfiguration | CWE-489 | H2 database console enabled | line |
| `CONFIG_PLAINTEXT_SECRET` | high | security | A07:2025 Authentication Failures | CWE-798 | Plain-text password or secret in a configuration file | line |
| `CURL_PIPE_SHELL` | high | security | A08:2025 Software or Data Integrity Failures | CWE-494 | Script downloaded and executed in one step | line |
| `CONFIG_ACTUATOR_EXPOSE_ALL_YAML` | medium | security | A02:2025 Security Misconfiguration | CWE-200 | Wildcard include in YAML (check actuator exposure) | line |
| `CONFIG_DDL_AUTO_PROPS` | medium | security | A02:2025 Security Misconfiguration | CWE-16 | Hibernate ddl-auto can change or wipe the schema | line |
| `CONFIG_DDL_AUTO_YAML` | medium | security | A02:2025 Security Misconfiguration | CWE-16 | Hibernate ddl-auto can change or wipe the schema | line |
| `CONFIG_ERROR_DETAILS_EXPOSED` | medium | security | A02:2025 Security Misconfiguration | CWE-209 | Error responses include stack traces or exception details | line |
| `CONFIG_JDBC_SSL_OFF` | medium | security | A04:2025 Cryptographic Failures | CWE-319 | JDBC connection with SSL disabled or key retrieval allowed | line |
| `CONFIG_SSL_DISABLED` | medium | security | A04:2025 Cryptographic Failures | CWE-319 | TLS / HTTPS explicitly disabled | line |
| `CONFIG_DEBUG_LOGGING` | low | security | A02:2025 Security Misconfiguration | CWE-532 | Debug or SQL logging switched on in configuration | line |
| `CONFIG_HEALTH_DETAILS_PROPS` | low | security | A02:2025 Security Misconfiguration | CWE-200 | Actuator health shows full details to everyone | line |
| `CONFIG_HEALTH_DETAILS_YAML` | low | security | A02:2025 Security Misconfiguration | CWE-200 | Actuator health shows full details to everyone | line |

### Docker and build files

| Rule | Severity | Category | OWASP 2025 | CWE | What it detects | Type |
|---|---|---|---|---|---|---|
| `DOCKER_NO_USER` | medium | security | A02:2025 Security Misconfiguration | CWE-250 | Container runs as root (no USER instruction) | multi-line |
| `DOCKER_USER_ROOT` | medium | security | A02:2025 Security Misconfiguration | CWE-250 | Container explicitly runs as root | line |
| `JSON_UNPINNED_DEPENDENCY` | medium | security | A03:2025 Software Supply Chain Failures | CWE-1104 | npm dependency with no version limit | line |
| `XML_HTTP_REPOSITORY` | medium | security | A03:2025 Software Supply Chain Failures | CWE-494 | Maven repository over plain http | line |
| `DOCKER_UNPINNED_IMAGE` | low | security | A03:2025 Software Supply Chain Failures | CWE-829 | Base image without a fixed version (or latest) | line |

### Python

| Rule | Severity | Category | OWASP 2025 | CWE | What it detects | Type |
|---|---|---|---|---|---|---|
| `PY_EVAL_EXEC` | high | security | A05:2025 Injection | CWE-95 | eval() / exec() | line |
| `PY_PICKLE` | high | security | A08:2025 Software or Data Integrity Failures | CWE-502 | pickle deserialization | line |
| `PY_SHELL` | high | security | A05:2025 Injection | CWE-78 | Shell command execution | line |
| `PY_SQL_FORMAT` | high | security | A05:2025 Injection | CWE-89 | SQL built with string formatting | line |
| `PY_VERIFY_FALSE` | high | security | A04:2025 Cryptographic Failures | CWE-295 | TLS verification disabled | line |
| `PY_YAML_LOAD` | high | security | A08:2025 Software or Data Integrity Failures | CWE-502 | yaml.load without SafeLoader | line |
| `PY_BARE_EXCEPT` | medium | bug | A10:2025 Mishandling of Exceptional Conditions | CWE-396 | Bare except | line |
| `PY_EMPTY_EXCEPT` | medium | bug | A10:2025 Mishandling of Exceptional Conditions | CWE-390 | Broad except that only does 'pass' | multi-line |
| `PY_MUTABLE_DEFAULT` | medium | bug | - | - | Mutable default argument | line |

### pom.xml and reports

| Rule | Severity | Category | OWASP 2025 | CWE | What it detects | Type |
|---|---|---|---|---|---|---|
| `DEP_CHECK` | varies | security | A03:2025 Software Supply Chain Failures | CWE-1395 | Vulnerable dependency (read from an OWASP Dependency-Check JSON report) | dependency |
| `DEP_NPM_AUDIT` | varies | security | A03:2025 Software Supply Chain Failures | CWE-1395 | Vulnerable npm package (read from the output of 'npm audit --json') | dependency |
| `DEP_VULNERABLE_LIBRARY` | varies | security | A03:2025 Software Supply Chain Failures | CWE-1395 | Known-vulnerable library in pom.xml (built-in list of severe, verified cases) | dependency |

### Any file

| Rule | Severity | Category | OWASP 2025 | CWE | What it detects | Type |
|---|---|---|---|---|---|---|
| `SECRET_SCAN` | high | security | A07:2025 Authentication Failures | CWE-798 | Committed secret (keys, passwords, tokens, private keys) | secret scan |

## Suppressing, tuning and extending

- **One place:** add `review-ignore: RULE_ID reason` in a comment (`//`, `--`, `#` or `<!-- -->`) on the line or the line above.
- **A whole repository:** `.codereview.yml` can disable a rule, change its severity, or exclude folders.
- **Test code:** security findings in test files are reported as low, never hidden.
- **Adding a rule:** add it to `rules/rules.yml` with example lines that must match and example lines that must not; security rules also carry an OWASP category and a CWE number. The tests check the examples.
