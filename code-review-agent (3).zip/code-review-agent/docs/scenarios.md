# Code Review Agent: Scenarios

This document lists the end-to-end scenarios the agent supports. Each scenario is verified by an automated test in `tests/test_scenarios.py` that builds a real git repository and runs the real review flow.

## 1. Scenario catalogue

| # | Scenario | How it runs | Behaviour | Automated test |
|---|---|---|---|---|
| S1 | **Pull request across the whole stack** (Java controller and repository, React, MySQL script and procedure, properties, Dockerfile, `pom.xml`, `package.json`) | PR pipeline | 23 different problem types are detected in one review; committed passwords are never printed; HTML, JSON, SARIF and Markdown reports are written | `test_s1_pull_request_across_the_whole_stack` |
| S2 | **Clean pull request** | PR pipeline | "No rule violations"; exit code 0 even with `fail_on: low` | `test_s2_clean_pull_request` |
| S3 | **Dependency change in a pull request** | PR pipeline | Only the dependency whose lines changed is reported; `${property}` versions are resolved; an unresolvable property is skipped; an unrelated PR does not show existing dependency findings | `test_s3_*` |
| S4 | **npm audit report** | `npm audit --json`, then the PR pipeline | Findings (severity, CWE, fix) appear when the PR touches `package.json`; a missing or unreadable report produces a warning, never a failure | `test_s4_*` |
| S5 | **OWASP Dependency-Check report** | Dependency-Check, then the PR pipeline | One finding per vulnerable library with CVE ids, CVSS score and CWE; libraries without findings are not listed | `test_s5_dependency_check_report` |
| S6 | **Full repository scan** | `--all-files` or `full-scan.example.yml` | Reviews every file, including old code; produces a score and grade; skips binary, generated and lock files | `test_s6_*` |
| S7 | **Score stability** | Full scan | The penalty of any single rule is capped, so one high-volume low-severity rule cannot determine the grade | `test_s7_score_is_capped_per_rule` |
| S8 | **Baseline** | `--write-baseline`, then the `baseline` setting | Existing findings are accepted; moving code does not bring them back; only new findings are reported; identical lines are counted individually; a missing baseline file shows all findings with a warning | `test_s8_*` |
| S9 | **Per-repository settings** | `.codereview.yml` | Disabled rules, severity changes, excluded folders, extra test paths and `fail_on` take effect; the command line overrides the file; mistakes become warnings; dependency rules can be disabled as well | `test_s9_*` |
| S10 | **Azure DevOps comment flow and inline comments** | PR pipeline, `inline_comments.enabled` | One comment updated on each push; inline comments only for findings at or above the minimum severity, on changed lines, limited by `max`, and never duplicated; draft PRs, an already reviewed commit and a superseded run are skipped; a failing Azure DevOps call never blocks the build | `test_s10_*` |
| S11 | **Reports** | Any run | The HTML report escapes code; the SARIF file has the structure SARIF consumers require; identical findings produce identical reports | `test_s11_*` |
| S12 | **Command line** | From any folder | Works from any working directory; the exit code follows `--fail-on`; reports are written to `--report-dir` | `test_s12_command_line_from_another_folder` |
| S13 | **Safety controls** | Kill switch, thresholds | `RULE_REVIEW_ENABLED=false` stops the agent; `fail_on` blocks only when configured; an internal problem (missing rules file, not a repository) exits with success | `test_s13_kill_switch_threshold_and_fail_open` |

## 2. Example results

These results come from running the agent on small repositories.

| Situation | Result |
|---|---|
| A query is built with `"SELECT ... WHERE customer = '" + customer` | **high** `JAVA_SQL_CONCAT` at the line; with a `?` placeholder there are no findings |
| The `WHERE` line of an `UPDATE` is deleted | **high** `SQL_UPDATE_NO_WHERE`, although no line was added |
| A pull request changes only the README, while an old file contains an SQL problem | No findings in the PR review; the full scan reports the old problem |
| `log4j-core` is changed to 2.14.0 in `pom.xml` | **critical** `DEP_VULNERABLE_LIBRARY` (Log4Shell); the same old version in an unrelated PR is not repeated |
| A `@PostMapping` endpoint has no permission check | **medium** `JAVA_ENDPOINT_NO_AUTHZ`; a `review-ignore` comment with a reason removes it |
| The same SQL problem appears in test code | **low** `JAVA_SQL_CONCAT` (security findings in test files are reported as low) |
| A password is added to `application.properties` | **high** `CONFIG_PLAINTEXT_SECRET`, shown as `<REDACTED>` |
| An AWS key is committed, with `fail_on` set to `critical` | **critical** `SECRET_SCAN`; the run exits with code 1 (without `fail_on` it exits with 0) |
| A Java loop calls the repository for each id, and a React effect fetches without cleanup | **medium** `JAVA_DB_CALL_IN_LOOP` and **medium** `REACT_EFFECT_RACE` in one comment |
| A commented-out SQL line and a TODO comment | Two **low** findings (`ANY_COMMENTED_OUT_CODE`, `ANY_TODO`); comments are not evaluated by the other rules |
| A settings file with a mistyped rule id and an invalid severity | Warnings in the PR comment; the review runs with defaults |
| The rules file cannot be loaded | A warning is printed and the run exits with 0 |
| After a baseline is recorded, code is inserted above an old finding and one new problem is added | Only the new problem is reported; the old finding stays accepted |

## 3. How a pull request is processed

1. A developer creates or updates a pull request.
2. The branch policy starts the review pipeline.
3. The pipeline checks out the team repository and the agent, and installs the agent's libraries.
4. The agent skips draft PRs and commits it has already reviewed.
5. It reads the diff and builds the list of changed lines.
6. It reads `.codereview.yml` if the repository has one.
7. It applies line rules, multi-line checks, the secret scan and the dependency checks.
8. It applies the repository settings, the test-code handling and the baseline.
9. It confirms that no newer push has arrived.
10. It posts or updates one comment and writes the reports.
11. It exits with success, or with failure when `fail_on` is set and a finding reaches that severity.

## 4. Configuration scenarios

| Goal | Configuration |
|---|---|
| Review every pull request | Review pipeline plus a branch policy (Build validation) |
| Add line-level comments | `inline_comments: { enabled: true, min_severity: high, max: 15 }` |
| Review the existing code | `--all-files`, or `full-scan.example.yml` |
| Report only new findings | `--write-baseline`, then `baseline: .codereview-baseline.json` |
| Tune for one repository | `.codereview.yml` (`disable`, `severity`, `exclude_paths`, `test_paths`) |
| Include dependency reports | `dependencies: { npm_audit: ..., dependency_check: ... }` |
| Fail the build on serious findings | `fail_on: critical`, later `high` (or `RULE_FAIL_ON`) |
| Stop the agent immediately | `RULE_REVIEW_ENABLED=false` |
