import json
import os
import subprocess
import sys
from types import SimpleNamespace

import pytest

from agent.azure_devops import AzureDevOps
from agent.rule_review import RULE_MARKER, run


def git(repo, *args):
    subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True)


def make_repo(tmp_path, base_files, changed_files, deleted=()):
    r = tmp_path / "repo"
    r.mkdir()
    git(r, "init", "-q", "-b", "main")
    git(r, "config", "user.email", "t@example.com")
    git(r, "config", "user.name", "t")
    for name, text in base_files.items():
        (r / name).parent.mkdir(parents=True, exist_ok=True)
        (r / name).write_text(text)
    git(r, "add", "-A")
    git(r, "commit", "-q", "-m", "base")
    git(r, "checkout", "-q", "-b", "feature")
    for name, text in changed_files.items():
        (r / name).parent.mkdir(parents=True, exist_ok=True)
        (r / name).write_text(text)
    git(r, "add", "-A")
    git(r, "commit", "-q", "-m", "change")
    return r


@pytest.fixture(autouse=True)
def out_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("OUTPUT_DIR", str(tmp_path / "out"))
    return tmp_path / "out"


def go(repo, **kw):
    return run(str(repo), "main", env={"OUTPUT_DIR": os.environ["OUTPUT_DIR"]}, **kw)


def test_finds_issues_in_a_real_pr_without_leaking_secrets(repo, capsys, out_dir):
    code = go(repo, dry_run=True)
    out = capsys.readouterr().out
    assert code == 0                                   # advisory by default
    assert "JAVA_SQL_CONCAT" in out and "SECRET_SCAN" in out
    assert "SuperSecret123" not in out                 # never echoed
    assert "tokens_used=0" in out
    report = json.load(open(out_dir / "rule_review_report.json"))
    assert {f["rule_id"] for f in report["findings"]} >= {"JAVA_SQL_CONCAT", "SECRET_SCAN"}
    assert "package-lock.json" not in out              # lockfile ignored


def test_fail_on_threshold(repo):
    assert go(repo, dry_run=True, fail_on="none") == 0
    assert go(repo, dry_run=True, fail_on="high") == 1          # SQL concat + secret are 'high'
    assert go(repo, dry_run=True, fail_on="critical") == 0


def test_existing_problems_on_untouched_lines_are_not_reported(tmp_path, capsys):
    base = 'class A {\n  void a() {\n    System.out.println("old");\n  }\n  int b() {\n    return 1;\n  }\n}\n'
    changed = base.replace("return 1;", "return 2;")
    r = make_repo(tmp_path, {"A.java": base}, {"A.java": changed})
    assert go(r, dry_run=True) == 0
    out = capsys.readouterr().out
    assert "JAVA_SYSTEM_OUT" not in out and "No rule violations" in out


def test_removing_a_where_clause_is_caught(tmp_path, capsys):
    # ONLY the WHERE line is deleted; the lines above it are untouched. A deletion leaves no added
    # line, so this proves removals are tracked.
    base = "UPDATE budgets\nSET amount = 0\nWHERE project_id = 5\n;\n"
    changed = "UPDATE budgets\nSET amount = 0\n;\n"
    r = make_repo(tmp_path, {"fix.sql": base}, {"fix.sql": changed})
    go(r, dry_run=True)
    assert "SQL_UPDATE_NO_WHERE" in capsys.readouterr().out


def test_unrelated_deletion_does_not_trigger_findings(tmp_path, capsys):
    base = "UPDATE budgets\nSET amount = 0\nWHERE project_id = 5;\n\nSELECT 1;\nSELECT 2;\n"
    changed = "UPDATE budgets\nSET amount = 0\nWHERE project_id = 5;\n\nSELECT 1;\n"
    r = make_repo(tmp_path, {"a.sql": base}, {"a.sql": changed})
    go(r, dry_run=True)
    assert "SQL_UPDATE_NO_WHERE" not in capsys.readouterr().out


@pytest.mark.parametrize("filename,content,secret", [
    ("src/main/resources/application.properties", 'db.password="Sup3rS3cretValue"\n', "Sup3rS3cretValue"),
    ("config.yml", 'api_key: "abcdef123456789"\n', "abcdef123456789"),
    (".env", 'TOKEN = "tok_abcdefghijklmnop"\n', "tok_abcdefghijklmnop"),
])
def test_secret_in_a_non_code_file_is_found(tmp_path, capsys, filename, content, secret):
    r = make_repo(tmp_path, {"README.md": "x\n"}, {filename: content})
    go(r, dry_run=True)
    out = capsys.readouterr().out
    assert ("SECRET_SCAN" in out or "CONFIG_PLAINTEXT_SECRET" in out) and secret not in out


def test_clean_change_reports_no_violations(tmp_path, capsys):
    r = make_repo(tmp_path, {"A.java": "class A {\n  int f() {\n    return 1;\n  }\n}\n"},
                  {"A.java": "class A {\n  int f() {\n    return 2;\n  }\n}\n"})
    assert go(r, dry_run=True, fail_on="low") == 0
    assert "No rule violations" in capsys.readouterr().out


def test_disabled_rules_are_honoured(repo, capsys):
    go(repo, dry_run=True, disabled=frozenset({"JAVA_SQL_CONCAT", "SECRET_SCAN"}))
    out = capsys.readouterr().out
    assert "JAVA_SQL_CONCAT" not in out and "SECRET_SCAN" not in out


def test_fails_open_on_any_internal_problem(tmp_path, repo):
    assert go(repo, dry_run=True, rules_file=str(tmp_path / "missing.yml"), fail_on="low") == 0
    bad = tmp_path / "bad.yml"
    bad.write_text("rules:\n  - id: X\n    pattern: '('\n")
    assert go(repo, dry_run=True, rules_file=str(bad), fail_on="low") == 0
    assert run(str(tmp_path / "not-a-repo"), "main", dry_run=True, fail_on="low",
               env={"OUTPUT_DIR": str(tmp_path / "o")}) == 0


def test_kill_switch(repo):
    assert run(str(repo), "main", dry_run=True, fail_on="low", env={"RULE_REVIEW_ENABLED": "false"}) == 0


def test_cli_runs_as_a_script(repo, tmp_path):
    script = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "agent", "rule_review.py")
    result = subprocess.run([sys.executable, script, "--repo-dir", str(repo), "--target-branch", "main",
                             "--dry-run", "--fail-on", "high"], capture_output=True, text=True,
                            cwd=str(tmp_path), env={**os.environ, "OUTPUT_DIR": str(tmp_path / "o")})
    assert result.returncode == 1 and "Code review" in result.stdout     # run from ANOTHER directory
    assert "SuperSecret123" not in result.stdout


# ---------------------------------------------------------------- Azure DevOps behaviour
PR = {"lastMergeSourceCommit": {"commitId": "abc123"}, "targetRefName": "refs/heads/main", "isDraft": False}


class FakeADO(AzureDevOps):
    def __init__(self, pr=PR, existing=None, current_sha=None):
        self.pr, self.existing, self.posted = pr, existing, []
        self.current_sha = current_sha or pr["lastMergeSourceCommit"]["commitId"]

    def get_pr(self):
        return self.pr

    def find_comment(self):
        return self.existing

    def current_source_commit(self):
        return self.current_sha

    def upsert_comment(self, content):
        self.posted.append(content)


def test_posts_one_comment_with_its_own_marker(repo):
    ado = FakeADO()
    assert go(repo, ado=ado) == 0
    assert len(ado.posted) == 1
    assert ado.posted[0].startswith(f"{RULE_MARKER} sha=abc123 -->")


def test_skips_drafts_same_commit_and_stale_runs(repo):
    ado = FakeADO(dict(PR, isDraft=True))
    go(repo, ado=ado)
    assert ado.posted == []
    seen = FakeADO(existing={"content": f"{RULE_MARKER} sha=abc123 -->", "thread_id": 1, "comment_id": 1})
    go(repo, ado=seen)
    assert seen.posted == []
    stale = FakeADO(current_sha="newer")
    go(repo, ado=stale)
    assert stale.posted == []


def test_rule_and_ai_comments_do_not_overwrite_each_other():
    threads = [{"id": 1, "comments": [{"id": 1, "content": f"{RULE_MARKER} sha=x -->\nrules"}]},
               {"id": 2, "comments": [{"id": 1, "content": "<!-- ai-code-review-agent sha=x -->\nai"}]}]

    class S:
        def request(self, method, url, params=None, json=None, headers=None, timeout=None):
            return SimpleNamespace(content=b"x", raise_for_status=lambda: None, json=lambda: {"value": threads})

    env = {"SYSTEM_COLLECTIONURI": "https://dev.azure.com/o/", "SYSTEM_TEAMPROJECT": "p",
           "BUILD_REPOSITORY_ID": "r", "SYSTEM_PULLREQUEST_PULLREQUESTID": "1", "SYSTEM_ACCESSTOKEN": "t"}
    assert AzureDevOps(env, S()).find_comment()["thread_id"] == 2                     # AI agent's comment
    assert AzureDevOps(env, S(), marker=RULE_MARKER).find_comment()["thread_id"] == 1  # rule agent's comment


def test_security_findings_show_owasp_in_the_comment(tmp_path, capsys):
    ctl = ("@RestController\npublic class C {\n    @PostMapping\n"
           "    public void save(@RequestBody X x) {\n        repo.save(x);\n    }\n}\n")
    r = make_repo(tmp_path, {"README.md": "x\n"}, {"src/C.java": ctl})
    go(r, dry_run=True)
    out = capsys.readouterr().out
    assert "JAVA_ENDPOINT_NO_AUTHZ" in out and "A01:2025 Broken Access Control" in out and "CWE-862" in out
    assert "**OWASP Top 10:2025:**" in out


def test_config_docker_and_build_files_are_reviewed(tmp_path, capsys):
    r = make_repo(tmp_path, {"README.md": "x\n"}, {
        "src/main/resources/application.properties": "spring.datasource.password=Pr0dPassw0rd\nmanagement.endpoints.web.exposure.include=*\n",
        "Dockerfile": "FROM openjdk\nCOPY app.jar /app.jar\n",
        "pom.xml": "<project>\n  <repositories><repository><url>http://repo.example.com/m2</url></repository></repositories>\n</project>\n",
        "frontend/package.json": '{\n  "dependencies": {\n    "lodash": "*"\n  }\n}\n',
    })
    go(r, dry_run=True)
    out = capsys.readouterr().out
    for rule in ("CONFIG_PLAINTEXT_SECRET", "CONFIG_ACTUATOR_EXPOSE_ALL", "DOCKER_NO_USER", "DOCKER_UNPINNED_IMAGE",
                 "XML_HTTP_REPOSITORY", "JSON_UNPINNED_DEPENDENCY"):
        assert rule in out, rule
    assert "Pr0dPassw0rd" not in out


def test_security_findings_in_test_code_are_downgraded_not_hidden(tmp_path, capsys, out_dir):
    test_code = 'class T {\n  String q = "SELECT * FROM t WHERE id = " + id;\n}\n'
    r = make_repo(tmp_path, {"README.md": "x\n"}, {"src/test/java/RepoTest.java": test_code})
    assert go(r, dry_run=True, fail_on="high") == 0            # does not block
    out = capsys.readouterr().out
    assert "JAVA_SQL_CONCAT" in out and "(test code)" in out and "LOW" in out


def test_vendored_libraries_are_skipped(tmp_path, capsys):
    r = make_repo(tmp_path, {"README.md": "x\n"},
                  {"src/main/resources/static/js/libs/editor-0.3.0.js": "try { a() } catch (e) {}\neval(x);\n",
                   "web/vendor/lib.js": "eval(x);\n"})
    go(r, dry_run=True)
    out = capsys.readouterr().out
    assert "EMPTY_CATCH" not in out and "JS_EVAL" not in out
