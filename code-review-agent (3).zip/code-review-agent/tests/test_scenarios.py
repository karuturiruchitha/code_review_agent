"""END-TO-END SCENARIOS. Every test builds a real git repository and runs the real review flow.

S1  pull request touching every part of a typical stack          S8  baseline survives edits above the finding
S2  clean pull request                                           S9  per-repository settings (.codereview.yml)
S3  PR that only bumps a vulnerable dependency                   S10 inline comments on Azure DevOps (opt-in)
S4  npm audit report, scoped to PRs that touch package.json      S11 reports: HTML safety, SARIF structure, determinism
S5  OWASP Dependency-Check report                                S12 command line, from another folder
S6  full repository scan (old code, not only the diff)           S13 safety: kill switch, fail open, thresholds
S7  score is capped per rule
"""
import json
import os
import subprocess
import sys

import pytest

from agent.azure_devops import AzureDevOps
from agent.rule_review import RULE_MARKER, run
from helpers import fixture, git, make_repo, write_files

CONTROLLER = """@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {
    private final InvoiceService service;

    @GetMapping("/{invoiceId}")
    public Invoice get(@PathVariable Long invoiceId) {
        return service.findById(invoiceId);
    }

    @DeleteMapping("/{invoiceId}")
    public void delete(@PathVariable Long invoiceId) {
        try {
            service.delete(invoiceId);
        } catch (Exception e) { }
    }
}
"""
REPOSITORY = """public class InvoiceRepository {
    public List<Invoice> export(String customer, String sortBy) {
        String sql = "SELECT i.id, i.amount FROM invoices i "
                   + "WHERE i.customer_name = '" + customer + "' "
                   + "ORDER BY " + sortBy;
        return jdbc.query(sql, mapper);
    }

    public void run(Statement stmt, String query) throws SQLException {
        stmt.executeQuery(query);
    }

    public void markExported(List<Long> ids) {
        for (Long id : ids) {
            jdbc.update("UPDATE invoices SET exported = 1 WHERE id = ?", id);
        }
    }

    public String token() {
        return Jwts.builder().setSubject("x").signWith(key).compact();
    }
}
"""
REACT = """export default function List({ projectId }) {
  const [rows, setRows] = useState([]);
  useEffect(() => {
    fetch(`/api/p/${projectId}`).then(r => r.json()).then(setRows);
  }, [projectId]);
  useEffect(() => {
    axios.get('/api/x').then(r => setRows(r.data));
  });
  useEffect(() => {
    const id = setInterval(tick, 1000);
  }, []);
  const load = async () => { const r = await fetch('/api/y'); setRows(await r.json()); };
  localStorage.setItem("authToken", token);
  return null;
}
"""
SQL = """UPDATE billing SET status = 'BILLED';
SELECT id FROM t WHERE id NOT IN (SELECT parent_id FROM child);
CREATE PROCEDURE close_month(IN p INT)
BEGIN
  UPDATE a SET x = 1 WHERE id = p;
  INSERT INTO b(id) VALUES (p);
END;
"""
POM = """<project>
  <dependencies>
    <dependency><groupId>org.apache.logging.log4j</groupId><artifactId>log4j-core</artifactId><version>2.14.0</version></dependency>
  </dependencies>
  <repositories><repository><url>http://repo.example.com/m2</url></repository></repositories>
</project>
"""
STACK = {
    "src/main/java/app/InvoiceController.java": CONTROLLER, "src/main/java/app/InvoiceRepository.java": REPOSITORY,
    "frontend/src/List.jsx": REACT, "db/close.sql": SQL, "pom.xml": POM,
    "src/main/resources/application.properties":
        "spring.datasource.password=Pr0dPassw0rd\nspring.jpa.hibernate.ddl-auto=update\nspring.datasource.url=jdbc:mysql://db/x?useSSL=false\n",
    "Dockerfile": "FROM openjdk\nCOPY app.jar /app.jar\n",
    "frontend/package.json": '{\n  "dependencies": {\n    "lodash": "*"\n  }\n}\n',
}


@pytest.fixture(autouse=True)
def out_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("OUTPUT_DIR", str(tmp_path / "out"))
    return tmp_path / "out"


def go(repo, **kw):
    kw.setdefault("env", {"OUTPUT_DIR": os.environ["OUTPUT_DIR"]})
    return run(str(repo), kw.pop("target", "main"), **kw)


def report(out_dir):
    return json.load(open(out_dir / "rule_review_report.json"))


def ids_of(out_dir):
    return {f["rule_id"] for f in report(out_dir)["findings"]}


# ---------------------------------------------------------------------------------------- S1
def test_s1_pull_request_across_the_whole_stack(tmp_path, capsys, out_dir):
    r = make_repo(tmp_path, {"README.md": "x\n"}, STACK)
    assert go(r, dry_run=True) == 0                          # advisory by default
    found = ids_of(out_dir)
    expected = {"JAVA_ENDPOINT_NO_AUTHZ", "JAVA_IDOR_RISK", "EMPTY_CATCH", "JAVA_SQL_CONCAT", "JAVA_RAW_STATEMENT",
                "JAVA_DB_CALL_IN_LOOP", "JAVA_JWT_NO_EXPIRY", "REACT_EFFECT_RACE", "REACT_EFFECT_NO_DEPS",
                "REACT_EFFECT_NO_CLEANUP", "JS_ASYNC_NO_ERROR_HANDLING", "JS_TOKEN_IN_STORAGE", "SQL_UPDATE_NO_WHERE",
                "SQL_NOT_IN_SUBQUERY", "SQL_PROC_NO_HANDLER", "CONFIG_PLAINTEXT_SECRET", "CONFIG_DDL_AUTO_PROPS",
                "CONFIG_JDBC_SSL_OFF", "DOCKER_NO_USER", "DOCKER_UNPINNED_IMAGE", "JSON_UNPINNED_DEPENDENCY",
                "XML_HTTP_REPOSITORY", "DEP_VULNERABLE_LIBRARY"}
    missing = expected - found
    assert not missing, f"not detected: {sorted(missing)}"
    out = capsys.readouterr().out
    assert "Pr0dPassw0rd" not in out and "tokens_used=0" in out
    for name in ("rule_review_report.json", "rule_review_report.md", "rule_review_report.html", "rule_review.sarif"):
        assert (out_dir / name).exists(), name


# ---------------------------------------------------------------------------------------- S2
def test_s2_clean_pull_request(tmp_path, capsys):
    r = make_repo(tmp_path, {"A.java": "class A {\n  int f() {\n    return 1;\n  }\n}\n"},
                  {"A.java": "class A {\n  int f() {\n    return 2;\n  }\n}\n"})
    assert go(r, dry_run=True, fail_on="low") == 0
    assert "No rule violations" in capsys.readouterr().out


# ---------------------------------------------------------------------------------------- S3
def test_s3_dependency_bump_reports_only_the_changed_dependency(tmp_path, out_dir):
    two = ("<project>\n  <dependencies>\n"
           "    <dependency><groupId>org.yaml</groupId><artifactId>snakeyaml</artifactId><version>1.30</version></dependency>\n"
           "    <dependency><groupId>org.apache.commons</groupId><artifactId>commons-text</artifactId><version>1.10.0</version></dependency>\n"
           "  </dependencies>\n</project>\n")
    base = {"pom.xml": two, "README.md": "x\n"}
    # PR changes ONLY commons-text to a vulnerable version; snakeyaml 1.30 (also vulnerable) already existed
    changed = {"pom.xml": two.replace("1.10.0", "1.9")}
    r = make_repo(tmp_path, base, changed)
    go(r, dry_run=True)
    deps_found = [f for f in report(out_dir)["findings"] if f["rule_id"] == "DEP_VULNERABLE_LIBRARY"]
    assert [f["package"] for f in deps_found] == ["commons-text"]
    assert deps_found[0]["severity"] == "critical" and deps_found[0]["owasp"] == "A03"


def test_s3b_unrelated_pr_does_not_resurface_old_dependency_problems(tmp_path, out_dir):
    pom = ("<project>\n  <dependencies>\n"
           "    <dependency><groupId>org.yaml</groupId><artifactId>snakeyaml</artifactId><version>1.30</version></dependency>\n"
           "  </dependencies>\n</project>\n")
    r = make_repo(tmp_path, {"pom.xml": pom}, {"README.md": "changed\n"})
    go(r, dry_run=True)
    assert "DEP_VULNERABLE_LIBRARY" not in ids_of(out_dir)


def test_s3c_version_property_and_unresolvable_property(tmp_path, out_dir):
    pom = ("<project><properties><log4j.version>2.14.0</log4j.version></properties><dependencies>\n"
           "<dependency><groupId>org.apache.logging.log4j</groupId><artifactId>log4j-core</artifactId><version>${log4j.version}</version></dependency>\n"
           "<dependency><groupId>org.yaml</groupId><artifactId>snakeyaml</artifactId><version>${not.defined}</version></dependency>\n"
           "</dependencies></project>\n")
    r = make_repo(tmp_path, {"README.md": "x\n"}, {"pom.xml": pom})
    go(r, dry_run=True)
    pk = [f["package"] for f in report(out_dir)["findings"] if f["rule_id"] == "DEP_VULNERABLE_LIBRARY"]
    assert pk == ["log4j-core"]                              # resolved through <properties>; the unknown one is not guessed


# ---------------------------------------------------------------------------------------- S4
def test_s4_npm_audit_report_only_when_package_json_changed(tmp_path, out_dir):
    audit = fixture("npm-audit-v2.json")
    pj = '{ "name": "demo", "dependencies": { "lodash": "4.17.10" } }\n'
    r = make_repo(tmp_path, {"package.json": pj, "README.md": "x\n", "npm-audit.json": audit},
                  {"package.json": pj.replace("4.17.10", "4.17.11")})
    go(r, dry_run=True, npm_audit="npm-audit.json")
    found = [f for f in report(out_dir)["findings"] if f["rule_id"] == "DEP_NPM_AUDIT"]
    assert {f["package"] for f in found} == {"jsonwebtoken", "lodash", "minimist"}
    assert {f["severity"] for f in found} == {"critical", "high"} and all(f["cwe"].startswith("CWE-") for f in found)
    # a PR that does not touch the manifest must not drag the old audit results along
    r2 = make_repo(tmp_path, {"package.json": pj, "npm-audit.json": audit, "README.md": "x\n"}, {"README.md": "y\n"}, name="r2")
    go(r2, dry_run=True, npm_audit="npm-audit.json")
    assert "DEP_NPM_AUDIT" not in ids_of(out_dir)


def test_s4b_missing_or_broken_report_is_a_warning_not_a_failure(tmp_path, out_dir, capsys):
    r = make_repo(tmp_path, {"package.json": "{}\n", "bad.json": "not json"}, {"package.json": '{"a": 1}\n'})
    assert go(r, dry_run=True, npm_audit="missing.json", fail_on="low") == 0
    assert go(r, dry_run=True, npm_audit="bad.json", fail_on="low") == 0
    out = capsys.readouterr().out
    assert "dependency report not found: missing.json" in out and "could not read dependency report bad.json" in out


# ---------------------------------------------------------------------------------------- S5
def test_s5_dependency_check_report(tmp_path, out_dir):
    r = make_repo(tmp_path, {"pom.xml": "<project/>\n", "dc.json": fixture("dependency-check-sample.json")},
                  {"pom.xml": "<project>\n</project>\n"})
    go(r, dry_run=True, dependency_check="dc.json")
    found = {f["package"]: f for f in report(out_dir)["findings"] if f["rule_id"] == "DEP_CHECK"}
    assert set(found) == {"log4j-core-2.14.0.jar", "jackson-databind-2.12.1.jar", "old-lib-1.0.jar"}   # clean jar not listed
    log4j = found["log4j-core-2.14.0.jar"]
    assert log4j["severity"] == "critical" and "CVE-2021-44228" in log4j["title"] and log4j["cwe"] == "CWE-917"
    assert found["jackson-databind-2.12.1.jar"]["severity"] == "high" and found["old-lib-1.0.jar"]["severity"] == "medium"


# ---------------------------------------------------------------------------------------- S6
def test_s6_full_scan_finds_old_code_that_a_pr_review_ignores(tmp_path, out_dir):
    r = make_repo(tmp_path, STACK, {"README.md": "a change elsewhere\n"})
    go(r, dry_run=True)
    assert "JAVA_SQL_CONCAT" not in ids_of(out_dir)           # PR mode: the old code is not part of this change
    assert go(r, dry_run=True, all_files=True) == 0
    rep = report(out_dir)
    assert rep["mode"] == "full_scan" and {"JAVA_SQL_CONCAT", "SQL_UPDATE_NO_WHERE", "CONFIG_PLAINTEXT_SECRET"} <= ids_of(out_dir)
    assert rep["score"] and rep["score"]["grade"] in "ABCDF" and 0 <= rep["score"]["score"] <= 100
    md = (out_dir / "rule_review_report.md").read_text()
    assert "full repository scan" in md and "Score:" in md and "OWASP Top 10:2025" in md


def test_s6b_full_scan_skips_binary_and_generated_files(tmp_path, out_dir):
    r = make_repo(tmp_path, {"logo.png": "x", "package-lock.json": '{"password": "abcdefghijk"}\n', "src/A.java": "class A {}\n"})
    (r / "blob.bin").write_bytes(b"\x00\x01password = 'abcdefgh12'\x00")
    git(r, "add", "-A")
    go(r, dry_run=True, all_files=True)
    assert report(out_dir)["findings"] == []


# ---------------------------------------------------------------------------------------- S7
def test_s7_score_is_capped_per_rule(tmp_path, out_dir):
    noisy = "\n".join(f"System.out.println({i});" for i in range(400))          # 400 low findings from ONE rule
    r = make_repo(tmp_path, {"src/main/java/Noisy.java": "class N {\n" + noisy + "\n}\n"})
    go(r, dry_run=True, all_files=True)
    sc = report(out_dir)["score"]
    assert sc["score"] >= 80 and sc["grade"] in ("A", "B")                          # 400 x 0.5 would be -200 without the cap
    assert sc["biggest_penalties"][0] == {"rule_id": "JAVA_SYSTEM_OUT", "points": 20.0, "capped": True}


# ---------------------------------------------------------------------------------------- S8
def test_s8_baseline_accepts_old_findings_and_survives_edits_above_them(tmp_path, out_dir, capsys):
    r = make_repo(tmp_path, {"src/main/java/A.java": 'class A {\n  void f() {\n    System.out.println("a");\n  }\n}\n'})
    assert go(r, dry_run=True, all_files=True, write_baseline="baseline.json") == 0
    assert json.load(open(r / "baseline.json"))["count"] >= 1
    # edit ABOVE the accepted finding (line numbers shift) and add one NEW problem
    new_text = ('// header comment\n// another line\nclass A {\n  void f() {\n    System.out.println("a");\n  }\n'
                '  void g() {\n    e.printStackTrace();\n  }\n}\n')
    write_files(r, {"src/main/java/A.java": new_text})
    go(r, dry_run=True, all_files=True, baseline="baseline.json")
    rep = report(out_dir)
    assert {f["rule_id"] for f in rep["findings"]} == {"JAVA_PRINT_STACKTRACE"}    # only the new one
    assert rep["baseline_suppressed"] == 1
    assert "accepted in the baseline" in (out_dir / "rule_review_report.md").read_text()


def test_s8b_identical_findings_are_counted_separately(tmp_path, out_dir):
    two = 'class A {\n  void f() {\n    System.out.println("x");\n    System.out.println("x");\n  }\n}\n'
    r = make_repo(tmp_path, {"src/main/java/A.java": 'class A {\n  void f() {\n    System.out.println("x");\n  }\n}\n'})
    go(r, dry_run=True, all_files=True, write_baseline="b.json")
    write_files(r, {"src/main/java/A.java": two})                                   # a second identical call appears
    go(r, dry_run=True, all_files=True, baseline="b.json")
    assert len(report(out_dir)["findings"]) == 1 and report(out_dir)["baseline_suppressed"] == 1


def test_s8c_missing_baseline_shows_everything_with_a_warning(tmp_path, out_dir):
    r = make_repo(tmp_path, {"src/main/java/A.java": 'class A {\n  void f() {\n    System.out.println("x");\n  }\n}\n'})
    go(r, dry_run=True, all_files=True, baseline="nope.json")
    assert len(report(out_dir)["findings"]) == 1
    assert any("baseline file not found" in w for w in report(out_dir)["warnings"])


# ---------------------------------------------------------------------------------------- S9
def test_s9_settings_file_controls_the_review(tmp_path, out_dir):
    cfgfile = ("version: 1\nfail_on: high\ndisable: [JAVA_SYSTEM_OUT]\nseverity:\n  JAVA_PRINT_STACKTRACE: high\n"
               "exclude_paths: ['legacy/**']\n")
    code = 'class A {\n  void f() {\n    System.out.println("x");\n    e.printStackTrace();\n  }\n}\n'
    r = make_repo(tmp_path, {".codereview.yml": cfgfile, "README.md": "x\n"},
                  {"src/main/java/A.java": code, "legacy/Old.java": code})
    assert go(r, dry_run=True) == 1                                                 # fail_on: high from the file; severity raised
    found = {(f["file"], f["rule_id"]): f["severity"] for f in report(out_dir)["findings"]}
    assert ("src/main/java/A.java", "JAVA_PRINT_STACKTRACE") in found and found[("src/main/java/A.java", "JAVA_PRINT_STACKTRACE")] == "high"
    assert not any(rule == "JAVA_SYSTEM_OUT" for _p, rule in found)                  # disabled
    assert not any(p.startswith("legacy/") for p, _r in found)                       # excluded folder
    assert go(r, dry_run=True, fail_on="none") == 0                                  # the command line beats the file


def test_s9b_settings_mistakes_become_warnings_never_failures(tmp_path, out_dir):
    cfgfile = "disable: [JAVA_SYTEM_OUT]\nseverity:\n  JAVA_PRINT_STACKTRACE: urgent\nbogus_key: 1\nfail_on: sometimes\n"
    r = make_repo(tmp_path, {".codereview.yml": cfgfile, "README.md": "x\n"}, {"src/A.java": "class A {}\n"})
    assert go(r, dry_run=True) == 0
    w = " | ".join(report(out_dir)["warnings"])
    for expect in ("unknown rule id 'JAVA_SYTEM_OUT'", "severity 'urgent'", "unknown key 'bogus_key'", "fail_on 'sometimes'"):
        assert expect in w, expect


def test_s9c_unreadable_settings_file_uses_defaults(tmp_path, out_dir):
    r = make_repo(tmp_path, {".codereview.yml": "disable: [a\n  bad: : yaml\n", "README.md": "x\n"},
                  {"src/main/java/A.java": 'class A {\n  void f() {\n    e.printStackTrace();\n  }\n}\n'})
    assert go(r, dry_run=True) == 0
    assert "JAVA_PRINT_STACKTRACE" in ids_of(out_dir) and any("could not read" in w for w in report(out_dir)["warnings"])


def test_s9d_extra_test_paths_are_downgraded(tmp_path, out_dir):
    q = 'class A {\n  String f(String id) {\n    return "SELECT * FROM t WHERE id = " + id;\n  }\n}\n'
    r = make_repo(tmp_path, {".codereview.yml": "test_paths: ['qa/**']\n", "README.md": "x\n"}, {"qa/Helper.java": q, "src/Main.java": q})
    go(r, dry_run=True)
    sev = {f["file"]: f["severity"] for f in report(out_dir)["findings"] if f["rule_id"] == "JAVA_SQL_CONCAT"}
    assert sev == {"qa/Helper.java": "low", "src/Main.java": "high"}


def test_s9e_dependency_rules_can_be_disabled_too(tmp_path, out_dir):
    pom = ("<project><dependencies>\n<dependency><groupId>org.yaml</groupId><artifactId>snakeyaml</artifactId>"
           "<version>1.30</version></dependency>\n</dependencies></project>\n")
    audit = fixture("npm-audit-v2.json")
    r = make_repo(tmp_path, {"README.md": "x\n", "npm-audit.json": audit, "package.json": "{}\n"},
                  {"pom.xml": pom, "package.json": '{"a": 1}\n'})
    go(r, dry_run=True, npm_audit="npm-audit.json")
    assert {"DEP_VULNERABLE_LIBRARY", "DEP_NPM_AUDIT"} <= ids_of(out_dir)
    go(r, dry_run=True, npm_audit="npm-audit.json", disabled=frozenset({"DEP_VULNERABLE_LIBRARY", "DEP_NPM_AUDIT"}))
    assert not ({"DEP_VULNERABLE_LIBRARY", "DEP_NPM_AUDIT"} & ids_of(out_dir))
    (r / ".codereview.yml").write_text("disable: [DEP_VULNERABLE_LIBRARY]\n")                    # also through the settings file
    go(r, dry_run=True, npm_audit="npm-audit.json")
    assert "DEP_VULNERABLE_LIBRARY" not in ids_of(out_dir) and "DEP_NPM_AUDIT" in ids_of(out_dir)


# ---------------------------------------------------------------------------------------- S10
PR = {"lastMergeSourceCommit": {"commitId": "abc123"}, "targetRefName": "refs/heads/main", "isDraft": False}


class FakeADO(AzureDevOps):
    def __init__(self, pr=PR, existing=None, current_sha=None, known_inline=()):
        self.pr, self.existing, self.posted, self.inline = pr, existing, [], []
        self.known_inline, self.current_sha = set(known_inline), current_sha or pr["lastMergeSourceCommit"]["commitId"]

    def get_pr(self):
        return self.pr

    def find_comment(self):
        return self.existing

    def current_source_commit(self):
        return self.current_sha

    def upsert_comment(self, content):
        self.posted.append(content)

    def inline_fingerprints(self):
        return set(self.known_inline)

    def create_inline_thread(self, file_path, line, content):
        self.inline.append((file_path, line, content))


INLINE_REPO = {"src/main/java/A.java": 'class A {\n  void f(String id) {\n    String q = "SELECT * FROM t WHERE id = " + id;\n    e.printStackTrace();\n  }\n}\n'}


def test_s10_inline_comments_are_opt_in_filtered_and_not_duplicated(tmp_path):
    r = make_repo(tmp_path, {"README.md": "x\n"}, INLINE_REPO)
    off = FakeADO()
    go(r, ado=off)
    assert off.inline == [] and len(off.posted) == 1                                   # off by default
    on = FakeADO()
    go(r, ado=on, inline=True)
    assert len(on.inline) == 1                                                         # only the HIGH one (min_severity high)
    path, line, body = on.inline[0]
    assert path == "src/main/java/A.java" and line == 3 and "JAVA_SQL_CONCAT" in body and "rule-review-inline fp=" in body
    fp = body.split("fp=")[1].split(" ")[0]
    again = FakeADO(known_inline={fp})
    go(r, ado=again, inline=True)
    assert again.inline == []                                                          # a re-run never duplicates


def test_s10b_inline_limit_and_dependency_findings_are_not_inlined(tmp_path):
    many = "\n".join(f'    String q{i} = "SELECT * FROM t WHERE id = " + a{i};' for i in range(6))
    files = {"src/A.java": "class A {\n  void f() {\n" + many + "\n  }\n}\n", "pom.xml": POM}
    r = make_repo(tmp_path, {"README.md": "x\n", ".codereview.yml": "inline_comments:\n  enabled: true\n  max: 3\n"}, files)
    ado = FakeADO()
    go(r, ado=ado)
    assert len(ado.inline) == 3 and all(p == "src/A.java" for p, _l, _b in ado.inline)


def test_s10c_comment_flow_draft_same_commit_and_stale(tmp_path):
    r = make_repo(tmp_path, {"README.md": "x\n"}, INLINE_REPO)
    assert FakeADO(dict(PR, isDraft=True)).posted == [] and go(r, ado=(d := FakeADO(dict(PR, isDraft=True)))) == 0 and d.posted == []
    seen = FakeADO(existing={"content": f"{RULE_MARKER} sha=abc123 -->", "thread_id": 1, "comment_id": 1})
    go(r, ado=seen)
    assert seen.posted == []
    stale = FakeADO(current_sha="newer")
    go(r, ado=stale)
    assert stale.posted == []


def test_s10d_a_failing_azure_devops_call_never_blocks(tmp_path, capsys):
    class Broken(FakeADO):
        def upsert_comment(self, content):
            raise RuntimeError("403 Forbidden")

        def create_inline_thread(self, *a):
            raise RuntimeError("400 Bad Request")
    r = make_repo(tmp_path, {"README.md": "x\n"}, INLINE_REPO)
    assert go(r, ado=Broken(), inline=True) == 0
    assert "Could not post the PR comment" in capsys.readouterr().out


# ---------------------------------------------------------------------------------------- S11
def test_s11_html_report_escapes_code(tmp_path, out_dir):
    evil = 'class A {\n  void f() {\n    log.info("<script>alert(1)</script> password " + password);\n  }\n}\n'
    r = make_repo(tmp_path, {"README.md": "x\n"}, {"src/main/java/A.java": evil})
    go(r, dry_run=True)
    html_text = (out_dir / "rule_review_report.html").read_text()
    assert "<script>alert(1)</script>" not in html_text and "&lt;script&gt;alert(1)&lt;/script&gt;" in html_text
    assert html_text.count("<script>") == 1                                            # only the report's own filter script
    assert html_text.startswith("<!DOCTYPE html>") and "</html>" in html_text


def test_s11b_sarif_structure(tmp_path, out_dir):
    r = make_repo(tmp_path, {"README.md": "x\n"}, STACK)
    go(r, dry_run=True)
    sarif = json.load(open(out_dir / "rule_review.sarif"))
    assert sarif["version"] == "2.1.0" and len(sarif["runs"]) == 1
    run_ = sarif["runs"][0]
    rules = run_["tool"]["driver"]["rules"]
    assert len({x["id"] for x in rules}) == len(rules)
    assert len(run_["results"]) == len(report(out_dir)["findings"])
    for res in run_["results"]:
        assert rules[res["ruleIndex"]]["id"] == res["ruleId"] and res["level"] in ("error", "warning", "note")
        loc = res["locations"][0]["physicalLocation"]
        assert loc["region"]["startLine"] >= 1 and not loc["artifactLocation"]["uri"].startswith("/")
        assert res["partialFingerprints"]["codeReviewAgent/v1"]
    assert any("OWASP" in t for x in rules for t in x["properties"]["tags"])


def test_s11c_reports_are_deterministic(tmp_path):
    r = make_repo(tmp_path, {"README.md": "x\n"}, STACK)
    texts = []
    for i in range(2):
        out = tmp_path / f"o{i}"
        go(r, dry_run=True, report_dir=str(out))
        texts.append({n: (out / n).read_text() for n in ("rule_review_report.json", "rule_review_report.md", "rule_review_report.html", "rule_review.sarif")})
    assert texts[0] == texts[1]


# ---------------------------------------------------------------------------------------- S12
def test_s12_command_line_from_another_folder(tmp_path):
    r = make_repo(tmp_path, STACK, {"README.md": "x\n"})
    script = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "agent", "rule_review.py")
    env = {**os.environ, "OUTPUT_DIR": str(tmp_path / "cli")}
    res = subprocess.run([sys.executable, script, "--repo-dir", str(r), "--all-files", "--dry-run", "--fail-on", "critical"],
                         capture_output=True, text=True, cwd=str(tmp_path), env=env)
    assert res.returncode == 1 and "Full repository scan" in res.stdout.replace("full repository scan", "Full repository scan")
    assert (tmp_path / "cli" / "rule_review_report.html").exists() and "Pr0dPassw0rd" not in res.stdout
    ok = subprocess.run([sys.executable, script, "--repo-dir", str(r), "--all-files", "--dry-run", "--report-dir", str(tmp_path / "x")],
                        capture_output=True, text=True, cwd=str(tmp_path), env=env)
    assert ok.returncode == 0 and (tmp_path / "x" / "rule_review.sarif").exists()


# ---------------------------------------------------------------------------------------- S13
def test_s13_kill_switch_threshold_and_fail_open(tmp_path):
    r = make_repo(tmp_path, {"README.md": "x\n"}, STACK)
    assert run(str(r), "main", dry_run=True, fail_on="low", env={"RULE_REVIEW_ENABLED": "off"}) == 0
    assert go(r, dry_run=True, fail_on="critical") == 1                                # committed secret / log4j are critical
    assert go(r, dry_run=True, fail_on="none") == 0
    assert go(r, dry_run=True, rules_file=str(tmp_path / "missing.yml"), fail_on="low") == 0     # tool problem: fail open
    assert run(str(tmp_path / "not-a-repo"), "main", dry_run=True, fail_on="low", env={"OUTPUT_DIR": str(tmp_path / "o")}) == 0
