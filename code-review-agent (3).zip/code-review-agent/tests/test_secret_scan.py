from agent.secret_scan import redact, scan_added_lines


def test_redact_keeps_context():
    assert redact('password = "SuperSecret123"') == 'password = "<REDACTED>"'
    assert "AKIAABCDEFGHIJKLMNOP" not in redact("key=AKIAABCDEFGHIJKLMNOP")


def test_scan_finds_secret_without_leaking_it():
    f = scan_added_lines("a.java", [(5, 'private static final String DB_PASSWORD = "SuperSecret123";')])
    assert len(f) == 1 and "SuperSecret123" not in f[0]["evidence"]


def test_short_or_non_secret_values_are_not_flagged():
    assert scan_added_lines("a.py", [(1, 'tokenType = "Bearer"')]) == []
    assert scan_added_lines("a.py", [(1, 'label = "Reset password"')]) == []
    assert scan_added_lines("a.py", [(1, 'password = os.getenv("DB_PASSWORD")')]) == []


def test_more_well_known_secret_formats_are_found_and_never_echoed():
    samples = {
        "GitHub token": "token = ghp_abcdefghijklmnopqrstuvwxyz0123456789",
        "Slack token": "SLACK=xoxb-123456789012-abcdefghij",
        "Google API key": "key: AIzaSyA1234567890abcdefghijklmnopqrstuv",
        "Stripe live key": "stripe = sk_live_abcdefghijklmnopqrstuvwx",
        "Azure storage key": "AccountKey=" + "A" * 64 + "==",
    }
    for label, line in samples.items():
        found = scan_added_lines("a.yml", [(1, line)])
        assert found and label in found[0]["title"], label
        for secret_part in ("abcdefghijklmnopqrstuvwxyz0123456789", "123456789012-abcdefghij", "A" * 20):
            assert secret_part not in found[0]["evidence"] or secret_part not in line
    assert scan_added_lines("a.yml", [(1, "token = ghp_short")]) == []
