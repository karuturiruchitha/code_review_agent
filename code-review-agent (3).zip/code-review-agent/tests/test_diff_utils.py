from agent.diff_utils import parse_diff, resolve_target_ref, run_git_diff


def test_parse_real_git_diff(repo):
    diff = run_git_diff(str(repo), resolve_target_ref(str(repo), "refs/heads/main"))
    hunks = parse_diff(diff)
    java = [h for h in hunks if h.file == "src/UserRepository.java"]
    added = {n: t for h in java for n, t in h.added}
    assert any("DB_PASSWORD" in t for t in added.values())
    assert added[5].strip().startswith("private static final String DB_PASSWORD")   # new-file line numbers
    assert {h.file for h in hunks} >= {"src/UserRepository.java", "README.md", "package-lock.json"}


def test_removed_line_starting_with_dashes_is_not_a_header():
    diff = ("diff --git a/a.py b/a.py\n--- a/a.py\n+++ b/a.py\n"
            "@@ -1,3 +1,3 @@\n context\n--- a removed line that starts with dashes\n+added line\n")
    hunks = parse_diff(diff)
    assert len(hunks) == 1 and hunks[0].added == [(2, "added line")] and hunks[0].removed_at == [2]


def test_deleted_files_are_ignored_but_pure_deletions_are_tracked():
    deleted_file = ("diff --git a/x.py b/x.py\ndeleted file mode 100644\n--- a/x.py\n+++ /dev/null\n"
                    "@@ -1,2 +0,0 @@\n-a\n-b\n")
    assert parse_diff(deleted_file) == []
    removal = ("diff --git a/q.sql b/q.sql\n--- a/q.sql\n+++ b/q.sql\n"
               "@@ -1,3 +1,2 @@\n UPDATE t\n SET a = 1\n-WHERE id = 5\n")
    h = parse_diff(removal)[0]
    assert h.added == [] and h.removed_at == [3]       # deleted text sat right after new line 2
