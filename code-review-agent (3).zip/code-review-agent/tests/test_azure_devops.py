from types import SimpleNamespace

from agent.azure_devops import AzureDevOps

ENV = {"SYSTEM_COLLECTIONURI": "https://dev.azure.com/org/", "SYSTEM_TEAMPROJECT": "My Project",
       "BUILD_REPOSITORY_ID": "repo-1", "SYSTEM_PULLREQUEST_PULLREQUESTID": "42",
       "SYSTEM_ACCESSTOKEN": "tok"}


class FakeSession:
    def __init__(self, threads):
        self.calls, self.threads = [], threads

    def request(self, method, url, params=None, json=None, headers=None, timeout=None):
        self.calls.append((method, url, params, json, headers))
        body = {"value": self.threads} if url.endswith("/threads") and method == "GET" else {"ok": 1}
        return SimpleNamespace(content=b"x", raise_for_status=lambda: None, json=lambda: body)


def test_available_requires_all_variables():
    assert AzureDevOps.available(ENV)
    assert not AzureDevOps.available({k: v for k, v in ENV.items() if k != "SYSTEM_ACCESSTOKEN"})


def test_creates_thread_when_none_exists():
    s = FakeSession([])
    AzureDevOps(ENV, s).upsert_comment("<!-- ai-code-review-agent sha=a -->\nhello")
    method, url, params, body, headers = s.calls[-1]
    assert method == "POST" and url.endswith("/pullRequests/42/threads")
    assert "My%20Project" in url and params == {"api-version": "7.1"}
    assert headers["Authorization"] == "Bearer tok"
    assert body["comments"][0]["commentType"] == 1


def test_updates_existing_comment_instead_of_duplicating():
    threads = [{"id": 7, "comments": [{"id": 3, "content": "<!-- ai-code-review-agent sha=old -->\nold"}]}]
    s = FakeSession(threads)
    AzureDevOps(ENV, s).upsert_comment("<!-- ai-code-review-agent sha=new -->\nnew")
    method, url, _p, body, _h = s.calls[-1]
    assert method == "PATCH" and url.endswith("/threads/7/comments/3") and "new" in body["content"]


def test_ignores_other_peoples_comments():
    threads = [{"id": 1, "comments": [{"id": 1, "content": "LGTM"}]}]
    assert AzureDevOps(ENV, FakeSession(threads)).find_comment() is None
