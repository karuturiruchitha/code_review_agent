import os
import subprocess

FIXTURES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")


def git(repo, *args):
    subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True)


def write_files(root, files):
    for name, text in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)


def make_repo(tmp_path, base_files, changed_files=None, name="repo"):
    """A real git repository: 'main' holds base_files; branch 'feature' (checked out) holds the changed files on top."""
    r = tmp_path / name
    r.mkdir()
    git(r, "init", "-q", "-b", "main")
    git(r, "config", "user.email", "t@example.com")
    git(r, "config", "user.name", "t")
    write_files(r, base_files)
    git(r, "add", "-A")
    git(r, "commit", "-q", "-m", "base")
    if changed_files is not None:
        git(r, "checkout", "-q", "-b", "feature")
        write_files(r, changed_files)
        git(r, "add", "-A")
        git(r, "commit", "-q", "-m", "change")
    return r


def fixture(name):
    with open(os.path.join(FIXTURES, name), encoding="utf-8") as fh:
        return fh.read()
