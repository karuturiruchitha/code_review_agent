import os

import pytest

from agent.config import REPO_ROOT
from agent.rules_engine import (OWASP_2025, STRUCTURAL_RULES, all_rule_ids, analyze_file, balanced_end,
                                has_top_level_comma, language_of, line_rule_hits, load_rules,
                                strip_trailing_comment)

RULES = load_rules(os.path.join(REPO_ROOT, "rules", "rules.yml"))


def langs_of(rule):
    return [l for l in rule.langs if l != "any"] or ["java"]


def check(path, content, added=None, disabled=frozenset()):
    """Analyze a whole file; by default every line counts as changed."""
    n = len(content.splitlines())
    lines = set(range(1, n + 1)) if added is None else set(added)
    return analyze_file(path, content, lines, lines, RULES, disabled)


def ids(findings):
    return [f["rule_id"] for f in findings]


# ---------------------------------------------------------------- the rules prove themselves
def test_rule_ids_are_unique_and_documented():
    all_ids = all_rule_ids(RULES)
    assert len(all_ids) == len(set(all_ids))
    doc = open(os.path.join(REPO_ROOT, "docs", "rules.md"), encoding="utf-8").read()
    missing = [i for i in all_ids if i not in doc]
    assert not missing, f"docs/rules.md is out of date, missing: {missing} (run tools/generate_rules_doc.py)"


@pytest.mark.parametrize("rule", RULES, ids=lambda r: r.id)
def test_rule_has_examples(rule):
    assert rule.bad and rule.good, "every rule needs at least one bad and one good example"


@pytest.mark.parametrize("rule", RULES, ids=lambda r: r.id)
def test_rule_flags_bad_examples_and_ignores_good_ones(rule):
    for lang in langs_of(rule):
        for example in rule.bad:
            assert line_rule_hits(rule, example, lang), f"{rule.id} should flag: {example}"
        for example in rule.good:
            assert not line_rule_hits(rule, example, lang), f"{rule.id} should NOT flag: {example}"


# ---------------------------------------------------------------- helpers
def test_balanced_end_skips_strings_and_comments():
    text = 'f(a, "close ) in string", /* ) */ b) // )\nrest'
    assert text[balanced_end(text, 1)] == ")" and balanced_end(text, 1) == text.index(") //")
    assert balanced_end("f(a", 1) == -1
    assert balanced_end("{ 'a}b' }", 0) == 8


def test_top_level_comma():
    assert has_top_level_comma("() => { a(1, 2) }, [x]")
    assert not has_top_level_comma("() => { a(1, 2); b([1, 2]) }")


def test_trailing_comment_ignores_markers_inside_strings():
    assert strip_trailing_comment('url = "http://x"  // note', "java") == 'url = "http://x"  '
    assert strip_trailing_comment("x = 1  -- note", "sql") == "x = 1  "
    assert strip_trailing_comment("x = '--'", "sql") == "x = '--'"


# ---------------------------------------------------------------- only changed lines, comments, ignore
def test_only_changed_lines_are_reported():
    code = 'class A {\n  void f() {\n    System.out.println("x");\n  }\n}\n'
    assert "JAVA_SYSTEM_OUT" in ids(check("src/A.java", code, added={3}))
    assert check("src/A.java", code, added={1, 2, 4, 5}) == []     # pre-existing code is left alone


def test_comment_lines_are_not_flagged_by_code_rules_but_todo_is():
    assert check("a.js", "// eval(x) would be bad\n") == []
    assert ids(check("a.js", "// TODO: fix this\n")) == ["ANY_TODO"]
    assert "JAVA_SYSTEM_OUT" not in ids(check("A.java", 'int a = 1; // System.out.println(x)\n'))
    assert "ANY_TODO" in ids(check("A.java", "int a = 1; // TODO later\n"))


def test_excluded_paths_and_unknown_extensions():
    code = 'System.out.println("x");\n'
    assert "JAVA_SYSTEM_OUT" in ids(check("src/main/java/A.java", code))
    assert "JAVA_SYSTEM_OUT" not in ids(check("src/test/java/ATest.java", code))
    assert check("notes.txt", code) == []
    assert check("A.java", "x" * 5000 + ' System.out.println("x");\n') == []   # minified/generated line skipped


def test_review_ignore_comment():
    base = 'int a = 1;\n{}\nSystem.out.println("x");\n'
    assert "JAVA_SYSTEM_OUT" in ids(check("A.java", base.format("")))
    assert check("A.java", base.format("// review-ignore: JAVA_SYSTEM_OUT temporary")) == []
    assert check("A.java", base.format("// review-ignore")) == []
    assert "JAVA_SYSTEM_OUT" in ids(check("A.java", base.format("// review-ignore: SOME_OTHER_RULE")))
    assert check("A.java", 'System.out.println("x"); // review-ignore: JAVA_SYSTEM_OUT\n') == []


def test_disabled_rules_are_skipped():
    assert check("A.java", 'System.out.println("x");\n', disabled=frozenset({"JAVA_SYSTEM_OUT"})) == []


# ---------------------------------------------------------------- structural rules
def test_empty_catch():
    assert "EMPTY_CATCH" in ids(check("A.java", "try { f(); } catch (Exception e) { }\n"))
    assert "EMPTY_CATCH" in ids(check("a.js", "try { f() } catch (e) {}\n"))
    assert "EMPTY_CATCH" in ids(check("a.js", "try { f() } catch {\n}\n"))
    assert "EMPTY_CATCH" not in ids(check("A.java", "try { f(); } catch (IOException e) { log.error(\"x\", e); }\n"))
    assert "PY_EMPTY_EXCEPT" in ids(check("a.py", "try:\n    f()\nexcept Exception:\n    pass\n"))
    assert "PY_EMPTY_EXCEPT" in ids(check("a.py", "try:\n    f()\nexcept Exception as e:\n    pass\n"))
    assert "PY_EMPTY_EXCEPT" not in ids(check("a.py", "try:\n    import x\nexcept ImportError:\n    pass\n"))   # normal idiom
    assert "PY_EMPTY_EXCEPT" not in ids(check("a.py", "try:\n    f()\nexcept ValueError:\n    log(1)\n"))


JAVA_LOOP = """class S {
  void f(List<Integer> ids) {
    var all = itemRepository.findAll();
    for (Integer id : ids) {
      Item item = itemRepository.findById(id);
      process(item);
    }
    int i = 0;
    while (i < 3) {
      i++;
    }
  }
}
"""


def test_db_call_in_loop_flags_only_the_call_inside_the_loop():
    found = [f for f in check("S.java", JAVA_LOOP) if f["rule_id"] == "JAVA_DB_CALL_IN_LOOP"]
    assert [f["line"] for f in found] == [5]                      # not line 3 (same call, but before the loop)
    assert any(f["rule_id"] == "JAVA_DB_CALL_IN_LOOP" for f in check("S.java", "for (x : y) {\n  repo.save(x);\n}\n"))
    assert "JAVA_DB_CALL_IN_LOOP" not in ids(check("S.java", "for (x : y) {\n  total += x.getPrice();\n}\n"))
    nested = "for (a : x) {\n  for (b : y) {\n    jdbcTemplate.update(sql, b);\n  }\n}\n"
    assert [f["line"] for f in check("S.java", nested) if f["rule_id"] == "JAVA_DB_CALL_IN_LOOP"] == [3]


def test_long_method():
    body = "\n".join(f"    int v{i} = {i};" for i in range(100))
    long_code = f"class A {{\n  public void big() {{\n{body}\n  }}\n}}\n"
    short_code = "class A {\n  public void small() {\n    int a = 1;\n  }\n}\n"
    assert "JAVA_LONG_METHOD" in ids(check("A.java", long_code))
    assert "JAVA_LONG_METHOD" not in ids(check("A.java", short_code))
    # untouched long method is not reported
    assert "JAVA_LONG_METHOD" not in ids(check("A.java", long_code, added={200}))


EFFECT_RACE = """useEffect(() => {
  fetch('/api/data?q=' + q).then(r => r.json()).then(setData);
}, [q]);
"""
EFFECT_OK = """useEffect(() => {
  const controller = new AbortController();
  fetch('/api/data?q=' + q, { signal: controller.signal }).then(r => r.json()).then(setData);
  return () => controller.abort();
}, [q]);
"""
EFFECT_NO_DEPS = """useEffect(() => {
  axios.get('/api/data').then(res => setData(res.data));
});
"""


def test_react_effect_rules():
    assert "REACT_EFFECT_RACE" in ids(check("C.jsx", EFFECT_RACE))
    assert "REACT_EFFECT_NO_DEPS" not in ids(check("C.jsx", EFFECT_RACE))
    assert [i for i in ids(check("C.jsx", EFFECT_OK)) if i.startswith("REACT_")] == []
    found = ids(check("C.tsx", EFFECT_NO_DEPS))
    assert "REACT_EFFECT_NO_DEPS" in found
    assert [i for i in ids(check("C.jsx", "useEffect(() => { setTitle(name); }, [name]);\n")) if i.startswith("REACT_")] == []
    assert [i for i in ids(check("C.jsx", "useEffect(() => { setOpen(true); });\n")) if i.startswith("REACT_")] == []


def test_sql_update_delete_without_where():
    assert "SQL_UPDATE_NO_WHERE" in ids(check("a.sql", "UPDATE t SET a = 1;\n"))
    assert "SQL_UPDATE_NO_WHERE" not in ids(check("a.sql", "UPDATE t SET a = 1 WHERE id = 5;\n"))
    assert "SQL_UPDATE_NO_WHERE" not in ids(check("a.sql", "UPDATE a JOIN b ON a.id = b.id SET a.x = 1;\n"))
    assert "SQL_UPDATE_NO_WHERE" not in ids(check("a.sql", "-- UPDATE t SET a = 1;\n"))
    assert "SQL_UPDATE_NO_WHERE" not in ids(check("a.sql", "INSERT INTO t(a) VALUES ('UPDATE t SET a = 1');\n"))
    assert "SQL_DELETE_NO_WHERE" in ids(check("a.sql", "DELETE FROM t;\n"))
    assert "SQL_DELETE_NO_WHERE" not in ids(check("a.sql", "DELETE FROM t WHERE id = 1;\n"))
    multiline = "UPDATE t\nSET a = 1\nWHERE id = 2;\n"
    assert "SQL_UPDATE_NO_WHERE" not in ids(check("a.sql", multiline))


PROC = """DELIMITER //
CREATE PROCEDURE reset_all()
BEGIN
  IF @flag = 1 THEN
    UPDATE costs SET amount = 0;
  END IF;
  SELECT 1;
END //
DELIMITER ;
"""


def test_sql_inside_stored_procedures_is_found():
    found = [f for f in check("p.sql", PROC) if f["rule_id"] == "SQL_UPDATE_NO_WHERE"]
    assert [f["line"] for f in found] == [5]


def test_sql_drop_and_truncate():
    assert "SQL_DROP_TRUNCATE" in ids(check("a.sql", "DROP TABLE users;\n"))
    assert "SQL_DROP_TRUNCATE" in ids(check("a.sql", "TRUNCATE TABLE users;\n"))
    assert "SQL_DROP_TRUNCATE" not in ids(check("a.sql", "DROP TEMPORARY TABLE work;\n"))
    assert "SQL_DROP_TRUNCATE" not in ids(check("a.sql", "DROP TABLE IF EXISTS tmp_work;\n"))


def test_a_broken_structural_check_never_crashes_the_review():
    garbage = "{{{{ ((( catch ( for ( while ( useEffect( /* unterminated \"\n"
    for name in ("a.java", "a.js", "a.py", "a.sql"):
        check(name, garbage)       # must simply not raise


def test_findings_have_everything_the_comment_needs():
    f = check("A.java", 'String q = "SELECT * FROM t WHERE id = " + id;\n')[0]
    for key in ("rule_id", "title", "severity", "category", "message", "fix", "file", "line", "evidence"):
        assert f[key] not in (None, "")


# ---------------------------------------------------------------- OWASP mapping
def test_every_security_rule_is_mapped_to_owasp_2025_and_cwe():
    for r in RULES:
        if r.category == "security":
            assert r.owasp in OWASP_2025 and r.cwe.startswith("CWE-"), r.id
    for s in STRUCTURAL_RULES:
        if s.category == "security":
            assert s.owasp in OWASP_2025 and s.cwe.startswith("CWE-"), s.id


def test_findings_carry_owasp_labels():
    f = check("A.java", 'String q = "SELECT * FROM t WHERE id = " + id;\n')[0]
    assert f["owasp"] == "A05" and f["owasp_label"] == "A05:2025 Injection" and f["cwe"] == "CWE-89"


def test_every_owasp_category_except_insecure_design_has_automated_rules():
    covered = {r.owasp for r in RULES if r.owasp} | {s.owasp for s in STRUCTURAL_RULES if s.owasp}
    # A06 Insecure Design is not testable by pattern; it is covered by the manual checklist in docs.
    assert set(OWASP_2025) - covered == {"A06"}


# ---------------------------------------------------------------- file types
def test_language_detection():
    assert language_of("src/main/resources/application.properties") == "props"
    assert language_of("src/main/resources/application-prod.yml") == "yaml"
    assert language_of("Dockerfile") == "docker" and language_of("docker/Dockerfile.prod") == "docker"
    assert language_of("pom.xml") == "xml" and language_of("web.xml") is None
    assert language_of("frontend/package.json") == "json" and language_of("tsconfig.json") is None
    assert language_of(".env") == "props" and language_of("README.md") is None


def test_config_secret_is_found_and_never_shown():
    found = check("src/main/resources/application.properties", "spring.datasource.password=MyR3alPass\n")
    assert ids(found) == ["CONFIG_PLAINTEXT_SECRET"]
    assert "MyR3alPass" not in found[0]["evidence"] and "<REDACTED>" in found[0]["evidence"]
    assert check("src/main/resources/application.properties", "spring.datasource.password=${DB_PASSWORD}\n") == []
    assert check("config/application.yml.example", "password: realLookingValue\n") == []   # example files skipped


def test_docker_rules():
    assert "DOCKER_NO_USER" in ids(check("Dockerfile", "FROM eclipse-temurin:17-jre\nCOPY app.jar /app.jar\n"))
    assert "DOCKER_NO_USER" not in ids(check("Dockerfile", "FROM eclipse-temurin:17-jre\nUSER app\n"))
    assert "DOCKER_NO_USER" in ids(check("Dockerfile", "FROM eclipse-temurin:17-jre\nUSER root\n"))
    assert "DOCKER_UNPINNED_IMAGE" in ids(check("Dockerfile", "FROM openjdk\nUSER app\n"))


# ---------------------------------------------------------------- access control
CONTROLLER = """@RestController
@RequestMapping("/api/projects")
public class ProjectController {
    private final ProjectService service;

    @GetMapping("/{projectId}")
    public ResponseEntity<Project> get(@PathVariable Long projectId) {
        return ResponseEntity.ok(service.findById(projectId));
    }

    @PreAuthorize("hasRole('PM')")
    @DeleteMapping("/{id}")
    public void delete(@PathVariable("id") Long id) {
        service.delete(id);
    }

    @PostMapping
    public Project create(@RequestBody Project p) {
        return service.save(p);
    }

    @GetMapping("/mine/{id}")
    public Project mine(@PathVariable Long id, Principal principal) {
        return service.findForUser(id, principal.getName());
    }
}
"""


def test_endpoint_without_authorization():
    found = [f for f in check("ProjectController.java", CONTROLLER) if f["rule_id"] == "JAVA_ENDPOINT_NO_AUTHZ"]
    assert [f["line"] for f in found] == [17]                    # create(); delete() has @PreAuthorize
    secured = CONTROLLER.replace("@RestController", '@PreAuthorize("isAuthenticated()")\n@RestController')
    assert "JAVA_ENDPOINT_NO_AUTHZ" not in ids(check("ProjectController.java", secured))
    assert "JAVA_ENDPOINT_NO_AUTHZ" not in ids(check("ProjectService.java", CONTROLLER.replace("@RestController", "@Service")))


def test_idor_risk():
    found = [f for f in check("ProjectController.java", CONTROLLER) if f["rule_id"] == "JAVA_IDOR_RISK"]
    assert [f["line"] for f in found] == [7]                     # get(projectId) only
    # editing a different method does not report this one
    assert "JAVA_IDOR_RISK" not in ids(check("ProjectController.java", CONTROLLER, added={18}))


def test_xxe():
    assert "JAVA_XXE" in ids(check("X.java", "var f = DocumentBuilderFactory.newInstance();\n"))
    safe = ('var f = DocumentBuilderFactory.newInstance();\n'
            'f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);\n')
    assert "JAVA_XXE" not in ids(check("X.java", safe))


# ---------------------------------------------------------------- SQL injection (multi-line aware)
def sqlc(code):
    return [f for f in check("Repo.java", code) if f["rule_id"] == "JAVA_SQL_CONCAT"]


def test_sql_concat_single_and_multi_line():
    assert sqlc('String q = "SELECT * FROM users WHERE id = " + id;\n')
    multi = ('String q =\n    "SELECT * FROM employees WHERE last_name = \'"\n        + name\n'
             '        + "\' AND tan = \'"\n        + tan\n        + "\'";\n')
    found = sqlc(multi)
    assert len(found) == 1 and found[0]["line"] == 2           # reported once per query, at its start
    assert sqlc('"select id from S where a = 1 order by "\n + column;\n')               # ORDER BY injection
    assert sqlc('jdbc.update("DELETE FROM t WHERE name = \'" + req.getParameter("n") + "\'");\n')
    assert sqlc('em.createQuery("FROM User u WHERE u.name = \'" + name + "\'");\n')    # JPQL


def test_sql_concat_does_not_flag_safe_code():
    assert not sqlc('"SELECT * FROM t WHERE a = ? AND b ="\n + " ?";\n')                # placeholders only
    assert not sqlc('"SELECT * FROM " + TABLE_NAME + " WHERE id = ?";\n')                # constant
    assert not sqlc('post(url("JWT/kid/delete?token=" + token));\n')                     # not SQL
    assert not sqlc('log.info("Updating user " + id);\n')
    assert not sqlc('msg = "Please select a project from the list: " + name;\n')
    assert not sqlc('// String q = "SELECT * FROM t WHERE id = " + id;\n')               # comment
    assert not sqlc('char c = \'"\'; String q = "SELECT a FROM t WHERE id = ?";\n')     # char literal


def test_sql_concat_only_reported_when_the_query_was_changed():
    code = 'class A {\n  String q = "SELECT * FROM t WHERE id = " + id;\n  int x = 1;\n}\n'
    assert sqlc(code)
    assert not [f for f in check("Repo.java", code, added={3}) if f["rule_id"] == "JAVA_SQL_CONCAT"]


def test_java_import_lines_are_not_flagged():
    assert check("C.java", "import org.springframework.security.crypto.password.NoOpPasswordEncoder;\n") == []
    assert "JAVA_NOOP_PASSWORD_ENCODER" in ids(check("C.java", "return NoOpPasswordEncoder.getInstance();\n"))


def test_translation_files_are_not_treated_as_secrets():
    assert check("src/main/resources/i18n/messages_en.properties", "jwt-invalid-token=Invalid\n") == []
    assert check("src/main/resources/WebLabels.properties", "show-password=Show\n") == []
    assert check("app.properties", "reset-token=Click here to reset\n") == []             # value with spaces


def test_endpoint_that_checks_the_user_in_its_body_is_not_flagged():
    ctl = ("@RestController\npublic class C {\n    @PostMapping\n"
           "    public void save(@AuthenticationPrincipal User me, @RequestBody X x) {\n"
           "        service.save(x, me);\n    }\n    @PutMapping\n"
           "    public void edit(@RequestBody X x) {\n        accessService.checkAccess(x);\n    }\n}\n")
    assert "JAVA_ENDPOINT_NO_AUTHZ" not in ids(check("C.java", ctl))


def test_sql_evidence_shows_the_real_code_not_the_masked_copy():
    f = [x for x in check("a.sql", "UPDATE billing SET status = 'BILLED';\n") if x["rule_id"] == "SQL_UPDATE_NO_WHERE"][0]
    assert "'BILLED'" in f["evidence"]


# ---------------------------------------------------------------- v3: SQL text passed to execute(variable)
def raw(code):
    return [f["line"] for f in check("Repo.java", code) if f["rule_id"] == "JAVA_RAW_STATEMENT"]


def test_raw_statement_flags_a_caller_supplied_or_built_query():
    assert raw("void f(String query) {\n  Statement s = c.createStatement();\n  ResultSet r = s.executeQuery(query);\n}\n") == [3]
    assert raw("String q = base;\nq += extra;\nstmt.executeUpdate(q);\n") == [3]
    assert raw("void f(String sql) {\n  jdbcTemplate.execute(sql);\n}\n") == [2]


def test_raw_statement_stays_quiet_on_safe_or_non_jdbc_calls():
    assert raw("String q = \"SELECT password FROM t WHERE u = 'dave'\";\nResultSet r = statement.executeQuery(q);\n") == []   # only ever a literal
    assert raw('ResultSet r = ps.executeQuery();\ns.executeQuery("SELECT 1");\ns.execute(SELECT_ALL);\n') == []
    assert raw("commandExecutionService.execute(null, command, env);\nexecutor.execute(task);\n") == []                        # not JDBC
    assert raw("// statement.executeQuery(query);\n") == []


def test_jwt_expiry():
    assert "JAVA_JWT_NO_EXPIRY" in ids(check("A.java", "String t = Jwts.builder().setSubject(u).signWith(key).compact();\n"))
    assert "JAVA_JWT_NO_EXPIRY" not in ids(check("A.java", "String t = Jwts.builder().setSubject(u).setExpiration(d).signWith(key).compact();\n"))
    assert "JAVA_JWT_NO_EXPIRY" in ids(check("A.java", "String t = JWT.create().withSubject(u).sign(alg);\n"))
    assert "JAVA_JWT_NO_EXPIRY" not in ids(check("A.java", "String t = JWT.create().withSubject(u).withExpiresAt(d).sign(alg);\n"))


# ---------------------------------------------------------------- v3: MySQL procedures
PROC_TWO_DML = "CREATE PROCEDURE close_month(IN p INT)\nBEGIN\n  UPDATE a SET x = 1 WHERE id = p;\n  INSERT INTO b(id) VALUES (p);\nEND;\n"


def test_procedure_error_handler():
    assert "SQL_PROC_NO_HANDLER" in ids(check("p.sql", PROC_TWO_DML))
    handled = PROC_TWO_DML.replace("BEGIN\n", "BEGIN\n  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; END;\n")
    assert "SQL_PROC_NO_HANDLER" not in ids(check("p.sql", handled))
    one_dml = "CREATE PROCEDURE p()\nBEGIN\n  UPDATE a SET x = 1 WHERE id = 1;\nEND;\n"
    assert "SQL_PROC_NO_HANDLER" not in ids(check("p.sql", one_dml))          # a single statement is atomic


def test_dml_inside_a_procedure_loop():
    code = "CREATE PROCEDURE p()\nBEGIN\n  WHILE i < 10 DO\n    INSERT INTO t(a) VALUES (i);\n    SET i = i + 1;\n  END WHILE;\n  INSERT INTO t(a) VALUES (99);\nEND;\n"
    assert [f["line"] for f in check("p.sql", code) if f["rule_id"] == "SQL_DML_IN_LOOP"] == [4]
    assert "SQL_DML_IN_LOOP" not in ids(check("p.sql", "BEGIN\n  INSERT INTO t(a) SELECT a FROM s;\nEND;\n"))


# ---------------------------------------------------------------- v3: React / JavaScript
def test_effect_without_cleanup():
    leak = "useEffect(() => {\n  const id = setInterval(tick, 1000);\n}, []);\nuseEffect(() => {\n  window.addEventListener('resize', onResize);\n}, []);\n"
    assert [f["line"] for f in check("C.jsx", leak) if f["rule_id"] == "REACT_EFFECT_NO_CLEANUP"] == [1, 4]
    ok = ("useEffect(() => {\n  const id = setInterval(tick, 1000);\n  return () => clearInterval(id);\n}, []);\n"
          "useEffect(() => {\n  window.addEventListener('resize', f);\n  return function () { window.removeEventListener('resize', f); };\n}, []);\n")
    assert "REACT_EFFECT_NO_CLEANUP" not in ids(check("C.jsx", ok))


def test_async_function_error_handling():
    bad = "const load = async () => {\n  const r = await fetch(u);\n  setData(await r.json());\n};\n"
    assert "JS_ASYNC_NO_ERROR_HANDLING" in ids(check("C.jsx", bad))
    good = ("const a = async () => {\n  try { const r = await fetch(u); } catch (e) { log(e); }\n};\n"
            "const b = async () => {\n  await fetch(u).catch(() => {});\n};\n")
    assert "JS_ASYNC_NO_ERROR_HANDLING" not in ids(check("C.jsx", good))
    assert "JS_ASYNC_NO_ERROR_HANDLING" in ids(check("C.jsx", "class A {\n  async load() {\n    await api.get('/x');\n  }\n}\n"))


def test_postmessage_origin_check():
    assert "JS_POSTMESSAGE_NO_ORIGIN" in ids(check("C.js", "window.addEventListener('message', (e) => { run(e.data); });\n"))
    assert "JS_POSTMESSAGE_NO_ORIGIN" not in ids(check("C.js", "window.addEventListener('message', (e) => { if (e.origin !== OK) return; run(e.data); });\n"))


# ---------------------------------------------------------------- v3: new config / SQL line rules end to end
def test_config_rules_apply_to_properties_and_yaml():
    assert "CONFIG_DDL_AUTO_PROPS" in ids(check("src/main/resources/application.properties", "spring.jpa.hibernate.ddl-auto=update\n"))
    assert "CONFIG_DDL_AUTO_YAML" in ids(check("src/main/resources/application.yml", "spring:\n  jpa:\n    hibernate:\n      ddl-auto: create-drop\n"))
    assert "CONFIG_JDBC_SSL_OFF" in ids(check("application.yml", "url: jdbc:mysql://db/app?useSSL=false\n"))
    assert "CONFIG_SSL_DISABLED" in ids(check("application.properties", "server.ssl.enabled=false\n"))
    assert "CONFIG_DDL_AUTO_PROPS" not in ids(check("src/test/resources/application.properties", "spring.jpa.hibernate.ddl-auto=create-drop\n"))   # test config
