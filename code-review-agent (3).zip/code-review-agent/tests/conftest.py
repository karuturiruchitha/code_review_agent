import os
import subprocess
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

BASE_JAVA = """package demo;

public class UserRepository {

    public String findName(JdbcTemplate jdbc, int id) {
        return jdbc.queryForObject("SELECT name FROM users WHERE id = ?", String.class, id);
    }

    public int ratio(int a, int b) {
        return a * 100 / 1;
    }
}
"""

CHANGED_JAVA = """package demo;

public class UserRepository {

    private static final String DB_PASSWORD = "SuperSecret123";

    public String findName(JdbcTemplate jdbc, String id) {
        return jdbc.queryForObject("SELECT name FROM users WHERE id = " + id, String.class);
    }

    public int ratio(int a, int b) {
        return a * 100 / 1;
    }
}
"""


def git(repo, *args):
    subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True)


@pytest.fixture
def repo(tmp_path):
    r = tmp_path / "repo"
    r.mkdir()
    git(r, "init", "-q", "-b", "main")
    git(r, "config", "user.email", "t@example.com")
    git(r, "config", "user.name", "t")
    (r / "src").mkdir()
    (r / "src" / "UserRepository.java").write_text(BASE_JAVA)
    (r / "README.md").write_text("hello\n")
    git(r, "add", "-A")
    git(r, "commit", "-q", "-m", "base")
    git(r, "checkout", "-q", "-b", "feature")
    (r / "src" / "UserRepository.java").write_text(CHANGED_JAVA)
    (r / "README.md").write_text("hello world\n")
    (r / "package-lock.json").write_text('{"a": 1}\n')
    git(r, "add", "-A")
    git(r, "commit", "-q", "-m", "change")
    return r
