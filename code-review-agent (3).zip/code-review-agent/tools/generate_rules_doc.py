"""Generate docs/rules.md (rule catalogue) from rules/rules.yml and the multi-line checks. Run after changing rules.

    python tools/generate_rules_doc.py
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:] = [p for p in sys.path if os.path.abspath(p or ".") != _HERE]
sys.path.insert(0, os.path.dirname(_HERE))

from agent.config import REPO_ROOT, SEVERITY_ORDER  # noqa: E402
from agent.rules_engine import DEPENDENCY_RULES, OWASP_2025, STRUCTURAL_RULES, load_rules, owasp_label  # noqa: E402

# What people still look at in review, next to the automated rules, for each OWASP category.
REVIEWER_FOCUS = {
    "A01": "Ownership checks in the service layer, role design, and tenant or customer data separation.",
    "A02": "Server and proxy hardening, TLS settings, security headers, and per-environment profiles.",
    "A03": "Library versions beyond the built-in list are covered by the npm audit and Dependency-Check reports the agent reads.",
    "A04": "Key management and rotation, and the choice of which data to encrypt.",
    "A05": "Data that travels through several methods before it reaches a query.",
    "A06": "Design review: abuse cases, approval flows, rate limits and business rules.",
    "A07": "Session timeout, multi-factor sign-in, account lock-out and SSO configuration.",
    "A08": "Signed builds and artifacts, and who can change the pipeline.",
    "A09": "Which security events are logged and alerted on.",
    "A10": "Transaction boundaries and handling of partial failures across services.",
}
AREAS = [("Java / Spring Boot", ("java",)), ("React / JavaScript", ("js",)), ("MySQL scripts and procedures", ("sql",)),
         ("Configuration files", ("props", "yaml")), ("Docker and build files", ("docker", "xml", "json")),
         ("Python", ("py",))]


def _area(langs):
    for name, keys in AREAS:
        if any(l in keys for l in langs):
            return name
    return "Any file"


def build() -> str:
    rules = load_rules(os.path.join(REPO_ROOT, "rules", "rules.yml"))
    entries = [(r.id, _area(r.langs), r.severity, r.category, r.owasp, r.cwe, r.title, "line") for r in rules]
    entries += [(s.id, _area(s.langs), s.severity, s.category, s.owasp, s.cwe, s.title, "multi-line") for s in STRUCTURAL_RULES]
    entries.append(("SECRET_SCAN", "Any file", "high", "security", "A07", "CWE-798",
                    "Committed secret (keys, passwords, tokens, private keys)", "secret scan"))
    entries += [(rid, "pom.xml and reports", "varies", "security", "A03", "CWE-1395", title, "dependency")
                for rid, title in DEPENDENCY_RULES]
    total = len(entries)
    security = sum(1 for e in entries if e[3] == "security")

    out = ["# Code Review Agent: Rule Catalogue", "",
           f"The agent applies **{total} fixed rules** ({security} of them security rules). Security rules are mapped to the "
           "**OWASP Top 10:2025** and to **CWE** numbers. The same code always gives the same result: no AI and no tokens are used.", "",
           "Generated from the rule definitions by `tools/generate_rules_doc.py`, so it always matches the code.", "",
           "## Severity levels", "",
           "| Severity | Meaning | Typical handling |", "|---|---|---|",
           "| critical | Can be exploited directly, or a secret is exposed | Fix before merge; rotate any exposed secret |",
           "| high | A serious weakness | Fix before merge |",
           "| medium | Likely a real problem, depends on context | Fix, or document why it is acceptable |",
           "| low | Maintainability or lower risk | Optional |", "",
           "## Rule types", "",
           "| Type | Description |", "|---|---|",
           "| line | Evaluated on one changed line at a time |",
           "| multi-line | Reads a whole statement, method or file (for example a query built over several lines, or a web endpoint with its annotations) |",
           "| secret scan | Looks for keys, tokens and passwords in any text file; values are always hidden in output |",
           "| dependency | Known-vulnerable libraries from the built-in list and from `npm audit` / Dependency-Check reports |", "",
           "## Coverage by OWASP Top 10:2025", "",
           "| Category | Automated rules | Rules | Also handled in human review |", "|---|---|---|---|"]
    for code, name in OWASP_2025.items():
        ids = sorted(e[0] for e in entries if e[4] == code)
        listed = ", ".join(f"`{i}`" for i in ids) if ids else "Reviewed through design review"
        out.append(f"| **{code}:2025 {name}** | {len(ids) or '-'} | {listed} | {REVIEWER_FOCUS[code]} |")

    out += ["", "## Full catalogue", ""]
    order = {name: i for i, (name, _k) in enumerate(AREAS)}
    entries.sort(key=lambda e: (order.get(e[1], 99), -SEVERITY_ORDER.get(e[2], 4), e[0]))
    current = None
    for rid, area, sev, cat, owasp, cwe, title, kind in entries:
        if area != current:
            current = area
            out += ["", f"### {area}", "", "| Rule | Severity | Category | OWASP 2025 | CWE | What it detects | Type |",
                    "|---|---|---|---|---|---|---|"]
        out.append(f"| `{rid}` | {sev} | {cat} | {(owasp_label(owasp) if owasp else '-')} | {cwe or '-'} | {title} | {kind} |")

    out += ["", "## Suppressing, tuning and extending", "",
            "- **One place:** add `review-ignore: RULE_ID reason` in a comment (`//`, `--`, `#` or `<!-- -->`) on the line or the line above.",
            "- **A whole repository:** `.codereview.yml` can disable a rule, change its severity, or exclude folders.",
            "- **Test code:** security findings in test files are reported as low, never hidden.",
            "- **Adding a rule:** add it to `rules/rules.yml` with example lines that must match and example lines that must not; "
            "security rules also carry an OWASP category and a CWE number. The tests check the examples.", ""]
    return "\n".join(out)


if __name__ == "__main__":
    target = os.path.join(REPO_ROOT, "docs", "rules.md")
    with open(target, "w", encoding="utf-8") as fh:
        fh.write(build())
    print("wrote", target)
