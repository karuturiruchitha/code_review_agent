"""Turn a git diff into the set of changed lines per file."""
import re
import subprocess
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")


@dataclass
class Hunk:
    file: str
    new_start: int
    new_end: int
    added: List[Tuple[int, str]] = field(default_factory=list)   # (new-file line number, text)
    removed_at: List[int] = field(default_factory=list)          # new-file line where text was deleted

    @property
    def added_lines(self) -> int:
        return len(self.added)


def run_git_diff(repo_dir: str, target_ref: str) -> str:
    """Diff of the PR against its target branch, ignoring whitespace-only changes."""
    cmd = ["git", "-C", repo_dir, "-c", "core.quotepath=off", "diff", "--no-color",
           "-w", "--find-renames", "--diff-filter=d", f"{target_ref}...HEAD"]
    result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode != 0:
        raise RuntimeError(
            f"git diff failed: {result.stderr.strip()} "
            "(the pipeline needs 'fetchDepth: 0' so the target branch history is available)")
    return result.stdout


def resolve_target_ref(repo_dir: str, target_branch: str) -> str:
    """Turn 'refs/heads/main' / 'main' / 'origin/main' into a ref that exists locally."""
    name = target_branch
    for prefix in ("refs/heads/", "refs/remotes/origin/", "origin/"):
        if name.startswith(prefix):
            name = name[len(prefix):]
    candidates = [f"origin/{name}", name]

    def exists(ref: str) -> bool:
        return subprocess.run(["git", "-C", repo_dir, "rev-parse", "--verify", "--quiet", ref],
                              capture_output=True).returncode == 0

    for ref in candidates:
        if exists(ref):
            return ref
    subprocess.run(["git", "-C", repo_dir, "fetch", "--no-tags", "origin", name], capture_output=True)
    for ref in candidates:
        if exists(ref):
            return ref
    raise RuntimeError(f"Cannot find target branch '{target_branch}' locally or on origin")


def parse_diff(diff_text: str) -> List[Hunk]:
    hunks: List[Hunk] = []
    cur_file: Optional[str] = None
    in_hunk = False
    state = {"start": 0, "count": 0, "new_no": 0, "added": [], "removed": []}

    def flush() -> None:
        if cur_file and (state["added"] or state["removed"]):
            hunks.append(Hunk(file=cur_file, new_start=state["start"],
                              new_end=state["start"] + max(state["count"], 1) - 1,
                              added=list(state["added"]), removed_at=list(state["removed"])))
        state.update({"added": [], "removed": []})

    for line in diff_text.splitlines():
        if line.startswith("diff --git "):
            flush()
            in_hunk = False
            cur_file = None
            continue
        match = HUNK_RE.match(line)
        if not in_hunk:
            if line.startswith("+++ "):
                path = line[4:].rstrip("\t").strip()
                if path.startswith('"') and path.endswith('"'):
                    path = path[1:-1]
                cur_file = None if path == "/dev/null" else (path[2:] if path.startswith("b/") else path)
                continue
            if match and cur_file:
                in_hunk = True
        elif match:
            flush()
        else:
            match = None
        if match:
            state["start"] = int(match.group(3))
            state["count"] = int(match.group(4)) if match.group(4) is not None else 1
            state["new_no"] = state["start"]
            continue
        if not in_hunk or line.startswith("\\"):        # "\ No newline at end of file"
            continue
        kind = line[:1] if line[:1] in ("+", "-", " ") else " "
        if kind == "+":
            state["added"].append((state["new_no"], line[1:]))
            state["new_no"] += 1
        elif kind == "-":
            state["removed"].append(state["new_no"])
        else:
            state["new_no"] += 1
    flush()
    return hunks
