"""Dependency risk (OWASP A03, Software Supply Chain Failures). No AI, no network access.

Three sources, all offline:
  1. A SMALL list of famous, severe Java library vulnerabilities, every boundary checked against public advisories.
     It covers high-impact cases; complete coverage comes from the npm audit and Dependency-Check reports. Versions given as ${properties} in a pom are resolved.
  2. `npm audit --json`  : parsed (live advisory data comes from the tool, not from us).
  3. OWASP Dependency-Check JSON report: parsed (live NVD data comes from the tool, not from us).
"""
import json
import re
from typing import Dict, List, Optional, Set, Tuple

from agent.rules_engine import line_of, owasp_label

CWE_DEFAULT = "CWE-1395"       # Dependency on Vulnerable Third-Party Component
NPM_SEVERITY = {"critical": "critical", "high": "high", "moderate": "medium", "medium": "medium", "low": "low", "info": "low"}
DC_SEVERITY = {"CRITICAL": "critical", "HIGH": "high", "MEDIUM": "medium", "MODERATE": "medium", "LOW": "low"}


# ------------------------------------------------------------------ versions
def parse_version(text: str) -> Tuple[int, ...]:
    m = re.match(r"\s*v?(\d+(?:\.\d+)*)", text or "")
    return tuple(int(x) for x in m.group(1).split(".")) if m else ()


def _pad(v: Tuple[int, ...], n: int = 3) -> Tuple[int, ...]:
    return tuple(list(v) + [0] * n)[:max(n, len(v))]


def vlt(v: Tuple[int, ...], bound: Tuple[int, ...]) -> bool:
    n = max(len(v), len(bound), 3)
    return _pad(v, n) < _pad(bound, n)


def vge(v, bound) -> bool:
    return not vlt(v, bound)


# ------------------------------------------------------------------ the safety-net list (every boundary verified)
def _log4j(v):
    if not v or v[0] != 2 or vge(v, (2, 17, 1)):
        return None
    p = _pad(v)
    if p[:2] == (2, 3) and vge(v, (2, 3, 2)) or p[:2] == (2, 12) and vge(v, (2, 12, 4)):
        return None
    if vlt(v, (2, 15, 0)) and p not in ((2, 3, 1), (2, 12, 2), (2, 12, 3)):
        return ("critical", "Log4Shell (CVE-2021-44228): remote code execution", "2.17.1 (2.12.4 for Java 7, 2.3.2 for Java 6)")
    if p in ((2, 15, 0), (2, 16, 0)):
        return ("high", "Log4j follow-up flaws CVE-2021-45046 / CVE-2021-45105", "2.17.1")
    return ("medium", "Log4j CVE-2021-44832 (needs a writable configuration)", "2.17.1 (2.12.4 for Java 7, 2.3.2 for Java 6)")


def _spring_framework(v):
    if vlt(v, (5, 2, 20)) or (vge(v, (5, 3, 0)) and vlt(v, (5, 3, 18))):
        return ("critical", "Spring4Shell (CVE-2022-22965): remote code execution (needs JDK 9+ and a WAR on Tomcat to exploit)",
                "5.3.18 or later (5.2.20 on the 5.2 line)")


def _spring_boot(v):
    if vlt(v, (2, 5, 12)) or (vge(v, (2, 6, 0)) and vlt(v, (2, 6, 6))):
        return ("critical", "Spring Boot version bundles a Spring Framework vulnerable to Spring4Shell (CVE-2022-22965)",
                "2.5.12, 2.6.6 or later")


def _commons_text(v):
    if vge(v, (1, 5, 0)) and vlt(v, (1, 10, 0)):
        return ("critical", "Text4Shell (CVE-2022-42889): remote code execution through string interpolation", "1.10.0 or later")


def _snakeyaml(v):
    if vlt(v, (2, 0, 0)):
        return ("high", "SnakeYAML CVE-2022-1471: arbitrary code execution when parsing untrusted YAML with the default Constructor", "2.0 or later")


def _commons_collections3(v):
    if v and v[0] == 3 and vlt(v, (3, 2, 2)):
        return ("high", "Commons Collections deserialization gadget chain (CVE-2015-7501): remote code execution when untrusted Java objects are deserialized", "3.2.2 or later")


def _commons_collections4(v):
    if v and v[0] == 4 and vlt(v, (4, 1, 0)):
        return ("high", "Commons Collections 4.0 deserialization gadget chain (CVE-2015-7501)", "4.1 or later")


DENYLIST: List[Tuple[Set[Tuple[str, str]], object]] = [
    ({("org.apache.logging.log4j", "log4j-core")}, _log4j),
    ({("org.springframework", "spring-beans"), ("org.springframework", "spring-webmvc"),
      ("org.springframework", "spring-webflux")}, _spring_framework),
    ({("org.springframework.boot", "spring-boot-starter-web"), ("org.springframework.boot", "spring-boot-starter-webflux"),
      ("org.springframework.boot", "spring-boot-starter-parent")}, _spring_boot),
    ({("org.apache.commons", "commons-text")}, _commons_text),
    ({("org.yaml", "snakeyaml")}, _snakeyaml),
    ({("commons-collections", "commons-collections")}, _commons_collections3),
    ({("org.apache.commons", "commons-collections4")}, _commons_collections4),
]


def _finding(rule_id, title, severity, message, fix, file, line, evidence, cwe=CWE_DEFAULT, **extra) -> Dict:
    f = {"rule_id": rule_id, "title": title, "severity": severity, "category": "security", "message": message, "fix": fix,
         "file": file, "line": line, "evidence": evidence[:200], "owasp": "A03", "owasp_label": owasp_label("A03"),
         "cwe": cwe, "kind": "dependency"}
    f.update(extra)
    return f


# ------------------------------------------------------------------ pom.xml
def _pom_properties(content: str) -> Dict[str, Tuple[str, int]]:
    props: Dict[str, Tuple[str, int]] = {}
    block = re.search(r"<properties>(.*?)</properties>", content, re.S)
    if block:
        base = block.start(1)
        for m in re.finditer(r"<([\w.\-]+)>\s*([^<]*?)\s*</\1>", block.group(1)):
            props[m.group(1)] = (m.group(2), line_of(content, base + m.start()))
    return props


def analyze_pom(path: str, content: str, touched: Optional[Set[int]] = None) -> List[Dict]:
    """Known-vulnerable libraries in a pom.xml. If `touched` is given (pull-request mode), report only dependencies
    whose declaration, or whose version property, was changed."""
    out: List[Dict] = []
    props = _pom_properties(content)
    blocks = [(m, "dependency") for m in re.finditer(r"<dependency>(.*?)</dependency>", content, re.S)]
    blocks += [(m, "parent") for m in re.finditer(r"<parent>(.*?)</parent>", content, re.S)]
    for m, kind in blocks:
        body = m.group(1)
        tag = lambda name: (re.search(rf"<{name}>\s*([^<]+?)\s*</{name}>", body) or [None, None])[1]
        group, artifact, raw_version = tag("groupId"), tag("artifactId"), tag("version")
        if not (group and artifact and raw_version):
            continue
        first, last = line_of(content, m.start()), line_of(content, m.end())
        version, prop_line = raw_version, None
        pm = re.fullmatch(r"\$\{([^}]+)\}", raw_version)
        if pm:
            if pm.group(1) not in props:
                continue                                        # unresolvable: do not guess
            version, prop_line = props[pm.group(1)]
        for coords, check in DENYLIST:
            if (group, artifact) not in coords:
                continue
            verdict = check(parse_version(version))
            if not verdict:
                continue
            if touched is not None and not (any(n in touched for n in range(first, last + 1)) or (prop_line and prop_line in touched)):
                continue
            severity, why, fix = verdict
            scope = (tag("scope") or "").lower()
            title = f"{artifact} {version}: known vulnerability"
            if scope == "test" and kind == "dependency":
                severity, title = "low", title + " (test scope)"
            ver_line = line_of(content, m.start(1) + body.find("<version>")) if "<version>" in body else first
            out.append(_finding("DEP_VULNERABLE_LIBRARY", title, severity, why, f"Upgrade to {fix}.", path,
                                ver_line, f"{group}:{artifact}:{version}", package=artifact, version=version))
    return out


# ------------------------------------------------------------------ npm audit (JSON from `npm audit --json`)
def _line_of_key(manifest_text: Optional[str], name: str) -> int:
    if manifest_text:
        m = re.search(r'"' + re.escape(name) + r'"\s*:', manifest_text)
        if m:
            return line_of(manifest_text, m.start())
    return 1


def parse_npm_audit(json_text: str, manifest: str = "package.json", manifest_text: Optional[str] = None) -> List[Dict]:
    data = json.loads(json_text)
    out: List[Dict] = []
    if isinstance(data.get("vulnerabilities"), dict):                   # npm 7+ (auditReportVersion 2)
        for name, v in data["vulnerabilities"].items():
            advisories = [x for x in v.get("via", []) if isinstance(x, dict)]
            indirect = [x for x in v.get("via", []) if isinstance(x, str)]
            severity = NPM_SEVERITY.get(str(v.get("severity", "")).lower(), "medium")
            titles = list(dict.fromkeys(a.get("title", "").strip() for a in advisories if a.get("title")))[:3]
            if not titles:
                titles = [f"vulnerable through {', '.join(indirect[:3])}"]
            cwes = [c for a in advisories for c in (a.get("cwe") or [])]
            urls = list(dict.fromkeys(a["url"] for a in advisories if a.get("url")))[:2]
            fix_info = v.get("fixAvailable")
            if isinstance(fix_info, dict):
                fix = f"Upgrade {fix_info.get('name', name)} to {fix_info.get('version', 'the fixed version')}" + \
                      (" (major version change)." if fix_info.get("isSemVerMajor") else ".")
            elif fix_info:
                fix = "Run npm audit fix."
            else:
                fix = "No automatic fix is available: replace the package or check the advisory for a workaround."
            direct = "direct dependency" if v.get("isDirect") else "indirect dependency"
            out.append(_finding("DEP_NPM_AUDIT", f"{name}: {titles[0]}", severity,
                                f"{direct}; {'; '.join(titles)}." + (f" Advisories: {', '.join(urls)}" if urls else ""),
                                fix, manifest, _line_of_key(manifest_text, name), f"{name}@{v.get('range', '*')}",
                                cwe=(cwes[0] if cwes else CWE_DEFAULT), package=name))
    elif isinstance(data.get("advisories"), dict):                      # npm 6
        for adv in data["advisories"].values():
            name = adv.get("module_name", "unknown")
            out.append(_finding("DEP_NPM_AUDIT", f"{name}: {adv.get('title', 'vulnerability')}",
                                NPM_SEVERITY.get(str(adv.get("severity", "")).lower(), "medium"),
                                f"Vulnerable versions: {adv.get('vulnerable_versions', '?')}. {adv.get('url', '')}".strip(),
                                f"Upgrade to {adv.get('patched_versions') or 'a patched version'}.", manifest,
                                _line_of_key(manifest_text, name), f"{name}@{adv.get('vulnerable_versions', '*')}",
                                cwe=(adv.get("cwe") or CWE_DEFAULT), package=name))
    return out


# ------------------------------------------------------------------ OWASP Dependency-Check (JSON report)
def parse_dependency_check(json_text: str, manifest: str = "pom.xml") -> List[Dict]:
    data = json.loads(json_text)
    out: List[Dict] = []
    for dep in data.get("dependencies", []) or []:
        vulns = dep.get("vulnerabilities") or []
        if not vulns:
            continue
        rank = ["low", "medium", "high", "critical"]
        sev_of = lambda v: DC_SEVERITY.get(str(v.get("severity", "")).upper(), "low")
        top = max(vulns, key=lambda v: rank.index(sev_of(v)))
        name = dep.get("fileName") or dep.get("filePath") or "unknown dependency"
        ids = list(dict.fromkeys(v.get("name", "?") for v in vulns))
        cwes = [c for v in vulns for c in (v.get("cwes") or [])]
        score = (top.get("cvssv3") or {}).get("baseScore")
        desc = " ".join(str(top.get("description", "")).split())[:300]
        shown = ", ".join(ids[:5]) + (f" (+{len(ids) - 5} more)" if len(ids) > 5 else "")
        out.append(_finding("DEP_CHECK", f"{name}: {len(ids)} known vulnerabilit{'y' if len(ids) == 1 else 'ies'} ({shown})",
                            sev_of(top), (f"CVSS {score}. " if score is not None else "") + desc,
                            f"Upgrade or remove {name}; details for each CVE are in the Dependency-Check report.",
                            manifest, 1, f"{name}: {shown}", cwe=(cwes[0] if cwes else CWE_DEFAULT), package=name))
    return out
