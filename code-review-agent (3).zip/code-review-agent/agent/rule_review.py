"""Code review agent: fixed rules, NO AI, NO tokens, NO API key.

Two ways to run it:
  * pull-request review (default): checks only the lines the PR changed, posts ONE comment on the PR
  * full scan (--all-files): checks every file of the repository and writes HTML / JSON / SARIF reports

Around both: per-repository settings (.codereview.yml), baseline (accept existing findings, report only new ones),
dependency checks, inline comments (opt-in), pass/fail threshold, kill switch. Security rules are mapped to the
OWASP Top 10:2025 and CWE. Results are identical on every run and no code leaves the build agent.

Design rules:
  * FAIL OPEN: if this tool itself fails, the PR is never blocked because of it.
  * ADVISORY by default: only --fail-on <severity> can fail the build.
"""
import argparse
import os
import sys
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:] = [p for p in sys.path if os.path.abspath(p or ".") != _HERE]
sys.path.insert(0, os.path.dirname(_HERE))

from agent import baseline as baseline_mod  # noqa: E402
from agent import dependencies as deps  # noqa: E402
from agent import reports  # noqa: E402
from agent.azure_devops import INLINE_MARKER, AzureDevOps  # noqa: E402
from agent.config import REPO_ROOT, SEVERITY_ORDER, TEST_PATH_RE, load_config  # noqa: E402
from agent.reports import RULE_MARKER  # noqa: E402,F401  (re-exported)
from agent.rules_engine import (DEPENDENCY_RULE_IDS, all_rule_ids, analyze_file, is_ignored,  # noqa: E402
                                language_of, load_rules, owasp_label)
from agent.scan import FileScan, is_skipped, read_text, scan_all_files, scan_pull_request  # noqa: E402
from agent.scoring import compute_score  # noqa: E402
from agent.secret_scan import scan_added_lines  # noqa: E402
from agent.settings import Settings, load_settings  # noqa: E402

DEFAULT_RULES_FILE = os.path.join(REPO_ROOT, "rules", "rules.yml")
MANIFEST_NAMES = ("pom.xml", "package.json", "package-lock.json", "build.gradle", "yarn.lock", "pnpm-lock.yaml")


def warn(message: str) -> None:
    if os.getenv("TF_BUILD"):
        print(f"##vso[task.logissue type=warning;]{message}", flush=True)
    else:
        print(f"WARNING: {message}", flush=True)


def _resolve(path: Optional[str], repo_dir: str) -> Optional[str]:
    if not path:
        return None
    return path if os.path.isabs(path) else os.path.join(repo_dir, path)


# ------------------------------------------------------------------------------------------ analysis
def analyze_scans(repo_dir: str, scans: List[FileScan], cfg, rules, disabled: FrozenSet[str],
                  pr_mode: bool) -> Tuple[List[Dict], int, Dict[str, str]]:
    """Run the rules over the selected lines. Returns (findings, files_checked, {path: content} for the files read)."""
    findings: List[Dict] = []
    checked = 0
    contents: Dict[str, str] = {}
    for scan in sorted(scans, key=lambda s: s.path):
        if is_skipped(scan.path, cfg.skip_patterns):
            continue
        content = read_text(repo_dir, scan.path)
        if content is None:
            continue
        contents[scan.path] = content
        lines = content.splitlines()
        if scan.added is None:                                   # full scan: every line counts as changed
            added_set = set(range(1, len(lines) + 1))
            touched = added_set
            added_items = list(enumerate(lines, 1))
        else:
            added_set, touched = set(scan.added), scan.touched
            added_items = sorted(scan.added.items())
        try:
            if language_of(scan.path):
                checked += 1
                for f in analyze_file(scan.path, content, added_set, touched, rules, disabled):
                    f["on_added_line"] = f["line"] in added_set
                    findings.append(f)
            # Secrets can be in ANY text file (yml, properties, env files), not only in code files.
            if "SECRET_SCAN" not in disabled:
                for f in scan_added_lines(scan.path, added_items):
                    if not is_ignored(lines, f["line"], "SECRET_SCAN"):
                        findings.append({"rule_id": "SECRET_SCAN", "title": f["title"], "severity": f["severity"],
                                         "category": "security", "message": f["scenario"], "fix": f["fix"],
                                         "file": scan.path, "line": f["line"], "evidence": f["evidence"],
                                         "owasp": "A07", "owasp_label": owasp_label("A07"), "cwe": "CWE-798",
                                         "on_added_line": True})
        except Exception as exc:                                 # one odd file must not stop the review
            warn(f"Code review skipped {scan.path}: {exc}")
    return findings, checked, contents


def dependency_findings(repo_dir: str, scans: List[FileScan], contents: Dict[str, str], changed_paths: Set[str],
                        pr_mode: bool, settings: Settings, npm_audit: Optional[str], dep_check: Optional[str],
                        warnings: List[str]) -> List[Dict]:
    out: List[Dict] = []
    # 1) the built-in list, for every pom.xml in scope. In PR mode only dependencies whose lines changed.
    for scan in scans:
        if os.path.basename(scan.path) != "pom.xml":
            continue
        content = contents.get(scan.path) or read_text(repo_dir, scan.path)
        if content is None:
            continue
        try:
            found = deps.analyze_pom(scan.path, content, scan.touched if pr_mode else None)
        except Exception as exc:
            warnings.append(f"dependency check skipped {scan.path}: {exc}")
            continue
        lines = content.splitlines()
        out.extend(f for f in found if not is_ignored(lines, f["line"], f["rule_id"]))

    def manifest_changed(manifest: str, siblings: Tuple[str, ...]) -> bool:
        """Did the PR change the manifest (or its lock file) that the report belongs to?"""
        base = os.path.dirname(manifest)
        return any(os.path.join(base, name).replace(os.sep, "/") in changed_paths for name in siblings)

    # 2) tool reports: the tools hold the live advisory data; we only read what they wrote
    for path, kind, manifest, siblings in (
            (npm_audit, "npm", settings.npm_audit_manifest, ("package.json", "package-lock.json")),
            (dep_check, "dc", settings.dependency_check_manifest, ("pom.xml", "build.gradle"))):
        if not path:
            continue
        full = _resolve(path, repo_dir)
        if not os.path.isfile(full):
            warnings.append(f"dependency report not found: {path} (run the audit step before the review)")
            continue
        if pr_mode and not manifest_changed(manifest, siblings):
            continue                                              # unrelated PR: do not bring old dependency findings
        try:
            text = open(full, "r", encoding="utf-8").read()
            if kind == "npm":
                out.extend(deps.parse_npm_audit(text, manifest, read_text(repo_dir, manifest)))
            else:
                out.extend(deps.parse_dependency_check(text, manifest))
        except (OSError, ValueError) as exc:
            warnings.append(f"could not read dependency report {path}: {str(exc).splitlines()[0]}")
    return out


def finalize(findings: List[Dict], settings: Settings, disabled: FrozenSet[str]) -> List[Dict]:
    """Apply settings (exclude paths, disabled rules, severity overrides), test-code handling and de-duplication."""
    test_re = [__import__("re").compile(__import__("fnmatch").translate(p)) for p in settings.test_paths]
    kept = []
    for f in findings:
        if f["rule_id"] in disabled or is_skipped(f["file"], settings.exclude_paths):
            continue
        # Security findings in test code are shown, but as low: test fixtures rarely reach production.
        is_test = TEST_PATH_RE.search(f["file"]) or any(r.match(f["file"]) for r in test_re)
        if f["category"] == "security" and is_test and f["severity"] != "low" and f.get("kind") != "dependency":
            f["severity"] = "low"
            f["title"] += " (test code)"
        if f["rule_id"] in settings.severity:                    # an explicit decision of the team always wins
            f["severity"] = settings.severity[f["rule_id"]]
        kept.append(f)
    unique: Dict[Tuple, Dict] = {}
    for f in kept:
        unique.setdefault((f["file"], f["line"], f["rule_id"], f["title"] if f.get("kind") == "dependency" else ""), f)
    return sorted(unique.values(), key=lambda f: (-SEVERITY_ORDER[f["severity"]], f["file"], f["line"]))


# ------------------------------------------------------------------------------------------ output
def post_inline_comments(ado: AzureDevOps, findings: List[Dict], settings: Settings) -> int:
    floor = SEVERITY_ORDER[settings.inline_min_severity]
    candidates = [f for f in findings if f.get("on_added_line") and f.get("kind") != "dependency"
                  and SEVERITY_ORDER[f["severity"]] >= floor][:settings.inline_max]
    if not candidates:
        return 0
    already = ado.inline_fingerprints()
    posted = 0
    for f in candidates:
        if f["fingerprint"] in already:
            continue
        body = (f"{INLINE_MARKER} fp={f['fingerprint']} -->\n**{f['severity'].upper()} · {f['rule_id']}**: {f['title']}\n\n"
                f"{f['message']}\n\n**Fix:** {f['fix']}\n\n_To suppress a false alarm: `review-ignore: {f['rule_id']} reason`._")
        ado.create_inline_thread(f["file"], f["line"], body)
        posted += 1
    return posted


def write_reports(out_dir: str, findings: List[Dict], ctx: Dict, comment_text: str) -> None:
    os.makedirs(out_dir, exist_ok=True)
    files = {"rule_review_report.json": reports.to_json(findings, ctx),
             "rule_review_report.md": comment_text,
             "rule_review_report.html": reports.render_html(findings, ctx),
             "rule_review.sarif": __import__("json").dumps(reports.to_sarif(findings, ctx), indent=1)}
    for name, text in files.items():
        with open(os.path.join(out_dir, name), "w", encoding="utf-8") as fh:
            fh.write(text)


# ------------------------------------------------------------------------------------------ main flow
def run(repo_dir: str = ".", target_branch: Optional[str] = None, rules_file: str = DEFAULT_RULES_FILE,
        dry_run: bool = False, fail_on: Optional[str] = None, disabled: FrozenSet[str] = frozenset(),
        ado: Optional[AzureDevOps] = None, env=None, all_files: bool = False, baseline: Optional[str] = None,
        write_baseline: Optional[str] = None, report_dir: Optional[str] = None, npm_audit: Optional[str] = None,
        dependency_check: Optional[str] = None, config_path: Optional[str] = None,
        inline: Optional[bool] = None) -> int:
    env = env if env is not None else os.environ
    if env.get("RULE_REVIEW_ENABLED", "true").strip().lower() in ("0", "false", "no", "off"):
        print("Code review is disabled (RULE_REVIEW_ENABLED=false).")
        return 0
    cfg = load_config()
    pr_mode = not all_files
    if dry_run or not pr_mode:
        ado = None
    elif ado is None and AzureDevOps.available(env):
        ado = AzureDevOps(env, marker=RULE_MARKER)

    # ---- pull-request context: skip drafts, skip a commit that was already reviewed
    source_sha: Optional[str] = None
    if ado is not None:
        try:
            pr = ado.get_pr()
            source_sha = (pr.get("lastMergeSourceCommit") or {}).get("commitId")
            target_branch = target_branch or pr.get("targetRefName")
            if cfg.skip_drafts and pr.get("isDraft"):
                print("Draft PR: skipping.")
                return 0
            existing = ado.find_comment()
            if existing and source_sha and f"sha={source_sha}" in existing["content"]:
                print(f"Commit {source_sha[:8]} already checked: skipping.")
                return 0
        except Exception as exc:
            warn(f"Could not read PR details: {exc}")
    target_branch = target_branch or env.get("SYSTEM_PULLREQUEST_TARGETBRANCH") or "main"

    # ---- analysis (any internal failure fails OPEN)
    try:
        rules = load_rules(rules_file)
        known_ids = frozenset(all_rule_ids(rules))
        settings = load_settings(repo_dir, config_path, known_ids)
        warnings: List[str] = list(settings.warnings)
        for w in warnings:
            warn(w)
        fail_on = fail_on or env.get("RULE_FAIL_ON") or settings.fail_on or "none"
        all_disabled = frozenset(disabled) | settings.disable
        scans, changed_paths = scan_all_files(repo_dir) if all_files else scan_pull_request(repo_dir, target_branch)
        findings, files_checked, contents = analyze_scans(repo_dir, scans, cfg, rules, all_disabled, pr_mode)
        findings += dependency_findings(
            repo_dir, scans, contents, changed_paths, pr_mode, settings,
            npm_audit or env.get("NPM_AUDIT_REPORT") or settings.npm_audit,
            dependency_check or env.get("DEPENDENCY_CHECK_REPORT") or settings.dependency_check, warnings)
        findings = finalize(findings, settings, all_disabled)
        baseline_suppressed = 0
        if write_baseline:
            count = baseline_mod.write_baseline(_resolve(write_baseline, repo_dir), findings)
            print(f"Baseline written: {count} finding(s) accepted in {write_baseline}")
            return 0
        baseline_path = _resolve(baseline or settings.baseline, repo_dir)
        if baseline_path:
            accepted = baseline_mod.load_baseline(baseline_path)
            if accepted is None:
                warnings.append(f"baseline file not found or unreadable: {baseline or settings.baseline}; all findings are shown")
            else:
                findings, baseline_suppressed = baseline_mod.apply_baseline(findings, accepted)
        baseline_mod.assign_fingerprints(findings)
    except Exception as exc:
        warn(f"Code review could not run: {exc}")
        return 0

    rule_count = len(all_rule_ids(rules))
    ctx = {"mode": "pull_request" if pr_mode else "full_scan",
           "mode_label": "Pull request review" if pr_mode else "Full repository scan",
           "files_checked": files_checked, "rule_count": rule_count, "source_sha": source_sha, "fail_on": fail_on,
           "baseline_suppressed": baseline_suppressed, "warnings": warnings,
           "score": compute_score(findings) if not pr_mode else None}
    text = reports.render_pr_comment(findings, ctx) if pr_mode else reports.render_full_markdown(findings, ctx)

    # ---- stale-run check, then post / print
    if ado is not None and source_sha:
        try:
            if ado.current_source_commit() != source_sha:
                print("PR has a newer commit: a newer run will check it. Stopping.")
                return 0
        except Exception:
            pass
    if ado is None:
        print(text, flush=True)
    else:
        try:
            ado.upsert_comment(text)
        except Exception as exc:
            warn(f"Could not post the PR comment: {exc}")
            print(text, flush=True)
        if inline if inline is not None else (settings.inline_enabled or env.get("INLINE_COMMENTS", "").lower() in ("1", "true", "yes")):
            try:
                n = post_inline_comments(ado, findings, settings)
                print(f"Inline comments posted: {n}", flush=True)
            except Exception as exc:
                warn(f"Could not post inline comments: {exc}")

    try:
        write_reports(report_dir or env.get("OUTPUT_DIR", cfg.output_dir), findings, ctx, text)
    except OSError as exc:
        warn(f"Could not write report files: {exc}")

    print(f"Done. mode={ctx['mode']} findings={len(findings)} files_checked={files_checked} rules={rule_count} "
          f"baseline_suppressed={baseline_suppressed} tokens_used=0", flush=True)
    if fail_on != "none":
        floor = SEVERITY_ORDER[fail_on]
        blocking = [f for f in findings if SEVERITY_ORDER[f["severity"]] >= floor]
        if blocking:
            warn(f"{len(blocking)} finding(s) at '{fail_on}' or above: failing the build as configured.")
            return 1
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Code review agent: fixed rules, no AI, no tokens")
    p.add_argument("--repo-dir", default=".")
    p.add_argument("--target-branch", default=None, help="pull-request mode: branch to compare with")
    p.add_argument("--all-files", action="store_true", help="full scan of the whole repository instead of a PR diff")
    p.add_argument("--rules-file", default=os.getenv("RULES_FILE", DEFAULT_RULES_FILE))
    p.add_argument("--config", default=None, help="settings file (default: .codereview.yml in the repo)")
    p.add_argument("--fail-on", default=None, choices=["none", "low", "medium", "high", "critical"],
                   help="fail the run at this severity or above (default: none = advisory)")
    p.add_argument("--disable", default=os.getenv("RULES_DISABLE", ""), help="comma-separated rule ids to turn off")
    p.add_argument("--baseline", default=None, help="accept the findings recorded in this baseline file")
    p.add_argument("--write-baseline", default=None, help="record the current findings as the accepted baseline")
    p.add_argument("--report-dir", default=None, help="where to write the HTML / JSON / SARIF / Markdown reports")
    p.add_argument("--npm-audit", default=None, help="path to the output of 'npm audit --json'")
    p.add_argument("--dependency-check", default=None, help="path to an OWASP Dependency-Check JSON report")
    p.add_argument("--inline-comments", action="store_true", default=None, help="also post line-level PR comments")
    p.add_argument("--dry-run", action="store_true", help="print the review instead of posting it")
    a = p.parse_args(argv)
    disabled = frozenset(x.strip() for x in a.disable.split(",") if x.strip())
    return run(repo_dir=a.repo_dir, target_branch=a.target_branch, rules_file=a.rules_file, dry_run=a.dry_run,
               fail_on=a.fail_on, disabled=disabled, all_files=a.all_files, baseline=a.baseline,
               write_baseline=a.write_baseline, report_dir=a.report_dir, npm_audit=a.npm_audit,
               dependency_check=a.dependency_check, config_path=a.config, inline=a.inline_comments)


if __name__ == "__main__":
    sys.exit(main())
