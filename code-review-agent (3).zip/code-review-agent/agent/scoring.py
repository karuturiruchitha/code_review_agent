"""Deterministic, explainable score for a full-repository scan.

100 points minus a penalty per finding, but the penalty of any ONE rule is capped, so a single noisy style
rule cannot flatten a healthy project to an F. Same findings always give the same score.
"""
from collections import defaultdict
from typing import Dict, List

PENALTY = {"critical": 12.0, "high": 5.0, "medium": 2.0, "low": 0.5}
RULE_CAP = 20.0
GRADES = ((88, "A"), (75, "B"), (60, "C"), (45, "D"))
FORMULA = ("100 minus 12 per critical, 5 per high, 2 per medium, 0.5 per low finding; "
           f"the penalty of any single rule is capped at {RULE_CAP:g} points. "
           "Grades: A 88+, B 75+, C 60+, D 45+, otherwise F.")


def compute_score(findings: List[Dict]) -> Dict:
    per_rule: Dict[str, float] = defaultdict(float)
    for f in findings:
        per_rule[f["rule_id"]] += PENALTY.get(f["severity"], 0.0)
    capped = {rule: min(points, RULE_CAP) for rule, points in per_rule.items()}
    score = max(0, min(100, round(100 - sum(capped.values()))))
    grade = next((g for floor, g in GRADES if score >= floor), "F")
    top = sorted(capped.items(), key=lambda kv: -kv[1])[:5]
    return {"score": score, "grade": grade, "formula": FORMULA,
            "biggest_penalties": [{"rule_id": r, "points": round(p, 1), "capped": per_rule[r] > RULE_CAP} for r, p in top]}
