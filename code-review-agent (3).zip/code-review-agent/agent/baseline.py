"""Baseline: accept the findings that already exist, so only NEW problems are reported afterwards.

A finding's fingerprint is built from the rule, the file and the code text itself, NOT the line number,
so it survives edits above it. If the same text appears twice in a file, each occurrence is counted separately.
"""
import datetime
import hashlib
import json
import re
from typing import Dict, List, Optional, Tuple

BASELINE_VERSION = 1


def _normalise(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def assign_fingerprints(findings: List[Dict]) -> None:
    seen: Dict[str, int] = {}
    for f in findings:
        base = hashlib.sha1(f"{f['rule_id']}|{f['file']}|{_normalise(f.get('evidence', ''))}".encode("utf-8")).hexdigest()[:16]
        n = seen.get(base, 0)
        seen[base] = n + 1
        f["fingerprint"] = f"{base}-{n}"


def write_baseline(path: str, findings: List[Dict]) -> int:
    assign_fingerprints(findings)
    payload = {
        "version": BASELINE_VERSION, "tool": "code-review-agent",
        "created": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "count": len(findings),
        "findings": [{"fingerprint": f["fingerprint"], "rule_id": f["rule_id"], "file": f["file"], "line": f["line"],
                      "evidence": f.get("evidence", "")} for f in findings],
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=1, ensure_ascii=False)
    return len(findings)


def load_baseline(path: str) -> Optional[set]:
    """Return the set of accepted fingerprints, or None if the file is missing / unreadable."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return {item["fingerprint"] for item in data.get("findings", [])}
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return None


def apply_baseline(findings: List[Dict], accepted: set) -> Tuple[List[Dict], int]:
    assign_fingerprints(findings)
    fresh = [f for f in findings if f["fingerprint"] not in accepted]
    return fresh, len(findings) - len(fresh)
