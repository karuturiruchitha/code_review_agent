"""Deterministic rule engine: fixed checks, no model, no tokens, same result on every run.

Two kinds of rules:
  * line rules      - declared in rules/rules.yml (regex per changed line, with bad/good examples
                      that are checked by the test-suite, so a rule can't be added without proof)
  * structural rules - small Python checks for things a single-line regex can't see
                      (empty catch blocks, DB calls inside loops, React effects, SQL statements)

Findings are only reported on lines the pull request actually changed.
"""
import os
import re
from dataclasses import dataclass
from typing import Callable, Dict, FrozenSet, List, Optional, Set, Tuple

import yaml

from agent.config import SEVERITY_ORDER

LANG_OF = {".java": "java", ".js": "js", ".jsx": "js", ".ts": "js", ".tsx": "js",
           ".py": "py", ".sql": "sql", ".properties": "props", ".yml": "yaml", ".yaml": "yaml"}
COMMENT_PREFIXES = {"java": ("//", "/*", "*"), "js": ("//", "/*", "*"), "py": ("#",),
                    "sql": ("--", "/*", "*", "#"), "props": ("#", "!"), "yaml": ("#",),
                    "docker": ("#",), "xml": ("<!--",), "json": ()}

# OWASP Top 10:2025 (final, January 2026)
OWASP_2025 = {
    "A01": "Broken Access Control", "A02": "Security Misconfiguration",
    "A03": "Software Supply Chain Failures", "A04": "Cryptographic Failures", "A05": "Injection",
    "A06": "Insecure Design", "A07": "Authentication Failures",
    "A08": "Software or Data Integrity Failures", "A09": "Logging & Alerting Failures",
    "A10": "Mishandling of Exceptional Conditions",
}


def owasp_label(code: str) -> str:
    return f"{code}:2025 {OWASP_2025[code]}" if code in OWASP_2025 else ""


def language_of(path: str):
    """Which rule set applies to this file (None = not reviewed)."""
    name = os.path.basename(path.replace("\\", "/")).lower()
    ext = os.path.splitext(name)[1]
    if name == "dockerfile" or name.startswith("dockerfile.") or ext == ".dockerfile":
        return "docker"
    if name == "pom.xml":
        return "xml"
    if name == "package.json":
        return "json"
    if name == ".env" or name.startswith(".env.") or ext == ".env":
        return "props"
    return LANG_OF.get(ext)


MAX_LINE_LEN = 2000                      # skip minified / generated lines
IGNORE_RE = re.compile(r"review-ignore(?::\s*([A-Za-z0-9_,\s-]+))?")


# --------------------------------------------------------------------------- text helpers
def strip_trailing_comment(line: str, lang: str) -> str:
    """Cut a trailing comment, ignoring comment markers that sit inside string literals."""
    marker = {"java": "//", "js": "//", "py": "#", "sql": "--", "yaml": " #", "docker": " #"}.get(lang)
    if not marker:
        return line
    quote = None
    i = 0
    while i < len(line):
        c = line[i]
        if quote:
            if c == "\\":
                i += 2
                continue
            if c == quote:
                quote = None
        elif c in "\"'`":
            quote = c
        elif line.startswith(marker, i):
            return line[:i]
        i += 1
    return line


def balanced_end(text: str, open_idx: int) -> int:
    """Index of the bracket matching text[open_idx], skipping strings and comments. -1 if none."""
    open_ch = text[open_idx]
    close_ch = {"(": ")", "{": "}", "[": "]"}[open_ch]
    depth, i, n = 0, open_idx, len(text)
    while i < n:
        c = text[i]
        if c == "/" and text.startswith("//", i):
            j = text.find("\n", i)
            i = n if j == -1 else j
            continue
        if c == "/" and text.startswith("/*", i):
            j = text.find("*/", i + 2)
            if j == -1:
                return -1
            i = j + 2
            continue
        if c in "\"'`":
            quote = c
            i += 1
            while i < n and text[i] != quote:
                if text[i] == "\\":
                    i += 2
                    continue
                if quote != "`" and text[i] == "\n":
                    break                        # unterminated simple string (e.g. apostrophe in JSX text)
                i += 1
            i += 1
            continue
        if c == open_ch:
            depth += 1
        elif c == close_ch:
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def has_top_level_comma(inner: str) -> bool:
    """True if there is a comma outside any nested brackets/strings (e.g. useEffect's deps argument)."""
    depth, i, n = 0, 0, len(inner)
    while i < n:
        c = inner[i]
        if c == "/" and inner.startswith("//", i):
            j = inner.find("\n", i)
            i = n if j == -1 else j
            continue
        if c == "/" and inner.startswith("/*", i):
            j = inner.find("*/", i + 2)
            i = n if j == -1 else j + 2
            continue
        if c in "\"'`":
            quote = c
            i += 1
            while i < n and inner[i] != quote:
                if inner[i] == "\\":
                    i += 2
                    continue
                if quote != "`" and inner[i] == "\n":
                    break
                i += 1
            i += 1
            continue
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
        elif c == "," and depth == 0:
            return True
        i += 1
    return False


def line_of(text: str, idx: int) -> int:
    return text.count("\n", 0, idx) + 1


# --------------------------------------------------------------------------- line rules (YAML)
@dataclass(frozen=True)
class Rule:
    id: str
    title: str
    severity: str
    category: str
    langs: Tuple[str, ...]
    pattern: "re.Pattern"
    message: str
    fix: str
    exclude_paths: Tuple[str, ...] = ()
    scope: str = "code"              # "code" = trailing comment removed first, "raw" = whole line
    match_comments: bool = False
    bad: Tuple[str, ...] = ()
    good: Tuple[str, ...] = ()
    owasp: str = ""                  # e.g. "A05" (OWASP Top 10:2025)
    cwe: str = ""                    # e.g. "CWE-89"
    redact: bool = False             # hide the value after '=' / ':' in the evidence (secrets)

    def applies(self, lang: str, path: str) -> bool:
        if "any" not in self.langs and lang not in self.langs:
            return False
        norm = path.replace("\\", "/")
        return not any(re.search(p, norm) for p in self.exclude_paths)


def _lines(value) -> Tuple[str, ...]:
    return tuple(l for l in str(value or "").splitlines() if l.strip())


def load_rules(path: str) -> List[Rule]:
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    rules, seen = [], set()
    for raw in data.get("rules", []):
        rid = str(raw.get("id", "")).strip()
        if not rid or rid in seen:
            raise ValueError(f"rule id missing or duplicated: {rid!r}")
        seen.add(rid)
        for field_name in ("title", "severity", "category", "lang", "pattern", "message", "fix"):
            if not raw.get(field_name):
                raise ValueError(f"rule {rid}: missing '{field_name}'")
        if raw["severity"] not in SEVERITY_ORDER:
            raise ValueError(f"rule {rid}: invalid severity {raw['severity']!r}")
        try:
            pattern = re.compile(str(raw["pattern"]).strip())
        except re.error as exc:
            raise ValueError(f"rule {rid}: bad regex: {exc}") from exc
        langs = tuple(raw["lang"]) if isinstance(raw["lang"], list) else (raw["lang"],)
        rules.append(Rule(
            id=rid, title=str(raw["title"]).strip(), severity=raw["severity"],
            category=str(raw["category"]).strip(), langs=langs, pattern=pattern,
            message=" ".join(str(raw["message"]).split()), fix=" ".join(str(raw["fix"]).split()),
            exclude_paths=tuple(raw.get("exclude_paths", []) or []),
            scope=raw.get("scope", "code"), match_comments=bool(raw.get("match_comments", False)),
            bad=_lines(raw.get("bad")), good=_lines(raw.get("good")),
            owasp=str(raw.get("owasp", "") or "").strip(), cwe=str(raw.get("cwe", "") or "").strip(),
            redact=bool(raw.get("redact", False)),
        ))
        if rules[-1].owasp and rules[-1].owasp not in OWASP_2025:
            raise ValueError(f"rule {rid}: unknown OWASP category {rules[-1].owasp!r} (use A01..A10)")
    return rules


def line_rule_hits(rule: Rule, line: str, lang: str) -> bool:
    if len(line) > MAX_LINE_LEN:
        return False
    if lang == "java" and line.lstrip().startswith(("import ", "package ")):
        return False
    is_comment = line.strip().startswith(COMMENT_PREFIXES.get(lang, ()))
    if is_comment and not rule.match_comments:
        return False
    text = line if (rule.scope == "raw" or is_comment) else strip_trailing_comment(line, lang)
    return bool(rule.pattern.search(text))


# --------------------------------------------------------------------------- structural rules
@dataclass(frozen=True)
class StructuralRule:
    id: str
    title: str
    severity: str
    category: str
    langs: Tuple[str, ...]
    message: str
    fix: str
    check: Callable[[str], List[Tuple[int, int, str]]]   # content -> [(first_line, last_line, evidence)]
    owasp: str = ""
    cwe: str = ""


def _check_empty_catch(content: str):
    out = []
    for m in re.finditer(r"\bcatch\s*(?:\([^)]*\))?\s*\{\s*\}", content):
        out.append((line_of(content, m.start()), line_of(content, m.end()), m.group(0)[:80]))
    return out


def _check_empty_except_py(content: str):
    # Only BROAD catches: "except ImportError: pass" / "except StopIteration: pass" are normal Python idioms.
    pattern = r"^[ \t]*except(?:[ \t]+(?:Exception|BaseException)(?:[ \t]+as[ \t]+\w+)?)?[ \t]*:[ \t]*\n[ \t]+pass\b"
    return [(line_of(content, m.start()), line_of(content, m.end()), m.group(0).strip()[:80])
            for m in re.finditer(pattern, content, re.M)]


DB_CALL_RE = re.compile(
    r"\b(?:jdbcTemplate|jdbc|namedParameterJdbcTemplate|entityManager|em)\s*\.\s*"
    r"(?:query\w*|update|batchUpdate|execute|find\w*|persist|merge|createQuery|createNativeQuery)\s*\("
    r"|\b\w*(?i:repository|repo|dao)\s*\.\s*"
    r"(?:find\w*|get\w*|save\w*|delete\w*|count\w*|exists\w*|update\w*|insert\w*|select\w*)\s*\("
    r"|\.\s*(?:executeQuery|executeUpdate)\s*\("
    r"|\b(?:restTemplate|webClient|httpClient)\s*\.\s*\w+\s*\(")


def _check_db_in_loop(content: str):
    out, seen = [], set()
    for m in re.finditer(r"\b(?:for|while)\s*\(", content):
        paren = m.end() - 1
        close = balanced_end(content, paren)
        if close == -1:
            continue
        j = close + 1
        while j < len(content) and content[j] in " \t\r\n":
            j += 1
        if j >= len(content) or content[j] != "{":
            continue
        end = balanced_end(content, j)
        if end == -1:
            continue
        body_start = j
        for call in DB_CALL_RE.finditer(content, body_start, end):
            ln = line_of(content, call.start())
            if ln not in seen:
                seen.add(ln)
                out.append((ln, ln, content.splitlines()[ln - 1].strip()[:120]))
    return out


METHOD_SIG_RE = re.compile(
    r"^[ \t]*(?:(?:public|protected|private|static|final|synchronized|abstract|default)\s+)+"
    r"[\w<>\[\],.? ]+\s+(\w+)\s*\([^;{]*\)\s*(?:throws\s+[\w., ]+)?\s*\{", re.M)
MAX_METHOD_LINES = 80


def _check_long_method(content: str):
    out = []
    for m in METHOD_SIG_RE.finditer(content):
        open_idx = m.end() - 1
        end = balanced_end(content, open_idx)
        if end == -1:
            continue
        first, last = line_of(content, m.start()), line_of(content, end)
        if last - first + 1 > MAX_METHOD_LINES:
            out.append((first, last, f"{m.group(1)}(): {last - first + 1} lines"))
    return out


NETWORK_RE = re.compile(r"\bfetch\s*\(|\baxios\b|\bapi\w*\s*\.\s*(?:get|post|put|delete|patch)\s*\(", re.I)
CLEANUP_RE = re.compile(r"return\s*\(\s*\)\s*=>|return\s+function|return\s*\(\s*\)\s*\{|AbortController"
                        r"|\bignore\b|\bcancel(?:l)?ed\b|\bisMounted\b|\bmounted\b|\bactive\s*=\s*false")


def _use_effect_calls(content: str):
    for m in re.finditer(r"\buseEffect\s*\(", content):
        open_idx = m.end() - 1
        end = balanced_end(content, open_idx)
        if end != -1:
            yield open_idx, end, content[open_idx + 1:end]


def _check_effect_race(content: str):
    out = []
    for open_idx, end, inner in _use_effect_calls(content):
        if NETWORK_RE.search(inner) and not CLEANUP_RE.search(inner):
            out.append((line_of(content, open_idx), line_of(content, end), "useEffect(...) with a request and no cleanup"))
    return out


def _check_effect_no_deps(content: str):
    out = []
    for open_idx, end, inner in _use_effect_calls(content):
        if NETWORK_RE.search(inner) and not has_top_level_comma(inner):
            out.append((line_of(content, open_idx), line_of(content, end), "useEffect(...) without a dependency array"))
    return out


def _mask_sql(text: str) -> str:
    """Blank out comments and string contents (keeping offsets and newlines) so keywords inside them don't match."""
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if text.startswith("--", i) or (c == "#" and False):
            j = text.find("\n", i)
            j = n if j == -1 else j
            out.append(" " * (j - i))
            i = j
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            j = n if j == -1 else j + 2
            out.append("".join(ch if ch == "\n" else " " for ch in text[i:j]))
            i = j
        elif c in "'\"`":
            quote, j = c, i + 1
            while j < n and text[j] != quote:
                j += 2 if text[j] == "\\" else 1
            j = min(j + 1, n)
            out.append(quote + "".join(ch if ch == "\n" else " " for ch in text[i + 1:j - 1]) + quote)
            i = j
        else:
            out.append(c)
            i += 1
    return "".join(out)


_PREFIXES = [
    re.compile(r"^\s*DELIMITER[^\n]*\n", re.I),
    re.compile(r"^\s*CREATE\b(?:(?!\bBEGIN\b)[\s\S])*?\b(?:PROCEDURE|FUNCTION|TRIGGER|EVENT)\b[\s\S]*?\bBEGIN\b\s*", re.I),
    re.compile(r"^\s*(?:ELSEIF|IF)\b[\s\S]*?\bTHEN\b\s*", re.I),
    re.compile(r"^\s*(?:ELSE|BEGIN|LOOP|REPEAT|END\s+IF|END\s+LOOP)\b\s*", re.I),
    re.compile(r"^\s*WHILE\b[\s\S]*?\bDO\b\s*", re.I),
]


def _sql_statements(content: str):
    """Yield (first_line, last_line, statement_text) for each statement, unwrapping procedure bodies."""
    masked = _mask_sql(content)
    pos = 0
    for part in masked.split(";"):
        start, stmt = pos, part
        pos += len(part) + 1
        for _ in range(8):
            for rx in _PREFIXES:
                m = rx.match(stmt)
                if m and m.end() > 0:
                    start += m.end()
                    stmt = stmt[m.end():]
                    break
            else:
                break
        text = stmt.strip()
        if not text:
            continue
        offset = start + (len(stmt) - len(stmt.lstrip()))
        yield line_of(content, offset), line_of(content, offset + len(text)), text


def _evidence_line(content: str, line: int) -> str:
    lines = content.splitlines()
    return lines[line - 1].strip()[:120] if 1 <= line <= len(lines) else ""


def _check_update_no_where(content: str):
    return [(a, b, _evidence_line(content, a)) for a, b, t in _sql_statements(content)
            if re.match(r"UPDATE\b", t, re.I) and re.search(r"\bSET\b", t, re.I)
            and not re.search(r"\bWHERE\b|\bJOIN\b", t, re.I)]


def _check_delete_no_where(content: str):
    return [(a, b, _evidence_line(content, a)) for a, b, t in _sql_statements(content)
            if re.match(r"DELETE\b", t, re.I) and not re.search(r"\bWHERE\b|\bJOIN\b", t, re.I)]


def _check_drop_truncate(content: str):
    return [(a, b, _evidence_line(content, a)) for a, b, t in _sql_statements(content)
            if re.match(r"(?:DROP\s+(?!TEMPORARY\b)(?:TABLE|DATABASE|SCHEMA)\b|TRUNCATE\b)", t, re.I)
            and not re.search(r"\b(?:tmp|temp)_\w*", t, re.I)]


# ---- Java SQL built by string concatenation (follows the whole "+" chain across lines)
SQL_STATEMENT_RE = re.compile(
    r"(?is)\bselect\b.*?\bfrom\b|\binsert\s+into\b|\bupdate\s+[\w.`]+\s+set\b|\bdelete\s+from\b"
    r"|\bmerge\s+into\b|^\s*from\s+\w+(?:\s+\w+)?\s+where\b")
SQL_POSITION_RE = re.compile(
    r"(?i)(?:\bfrom|\bjoin|\bwhere|\band|\bor|=|<>|!=|<|>|\bin\s*\(|\blike|\bby|\blimit|\boffset"
    r"|\bvalues\s*\(|\bset|,|\(|\binto|\btable)\s*['\"%(]*\s*$")
CONSTANT_RE = re.compile(r"^(?:[A-Z][A-Z0-9_]*|\d[\d_.]*[lLfFdD]?|true|false|null)$")


def _mask_java(text: str) -> str:
    """Blank out comments and char literals (same length, newlines kept); string literals stay."""
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if text.startswith("//", i):
            j = text.find("\n", i)
            j = n if j == -1 else j
            out.append(" " * (j - i))
            i = j
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            j = n if j == -1 else j + 2
            out.append("".join(ch if ch == "\n" else " " for ch in text[i:j]))
            i = j
        elif c == '"':
            j = i + 1
            while j < n and text[j] not in '"\n':
                j += 2 if text[j] == "\\" else 1
            j = min(j + 1, n)
            out.append(text[i:j])
            i = j
        elif c == "'":
            m = re.match(r"'(?:[^'\\\n]|\\.){1,6}'", text[i:])
            if m:
                out.append(" " * len(m.group(0)))
                i += len(m.group(0))
            else:
                out.append(c)
                i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


_STR_RE = re.compile(r'"((?:[^"\\\n]|\\.)*)"')


def _operand_end(text: str, i: int) -> int:
    """End index of a non-literal operand starting at i (stops at a top-level + , ; ) or })."""
    depth, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == '"':
            m = _STR_RE.match(text, i)
            i = m.end() if m else i + 1
            continue
        if c in "([":
            depth += 1
        elif c in ")]":
            if depth == 0:
                return i
            depth -= 1
        elif depth == 0 and c in "+,;}?:":
            return i
        i += 1
    return n


def _check_sql_concat(content: str):
    text = _mask_java(content)
    out, n = [], len(text)
    for m in _STR_RE.finditer(text):
        k = m.start() - 1
        while k >= 0 and text[k] in " \t\r\n":
            k -= 1
        if k >= 0 and text[k] == "+":
            continue                                   # not the start of a chain
        literals, risky, pos = [m.group(1)], [], m.end()
        while True:
            j = pos
            while j < n and text[j] in " \t\r\n":
                j += 1
            if j >= n or text[j] != "+" or text.startswith("++", j) or text.startswith("+=", j):
                break
            j += 1
            while j < n and text[j] in " \t\r\n":
                j += 1
            lit = _STR_RE.match(text, j)
            if lit:
                literals.append(lit.group(1))
                pos = lit.end()
                continue
            end = _operand_end(text, j)
            operand = text[j:end].strip()
            if not operand:
                break
            if not CONSTANT_RE.match(operand) and SQL_POSITION_RE.search("".join(literals)):
                risky.append((j, operand))
            literals.append("\x00")                    # placeholder: keeps literal boundaries honest
            pos = end
        if risky and SQL_STATEMENT_RE.search("".join(literals).replace("\x00", " ")):
            first = line_of(content, m.start())
            last = line_of(content, pos)
            out.append((line_of(content, risky[0][0]), last, f'"{m.group(1)[:70]}" + {risky[0][1][:40]}'))
            out[-1] = (min(first, out[-1][0]), last, out[-1][2])
    return out


# ---- Spring controllers: authorization + IDOR
CONTROLLER_RE = re.compile(r"@(?:RestController|Controller)\b")
SECURITY_ANN_RE = re.compile(r"@(?:PreAuthorize|PostAuthorize|Secured|RolesAllowed|DenyAll)\b")
ANY_MAPPING_RE = re.compile(r"@(?:Get|Post|Put|Delete|Patch|Request)Mapping\b")
WRITE_MAPPING_RE = re.compile(r"@(?:Post|Put|Delete|Patch)Mapping\b|RequestMethod\.(?:POST|PUT|DELETE|PATCH)\b")
ID_PARAM_RE = re.compile(r"@(?:PathVariable|RequestParam)(?:\s*\([^)]*\))?\s+(?:final\s+)?[\w<>.]+\s+(\w*(?:id|Id|ID))\b")
OWNERSHIP_RE = re.compile(
    r"(?i)principal|authentication|SecurityContextHolder|currentUser|getCurrentUser|loggedInUser|"
    r"AuthenticationPrincipal|hasAccess|checkAccess|canAccess|isOwner|verifyAccess|verifyOwnership|"
    r"assertOwner|authorize|hasPermission|PreAuthorize|PostAuthorize|Secured|RolesAllowed")


def _controller_methods(content: str):
    """Yield (annotations_text, annotations_offset, signature_match, body_open, body_end) per method."""
    if not CONTROLLER_RE.search(content):
        return
    cls = re.search(r"\bclass\s+\w+[^{]*\{", content)
    if not cls:
        return
    class_secured = bool(SECURITY_ANN_RE.search(content[:cls.start()]))
    prev_end = cls.end()
    for m in METHOD_SIG_RE.finditer(content, cls.end()):
        if m.start() < prev_end:
            continue
        open_idx = m.end() - 1
        end = balanced_end(content, open_idx)
        if end == -1:
            continue
        yield class_secured, content[prev_end:m.start()], prev_end, m, open_idx, end
        prev_end = end + 1


def _check_endpoint_no_authz(content: str):
    out = []
    for class_secured, ann, ann_off, m, open_idx, end in _controller_methods(content):
        if class_secured:
            return []
        w = WRITE_MAPPING_RE.search(ann)
        if w and not SECURITY_ANN_RE.search(ann) and not OWNERSHIP_RE.search(m.group(0) + content[open_idx:end]):
            out.append((line_of(content, ann_off + w.start()), line_of(content, end),
                        f"{m.group(1)}(): data-changing endpoint without @PreAuthorize/@Secured"))
    return out


def _check_idor(content: str):
    out = []
    for class_secured, ann, ann_off, m, open_idx, end in _controller_methods(content):
        if class_secured or not ANY_MAPPING_RE.search(ann):
            continue
        ids = ID_PARAM_RE.findall(m.group(0))
        body = content[open_idx:end]
        used = [i for i in ids if re.search(rf"\b{re.escape(i)}\b", body)]
        if used and not OWNERSHIP_RE.search(ann + m.group(0) + body):
            out.append((line_of(content, m.start()), line_of(content, end),
                        f"{m.group(1)}({', '.join(used)}): record looked up by id with no ownership check"))
    return out


XML_FACTORY_RE = re.compile(r"\b(?:DocumentBuilderFactory|SAXParserFactory|XMLInputFactory|TransformerFactory|SchemaFactory)"
                            r"\s*\.\s*newInstance\s*\(")
XXE_GUARD_RE = re.compile(r"disallow-doctype-decl|FEATURE_SECURE_PROCESSING|ACCESS_EXTERNAL_DTD|ACCESS_EXTERNAL_SCHEMA|"
                          r"IS_SUPPORTING_EXTERNAL_ENTITIES|SUPPORT_DTD|external-general-entities|"
                          r"setExpandEntityReferences\s*\(\s*false")


def _check_xxe(content: str):
    if XXE_GUARD_RE.search(content):
        return []
    return [(line_of(content, m.start()), line_of(content, m.start()), m.group(0))
            for m in XML_FACTORY_RE.finditer(content)]


def _check_docker_user(content: str):
    if not re.search(r"(?im)^\s*FROM\s+", content):
        return []
    if re.search(r"(?im)^\s*USER\s+(?!root\b|0\b)\S+", content):
        return []
    return [(1, max(1, len(content.splitlines())), "no USER instruction: the container runs as root")]


# ---- Java: SQL text passed to execute*() as a variable (injection with no "+" in sight) ----
RAW_EXEC_RE = re.compile(r"([A-Za-z_]\w*)?\s*\.\s*(execute|executeQuery|executeUpdate|executeLargeUpdate)\s*\(\s*([A-Za-z_]\w*)\s*[,)]")
JDBC_RECEIVER_RE = re.compile(r"stat|stmt|jdbc|templ|sql|conn|^st$|^db", re.I)
PLAIN_LITERAL_RE = re.compile(r'\s*"(?:[^"\\\n]|\\.)*"\s*')


def _check_raw_statement(content: str):
    masked = _mask_java(content)
    out = []
    for m in RAW_EXEC_RE.finditer(masked):
        recv, meth, arg = m.group(1) or "", m.group(2), m.group(3)
        if re.fullmatch(r"[A-Z][A-Z0-9_]*", arg):                       # ALL_CAPS constant
            continue
        if meth == "execute" and not JDBC_RECEIVER_RE.search(recv):     # generic execute() on a non-JDBC object
            continue
        before = masked[max(0, m.start() - 6000):m.start()]
        assigns = list(re.finditer(r"\b" + re.escape(arg) + r"\s*(\+?=)\s*([^;]*);", before))
        if assigns and all(a.group(1) == "=" and PLAIN_LITERAL_RE.fullmatch(a.group(2)) for a in assigns):
            continue                                                    # only ever one plain string literal
        ln = line_of(content, m.start())
        out.append((ln, ln, _evidence_line(content, ln)))
    return out


def _check_jwt_no_expiry(content: str):
    out = []
    for m in re.finditer(r"\b(?:Jwts\s*\.\s*builder\s*\(\s*\)|JWT\s*\.\s*create\s*\(\s*\))", content):
        tail = content[m.start():m.start() + 1600]
        stop = re.search(r"\.\s*(?:compact|sign)\s*\(", tail)
        chain = tail[:stop.end() + 40] if stop else tail[:600]
        if not re.search(r'setExpiration|\.\s*expiration\s*\(|withExpiresAt|claim\s*\(\s*"exp"', chain):
            ln = line_of(content, m.start())
            out.append((ln, ln, m.group(0)))
    return out


# ---- MySQL stored procedures ----
def _procedure_units(content: str):
    masked = _mask_sql(content)
    starts = [m.start() for m in re.finditer(r"(?i)\bCREATE\s+(?:DEFINER\s*=\s*\S+\s+)?PROCEDURE\b", masked)]
    return [(line_of(content, s), masked[s:(starts[i + 1] if i + 1 < len(starts) else len(masked))])
            for i, s in enumerate(starts)]


def _check_proc_no_handler(content: str):
    out = []
    for line, text in _procedure_units(content):
        dml = len(re.findall(r"(?im)^\s*(?:INSERT|UPDATE|DELETE|REPLACE)\b", text))
        if dml >= 2 and not re.search(r"(?i)\bDECLARE\s+(?:EXIT|CONTINUE)\s+HANDLER\b", text):
            out.append((line, line, _evidence_line(content, line)))
    return out


def _check_dml_in_loop(content: str):
    out, depth = [], 0
    for i, ln in enumerate(_mask_sql(content).split("\n"), 1):
        if re.search(r"(?i)\bEND\s+(?:WHILE|REPEAT|LOOP)\b", ln):
            depth = max(0, depth - 1)
        elif re.match(r"(?i)^\s*(?:\w+\s*:\s*)?(?:WHILE\b[\s\S]*\bDO\b|REPEAT\b|LOOP\b)", ln):
            depth += 1
        elif depth > 0 and re.match(r"(?i)^\s*(?:INSERT|UPDATE|DELETE|REPLACE)\b", ln):
            out.append((i, i, _evidence_line(content, i)))
    return out


# ---- React / JavaScript ----
def _check_effect_no_cleanup(content: str):
    out = []
    for open_idx, end, inner in _use_effect_calls(content):
        if re.search(r"\bsetInterval\s*\(|\.addEventListener\s*\(|\.subscribe\s*\(", inner) and \
                not re.search(r"return\s*(?:\(\s*\)\s*=>|function\b|\(\s*\)\s*\{)", inner):
            out.append((line_of(content, open_idx), line_of(content, end),
                        "useEffect(...) starts a timer/listener with no cleanup"))
    return out


ASYNC_FORMS = [re.compile(r"\basync\b\s*(?:function\b\s*\w*\s*)?(?:\([^)]*\)|\w+)\s*(?:=>\s*)?\{"),
               re.compile(r"\basync\s+\w+\s*\([^)]*\)\s*\{")]


def _check_async_no_error_handling(content: str):
    out = []
    for form in ASYNC_FORMS:
        for m in form.finditer(content):
            open_idx = m.end() - 1
            end = balanced_end(content, open_idx)
            if end == -1:
                continue
            body = content[open_idx:end]
            if re.search(r"\bawait\b", body) and not re.search(r"\btry\s*\{", body) and not re.search(r"\.catch\s*\(", body):
                out.append((line_of(content, m.start()), line_of(content, end), m.group(0)[:60]))
    return out


def _check_postmessage(content: str):
    out = []
    for m in re.finditer(r"""addEventListener\s*\(\s*['"]message['"]""", content):
        if not re.search(r"\.origin\b", content[m.start():m.start() + 700]):
            ln = line_of(content, m.start())
            out.append((ln, ln, m.group(0)))
    return out


STRUCTURAL_RULES: List[StructuralRule] = [
    StructuralRule("EMPTY_CATCH", "Empty catch block swallows the error", "medium", "bug", ("java", "js"),
                   "The exception is caught and silently discarded, so failures become invisible and the code carries on in a bad state.",
                   "Log the error with context, or rethrow it. If ignoring is truly intended, add a comment saying why.",
                   _check_empty_catch, owasp="A10", cwe="CWE-390"),
    StructuralRule("PY_EMPTY_EXCEPT", "Broad except that only does 'pass'", "medium", "bug", ("py",),
                   "Any error at all is silently discarded, so real failures become invisible.",
                   "Catch the specific exception you expect, or log it. If ignoring is intended, say why in a comment.",
                   _check_empty_except_py, owasp="A10", cwe="CWE-390"),
    StructuralRule("JAVA_DB_CALL_IN_LOOP", "Database or remote call inside a loop (N+1)", "medium", "performance", ("java",),
                   "One database/remote round trip per iteration. With 1,000 items that is 1,000 calls, which slows the request and loads the server.",
                   "Fetch everything in one call before the loop (IN clause, join, or batch operation).",
                   _check_db_in_loop),
    StructuralRule("JAVA_LONG_METHOD", f"Method longer than {MAX_METHOD_LINES} lines", "low", "debt", ("java",),
                   "Very long methods are hard to read, test and change safely.",
                   "Split into smaller methods with clear names.", _check_long_method),
    StructuralRule("REACT_EFFECT_RACE", "Request in useEffect without cleanup (stale responses)", "medium", "bug", ("js",),
                   "If inputs change quickly, an older, slower response can arrive after a newer one and overwrite correct data.",
                   "Cancel with AbortController, or ignore stale results with a flag/request id set in the effect cleanup.",
                   _check_effect_race),
    StructuralRule("REACT_EFFECT_NO_DEPS", "useEffect with a request and no dependency array", "high", "bug", ("js",),
                   "Without a dependency array the effect runs after every render. If it updates state, this causes a request loop.",
                   "Add a dependency array listing exactly the values the effect uses (use [] to run once).",
                   _check_effect_no_deps),
    StructuralRule("SQL_UPDATE_NO_WHERE", "UPDATE without WHERE", "high", "bug", ("sql",),
                   "Every row in the table is updated. If this is not intended, it silently corrupts data.",
                   "Add a WHERE clause. If a full-table update is intended, add -- review-ignore: SQL_UPDATE_NO_WHERE <reason>.",
                   _check_update_no_where),
    StructuralRule("SQL_DELETE_NO_WHERE", "DELETE without WHERE", "high", "bug", ("sql",),
                   "Every row in the table is deleted.",
                   "Add a WHERE clause. If a full delete is intended, add -- review-ignore: SQL_DELETE_NO_WHERE <reason>.",
                   _check_delete_no_where),
    StructuralRule("SQL_DROP_TRUNCATE", "Destructive DROP / TRUNCATE", "medium", "bug", ("sql",),
                   "Removes a table or all of its data permanently.",
                   "Confirm a backup exists and this belongs in a migration, not a routine script.",
                   _check_drop_truncate),
    StructuralRule("JAVA_SQL_CONCAT", "SQL / JPQL built by string concatenation", "high", "security", ("java",),
                   "A query assembled from text and variables can be hijacked if any variable holds user input "
                   "(SQL injection). The check follows the whole + chain, including queries split over several lines.",
                   "Use placeholders (? or :name) and pass the values separately. For ORDER BY or table names, "
                   "map the input to an allow-list of fixed column names.",
                   _check_sql_concat, owasp="A05", cwe="CWE-89"),
    StructuralRule("JAVA_RAW_STATEMENT", "SQL text passed to execute() as a variable (no placeholders)", "medium", "security",
                   ("java",),
                   "A Statement / JdbcTemplate call runs whatever text the variable holds. If it contains user input there is "
                   "no '+' for the concatenation check to see and no placeholder protecting it.",
                   "Use PreparedStatement / JdbcTemplate with ? placeholders and pass values separately. If the variable can only "
                   "ever hold a fixed string, suppress with a comment saying so.",
                   _check_raw_statement, owasp="A05", cwe="CWE-89"),
    StructuralRule("JAVA_JWT_NO_EXPIRY", "JWT created without an expiry", "medium", "security", ("java",),
                   "A token that never expires stays valid forever if it leaks.",
                   "Set an expiration: Jwts.builder().setExpiration(...) (or .expiration(...), Auth0 withExpiresAt(...)). "
                   "Keep access tokens short-lived.",
                   _check_jwt_no_expiry, owasp="A07", cwe="CWE-613"),
    StructuralRule("SQL_PROC_NO_HANDLER", "Stored procedure changes data but has no error handler", "medium", "bug", ("sql",),
                   "A procedure with several INSERT/UPDATE/DELETE statements and no DECLARE ... HANDLER can fail half-way and "
                   "leave partly written data.",
                   "Add DECLARE EXIT HANDLER FOR SQLEXCEPTION (ROLLBACK; RESIGNAL) and run the statements inside "
                   "START TRANSACTION ... COMMIT.",
                   _check_proc_no_handler, owasp="A10", cwe="CWE-755"),
    StructuralRule("SQL_DML_IN_LOOP", "INSERT/UPDATE/DELETE inside a loop in a procedure", "low", "performance", ("sql",),
                   "One statement per row is the stored-procedure version of N+1 and is slow on large months or tables.",
                   "Replace the loop with one set-based statement (INSERT ... SELECT, UPDATE ... JOIN).",
                   _check_dml_in_loop),
    StructuralRule("REACT_EFFECT_NO_CLEANUP", "useEffect starts a timer, listener or subscription without cleanup", "medium",
                   "bug", ("js",),
                   "setInterval, addEventListener and subscribe keep running after the component is gone, so every visit to "
                   "the screen leaves another one behind: memory grows and handlers fire on dead components.",
                   "Return a cleanup function from the effect: clearInterval(id), removeEventListener(...), or unsubscribe().",
                   _check_effect_no_cleanup, owasp="A10", cwe="CWE-772"),
    StructuralRule("JS_ASYNC_NO_ERROR_HANDLING", "async function awaits with no try/catch or .catch()", "low", "bug", ("js",),
                   "A failed request becomes an unhandled promise rejection: nothing is shown to the user and nothing is logged.",
                   "Wrap the awaited calls in try/catch (or attach .catch()), then show an error state and log it.",
                   _check_async_no_error_handling, owasp="A10", cwe="CWE-248"),
    StructuralRule("JS_POSTMESSAGE_NO_ORIGIN", "postMessage handler does not check event.origin", "medium", "security", ("js",),
                   "Any website that can open or embed this page can send it messages, so a handler that trusts the data can "
                   "be driven by an attacker.",
                   "Compare event.origin with the exact expected origin before using event.data.",
                   _check_postmessage, owasp="A01", cwe="CWE-346"),
    StructuralRule("JAVA_ENDPOINT_NO_AUTHZ", "Data-changing endpoint without an authorization check", "medium", "security",
                   ("java",),
                   "Any logged-in user (or any caller, if the gateway is bypassed) can call this POST/PUT/DELETE/PATCH endpoint.",
                   "Add @PreAuthorize/@Secured with the required role or permission. If the check lives elsewhere "
                   "(gateway, service layer), add // review-ignore: JAVA_ENDPOINT_NO_AUTHZ <where it is checked>.",
                   _check_endpoint_no_authz, owasp="A01", cwe="CWE-862"),
    StructuralRule("JAVA_IDOR_RISK", "Record fetched by id with no ownership check (IDOR)", "medium", "security", ("java",),
                   "A user can change the id in the URL and read or change someone else's record (insecure direct object "
                   "reference).",
                   "Check that the current user may access this record (e.g. compare with the authenticated user, or "
                   "@PreAuthorize with a permission check). If the service layer checks it, suppress with that reason.",
                   _check_idor, owasp="A01", cwe="CWE-639"),
    StructuralRule("JAVA_XXE", "XML parser without protection against external entities (XXE)", "high", "security", ("java",),
                   "A crafted XML upload can read server files or call internal systems.",
                   'Disable DTDs: factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true).',
                   _check_xxe, owasp="A02", cwe="CWE-611"),
    StructuralRule("DOCKER_NO_USER", "Container runs as root (no USER instruction)", "medium", "security", ("docker",),
                   "If the application is compromised, the attacker has root inside the container.",
                   "Create a non-root user and add a USER instruction before the application starts.",
                   _check_docker_user, owasp="A02", cwe="CWE-250"),
]


# --------------------------------------------------------------------------- analysis
def is_ignored(lines: List[str], line_no: int, rule_id: str) -> bool:
    for n in (line_no, line_no - 1):
        if 1 <= n <= len(lines):
            m = IGNORE_RE.search(lines[n - 1])
            if m:
                ids = m.group(1)
                if not ids or not ids.strip():
                    return True
                if rule_id in {t.strip() for t in re.split(r"[,\s]+", ids) if t.strip()}:
                    return True
    return False


def _finding(rule_id, title, severity, category, message, fix, path, line, evidence,
             owasp="", cwe="", redact=False) -> Dict:
    evidence = evidence.strip()
    if redact:
        evidence = re.sub(r"([:=]\s*).*$", r"\1<REDACTED>", evidence)
    return {"rule_id": rule_id, "title": title, "severity": severity, "category": category,
            "message": message, "fix": fix, "file": path, "line": line, "evidence": evidence[:200],
            "owasp": owasp, "owasp_label": owasp_label(owasp), "cwe": cwe}


def analyze_file(path: str, content: str, added: Set[int], touched: Set[int], rules: List[Rule],
                 disabled: FrozenSet[str] = frozenset()) -> List[Dict]:
    lang = language_of(path)
    if not lang:
        return []
    lines = content.splitlines()
    found: List[Dict] = []
    for rule in rules:
        if rule.id in disabled or not rule.applies(lang, path):
            continue
        for n in sorted(added):
            if 1 <= n <= len(lines) and line_rule_hits(rule, lines[n - 1], lang):
                found.append(_finding(rule.id, rule.title, rule.severity, rule.category,
                                      rule.message, rule.fix, path, n, lines[n - 1],
                                      rule.owasp, rule.cwe, rule.redact))
    for srule in STRUCTURAL_RULES:
        if srule.id in disabled or lang not in srule.langs:
            continue
        try:
            hits = srule.check(content)
        except Exception:                      # a heuristic must never crash the review
            continue
        for first, last, evidence in hits:
            if any(n in touched for n in range(first, last + 1)):
                found.append(_finding(srule.id, srule.title, srule.severity, srule.category,
                                      srule.message, srule.fix, path, first, evidence,
                                      srule.owasp, srule.cwe))
    unique: Dict[Tuple[str, int, str], Dict] = {}
    for f in found:
        if not is_ignored(lines, f["line"], f["rule_id"]):
            unique.setdefault((f["file"], f["line"], f["rule_id"]), f)
    return sorted(unique.values(), key=lambda f: (-SEVERITY_ORDER[f["severity"]], f["file"], f["line"]))


DEPENDENCY_RULES = (
    ("DEP_VULNERABLE_LIBRARY", "Known-vulnerable library in pom.xml (built-in list of severe, verified cases)"),
    ("DEP_NPM_AUDIT", "Vulnerable npm package (read from the output of 'npm audit --json')"),
    ("DEP_CHECK", "Vulnerable dependency (read from an OWASP Dependency-Check JSON report)"),
)
DEPENDENCY_RULE_IDS = tuple(r for r, _t in DEPENDENCY_RULES)


def all_rule_ids(rules: List[Rule]) -> List[str]:
    return [r.id for r in rules] + [s.id for s in STRUCTURAL_RULES] + ["SECRET_SCAN"] + list(DEPENDENCY_RULE_IDS)
