"""Deterministic secret detection and redaction. Costs zero tokens.

Redaction runs BEFORE any code is sent to the model; detection produces findings
without calling the model at all.
"""
import re
from typing import Dict, List, Tuple

# (label, severity, compiled regex with a named group "value" = the secret itself)
SECRET_PATTERNS: List[Tuple[str, str, "re.Pattern"]] = [
    ("AWS access key", "critical", re.compile(r"(?P<value>AKIA[0-9A-Z]{16})")),
    ("private key block", "critical",
     re.compile(r"(?P<value>-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----)")),
    ("API key (sk-...)", "critical", re.compile(r"(?P<value>sk-[A-Za-z0-9_\-]{20,})")),
    ("JWT", "high",
     re.compile(r"(?P<value>eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,})")),
    ("GitHub token", "critical", re.compile(r"(?P<value>\bgh[pousr]_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{40,})")),
    ("Slack token", "critical", re.compile(r"(?P<value>\bxox[baprs]-[A-Za-z0-9-]{10,})")),
    ("Google API key", "high", re.compile(r"(?P<value>\bAIza[0-9A-Za-z_\-]{35}\b)")),
    ("Stripe live key", "critical", re.compile(r"(?P<value>\bsk_live_[A-Za-z0-9]{20,})")),
    ("SendGrid key", "critical", re.compile(r"(?P<value>\bSG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}\b)")),
    ("Azure storage key", "critical", re.compile(r"AccountKey=(?P<value>[A-Za-z0-9+/=]{60,})")),
    ("hardcoded credential", "high",
     re.compile(r"""(?i)[A-Za-z0-9_]*(?:password|passwd|pwd|secret|api[_-]?key|token)[A-Za-z0-9_]*["']?\s*[:=]\s*["'](?P<value>[^"'\s]{8,})["']""")),
]

PLACEHOLDER = "<REDACTED>"


def redact(text: str) -> str:
    """Replace secret values with a placeholder, keeping the rest of the line intact."""
    for _label, _sev, pattern in SECRET_PATTERNS:
        def _sub(match: "re.Match") -> str:
            whole = match.group(0)
            value = match.group("value")
            return whole.replace(value, PLACEHOLDER)
        text = pattern.sub(_sub, text)
    return text


def scan_added_lines(file: str, added: List[Tuple[int, str]]) -> List[Dict]:
    """Return deterministic findings for added lines that look like committed secrets."""
    findings: List[Dict] = []
    for line_no, text in added:
        for label, severity, pattern in SECRET_PATTERNS:
            if pattern.search(text):
                findings.append({
                    "file": file,
                    "line": line_no,
                    "severity": severity,
                    "category": "security",
                    "title": f"Possible committed secret ({label})",
                    "evidence": redact(text).strip()[:200],
                    "scenario": "Anyone with read access to the repository or its history can use this value.",
                    "fix": "Remove it from the code, rotate the secret, and load it from a secret store or pipeline variable.",
                    "confidence": 1.0,
                    "verified": True,
                    "deterministic": True,
                })
                break  # one finding per line is enough
    return findings
