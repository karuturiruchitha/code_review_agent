"""Per-repository settings: a `.codereview.yml` file in the repository root.

Lets each team tune the agent for its own repository (turn rules off, change a rule's severity, skip folders,
point to dependency reports) WITHOUT editing the agent. A malformed file never breaks a review: it produces a
warning and the defaults are used.
"""
import os
from dataclasses import dataclass, field
from typing import Dict, FrozenSet, List, Optional, Tuple

import yaml

from agent.config import SEVERITY_ORDER

SETTINGS_FILES = (".codereview.yml", ".codereview.yaml", "codereview.yml")
KNOWN_KEYS = {"version", "fail_on", "disable", "severity", "exclude_paths", "test_paths", "baseline",
              "dependencies", "inline_comments"}
KNOWN_DEP_KEYS = {"scope", "npm_audit", "npm_audit_manifest", "dependency_check", "dependency_check_manifest"}


@dataclass
class Settings:
    source: Optional[str] = None
    fail_on: Optional[str] = None
    disable: FrozenSet[str] = frozenset()
    severity: Dict[str, str] = field(default_factory=dict)
    exclude_paths: Tuple[str, ...] = ()
    test_paths: Tuple[str, ...] = ()
    baseline: Optional[str] = None
    npm_audit: Optional[str] = None
    npm_audit_manifest: str = "package.json"
    dependency_check: Optional[str] = None
    dependency_check_manifest: str = "pom.xml"
    inline_enabled: bool = False
    inline_min_severity: str = "high"
    inline_max: int = 15
    warnings: List[str] = field(default_factory=list)


def _as_list(value, warnings: List[str], name: str) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list) and all(isinstance(x, str) for x in value):
        return list(value)
    warnings.append(f"settings: '{name}' must be a list of text values; ignored")
    return []


def load_settings(repo_dir: str, explicit_path: Optional[str] = None,
                  known_rule_ids: Optional[FrozenSet[str]] = None) -> Settings:
    settings = Settings()
    path = explicit_path
    if not path:
        for name in SETTINGS_FILES:
            candidate = os.path.join(repo_dir, name)
            if os.path.isfile(candidate):
                path = candidate
                break
    if not path:
        return settings
    settings.source = os.path.relpath(path, repo_dir) if not explicit_path else path
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
    except (OSError, yaml.YAMLError) as exc:
        settings.warnings.append(f"settings: could not read {settings.source}: {str(exc).splitlines()[0] if str(exc) else exc}; "
                                 "defaults used")
        return settings
    if not isinstance(data, dict):
        settings.warnings.append(f"settings: {settings.source} must contain key: value pairs; defaults used")
        return settings

    for key in data:
        if key not in KNOWN_KEYS:
            settings.warnings.append(f"settings: unknown key '{key}' ignored (known: {', '.join(sorted(KNOWN_KEYS))})")

    fail_on = data.get("fail_on")
    if fail_on is not None:
        if str(fail_on) in ("none", *SEVERITY_ORDER):
            settings.fail_on = str(fail_on)
        else:
            settings.warnings.append(f"settings: fail_on '{fail_on}' is not one of none/low/medium/high/critical; ignored")

    disabled = _as_list(data.get("disable"), settings.warnings, "disable")
    sev = data.get("severity") or {}
    if not isinstance(sev, dict):
        settings.warnings.append("settings: 'severity' must be rule: level pairs; ignored")
        sev = {}
    for rule_id, level in sev.items():
        if str(level) not in SEVERITY_ORDER:
            settings.warnings.append(f"settings: severity '{level}' for {rule_id} is not critical/high/medium/low; ignored")
        else:
            settings.severity[str(rule_id)] = str(level)
    if known_rule_ids is not None:
        for rid in list(disabled) + list(settings.severity):
            if rid not in known_rule_ids:
                settings.warnings.append(f"settings: unknown rule id '{rid}' (typo?). See docs/rules.md")
    settings.disable = frozenset(disabled)
    settings.exclude_paths = tuple(_as_list(data.get("exclude_paths"), settings.warnings, "exclude_paths"))
    settings.test_paths = tuple(_as_list(data.get("test_paths"), settings.warnings, "test_paths"))
    if data.get("baseline"):
        settings.baseline = str(data["baseline"])

    deps = data.get("dependencies") or {}
    if isinstance(deps, dict):
        for key in deps:
            if key not in KNOWN_DEP_KEYS:
                settings.warnings.append(f"settings: unknown dependencies key '{key}' ignored")
        settings.npm_audit = deps.get("npm_audit")
        settings.npm_audit_manifest = deps.get("npm_audit_manifest") or settings.npm_audit_manifest
        settings.dependency_check = deps.get("dependency_check")
        settings.dependency_check_manifest = deps.get("dependency_check_manifest") or settings.dependency_check_manifest
    else:
        settings.warnings.append("settings: 'dependencies' must be key: value pairs; ignored")

    inline = data.get("inline_comments") or {}
    if isinstance(inline, dict):
        settings.inline_enabled = bool(inline.get("enabled", False))
        level = str(inline.get("min_severity", "high"))
        if level in SEVERITY_ORDER:
            settings.inline_min_severity = level
        else:
            settings.warnings.append(f"settings: inline_comments.min_severity '{level}' invalid; using high")
        try:
            settings.inline_max = max(0, int(inline.get("max", 15)))
        except (TypeError, ValueError):
            settings.warnings.append("settings: inline_comments.max must be a number; using 15")
    return settings
