"""Decide WHICH lines are reviewed: only the changed ones (pull request) or every line (full scan)."""
import fnmatch
import os
import subprocess
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple

from agent.diff_utils import parse_diff, resolve_target_ref, run_git_diff

MAX_FILE_BYTES = 2_000_000


@dataclass
class FileScan:
    path: str
    added: Optional[Dict[int, str]]      # line number -> text of ADDED lines;  None = the whole file
    touched: Optional[Set[int]]          # lines changed or next to a deletion;  None = the whole file


def read_text(repo_dir: str, rel: str) -> Optional[str]:
    """Read a text file. Returns None for missing, oversized or binary files."""
    path = os.path.join(repo_dir, rel)
    try:
        if os.path.getsize(path) > MAX_FILE_BYTES:
            return None
        with open(path, "rb") as fh:
            raw = fh.read()
    except OSError:
        return None
    if b"\x00" in raw[:4096]:
        return None
    return raw.decode("utf-8", errors="replace")


def is_skipped(path: str, patterns) -> bool:
    return any(fnmatch.fnmatch(path, pat) or fnmatch.fnmatch("/" + path, pat) for pat in patterns)


def scan_pull_request(repo_dir: str, target_branch: str) -> Tuple[List[FileScan], Set[str]]:
    """Changed lines of the PR. Also returns EVERY changed path (even skipped ones), used to decide on dependency reports."""
    hunks = parse_diff(run_git_diff(repo_dir, resolve_target_ref(repo_dir, target_branch)))
    per_file: Dict[str, FileScan] = {}
    for h in hunks:
        entry = per_file.setdefault(h.file, FileScan(h.file, {}, set()))
        for n, text in h.added:
            entry.added[n] = text
            entry.touched.add(n)
    for h in hunks:
        entry = per_file[h.file]
        # A PURE deletion at new-file line k (nothing was added in its place) used to sit right after line k-1, so
        # line k-1 counts as touched. This is how "someone removed the WHERE line" is detected even though nothing
        # was added. A line that was merely REPLACED is already in `added`, so its neighbours are left alone.
        added_here = {n for n, _t in h.added}
        entry.touched.update(n - 1 for n in h.removed_at if n > 1 and n not in added_here)
    return list(per_file.values()), set(per_file)


def list_repository_files(repo_dir: str) -> List[str]:
    """All tracked files (git), or every file under the folder if it is not a git repository."""
    result = subprocess.run(["git", "-C", repo_dir, "ls-files", "-z"], capture_output=True)
    if result.returncode == 0:
        return [p for p in result.stdout.decode("utf-8", errors="replace").split("\0") if p]
    found = []
    for root, dirs, files in os.walk(repo_dir):
        dirs[:] = [d for d in dirs if d != ".git"]
        for name in files:
            found.append(os.path.relpath(os.path.join(root, name), repo_dir).replace(os.sep, "/"))
    return sorted(found)


def scan_all_files(repo_dir: str) -> Tuple[List[FileScan], Set[str]]:
    paths = list_repository_files(repo_dir)
    return [FileScan(p, None, None) for p in paths], set(paths)
