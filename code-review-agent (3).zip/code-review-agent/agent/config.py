"""Configuration for the rule-based code review agent. Every value can be overridden with an
environment variable. No AI, no API keys, no tokens."""
import os
import re
from dataclasses import dataclass
from typing import Tuple

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SEVERITY_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1}
TEST_PATH_RE = re.compile(r"(^|/)(src/test|tests?|__tests__)/|Tests?\.java$|IT\.java$|\.(test|spec)\.[jt]sx?$")

DEFAULT_SKIP_PATTERNS = ",".join([
    "*.min.js", "*.min.css", "*package-lock.json", "*yarn.lock", "*pnpm-lock.yaml",
    "*/node_modules/*", "*/dist/*", "*/build/*", "*/target/*", "*/.git/*",
    "*generated*", "*.snap", "*.map",
    "*/vendor/*", "*/third_party/*", "*/webjars/*", "*-[0-9]*.[0-9]*.js",   # vendored libraries
])


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Config:
    skip_drafts: bool
    output_dir: str
    skip_patterns: Tuple[str, ...]


def load_config() -> Config:
    raw = os.getenv("REVIEW_SKIP_PATTERNS", DEFAULT_SKIP_PATTERNS)
    return Config(
        skip_drafts=_bool("SKIP_DRAFT_PRS", True),
        output_dir=os.getenv("OUTPUT_DIR", "review_output"),
        skip_patterns=tuple(p.strip() for p in raw.split(",") if p.strip()),
    )
