"""Azure DevOps REST helpers: read the PR, post ONE review comment and update it on re-runs."""
import os
import re
from typing import Dict, Optional
from urllib.parse import quote

import requests

API_VERSION = "7.1"
MARKER = "<!-- ai-code-review-agent"
INLINE_MARKER = "<!-- rule-review-inline"


class AzureDevOps:
    REQUIRED_ENV = ("SYSTEM_COLLECTIONURI", "SYSTEM_TEAMPROJECT", "BUILD_REPOSITORY_ID",
                    "SYSTEM_PULLREQUEST_PULLREQUESTID", "SYSTEM_ACCESSTOKEN")

    def __init__(self, env=None, session=None, marker: str = MARKER) -> None:
        self.marker = marker
        env = env if env is not None else os.environ
        self.base = env["SYSTEM_COLLECTIONURI"].rstrip("/") + "/" + quote(env["SYSTEM_TEAMPROJECT"])
        self.repo_id = env["BUILD_REPOSITORY_ID"]
        self.pr_id = env["SYSTEM_PULLREQUEST_PULLREQUESTID"]
        self.token = env["SYSTEM_ACCESSTOKEN"]
        self.session = session or requests.Session()

    @classmethod
    def available(cls, env=None) -> bool:
        env = env if env is not None else os.environ
        return all(env.get(k) for k in cls.REQUIRED_ENV)

    def _request(self, method: str, suffix: str, json_body=None) -> Dict:
        url = f"{self.base}/_apis/git/repositories/{self.repo_id}/pullRequests/{self.pr_id}{suffix}"
        response = self.session.request(
            method, url, params={"api-version": API_VERSION}, json=json_body,
            headers={"Authorization": f"Bearer {self.token}"}, timeout=30)
        response.raise_for_status()
        return response.json() if response.content else {}

    def get_pr(self) -> Dict:
        return self._request("GET", "")

    def current_source_commit(self) -> Optional[str]:
        return (self.get_pr().get("lastMergeSourceCommit") or {}).get("commitId")

    def find_comment(self) -> Optional[Dict]:
        """Find the comment this agent posted earlier on the PR (identified by the hidden marker)."""
        for thread in self._request("GET", "/threads").get("value", []):
            for comment in thread.get("comments", []):
                if (comment.get("content") or "").lstrip().startswith(self.marker):
                    return {"thread_id": thread["id"], "comment_id": comment["id"],
                            "content": comment.get("content", "")}
        return None

    def upsert_comment(self, content: str) -> None:
        """Update our existing comment if there is one; otherwise create a new thread.
        Re-runs and parallel runs on the same PR therefore never pile up duplicate comments."""
        existing = self.find_comment()
        if existing:
            self._request("PATCH", f"/threads/{existing['thread_id']}/comments/{existing['comment_id']}",
                          {"content": content})
        else:
            self._request("POST", "/threads", {
                "comments": [{"parentCommentId": 0, "content": content, "commentType": 1}],
                "status": 1,
            })

    # ------------------------------------------------------------------ inline (line-level) comments, opt-in
    def inline_fingerprints(self) -> set:
        """Fingerprints of the inline comments this agent already posted (so a re-run never duplicates them)."""
        found = set()
        for thread in self._request("GET", "/threads").get("value", []):
            for comment in thread.get("comments", []):
                m = re.match(r"\s*" + re.escape(INLINE_MARKER) + r" fp=([0-9a-f]+-\d+) -->", comment.get("content") or "")
                if m:
                    found.add(m.group(1))
        return found

    def create_inline_thread(self, file_path: str, line: int, content: str) -> None:
        body = {"comments": [{"parentCommentId": 0, "content": content, "commentType": 1}], "status": 1,
                "threadContext": {"filePath": "/" + file_path.lstrip("/"),
                                  "rightFileStart": {"line": line, "offset": 1},
                                  "rightFileEnd": {"line": line, "offset": 2}}}
        self._request("POST", "/threads", body)
