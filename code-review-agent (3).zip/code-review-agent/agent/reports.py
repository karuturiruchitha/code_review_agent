"""All output formats: PR comment, full-scan summary (Markdown), self-contained HTML, SARIF 2.1.0, JSON.

Deterministic: no timestamps, so the same findings always produce the same text.
"""
import html
import json
from collections import Counter
from typing import Dict, List

from agent.config import SEVERITY_ORDER

RULE_MARKER = "<!-- rule-review-agent"
ICONS = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵"}
MAX_SHOWN = 40
SEVERITIES = ("critical", "high", "medium", "low")
SARIF_LEVEL = {"critical": "error", "high": "error", "medium": "warning", "low": "note"}
SARIF_SECURITY_SEVERITY = {"critical": "9.5", "high": "8.0", "medium": "5.5", "low": "3.0"}


def severity_counts(findings: List[Dict]) -> Dict[str, int]:
    c = Counter(f["severity"] for f in findings)
    return {s: c.get(s, 0) for s in SEVERITIES}


def _summary_text(findings: List[Dict]) -> str:
    return ", ".join(f"{n} {s}" for s, n in severity_counts(findings).items() if n) or "none"


def _owasp_counts(findings: List[Dict]) -> Dict[str, int]:
    return dict(sorted(Counter(f["owasp_label"] for f in findings if f.get("owasp_label")).items()))


def _finding_block(f: Dict) -> List[str]:
    tags = [f["category"]] + [t for t in (f.get("owasp_label"), f.get("cwe")) if t]
    evidence = f["evidence"].replace("`", "'")
    return [f"### {ICONS[f['severity']]} {f['severity'].upper()} · `{f['rule_id']}`: {f['title']}",
            f"`{f['file']}:{f['line']}` · " + " · ".join(tags),
            f"- **Code:** `{evidence}`",
            f"- **Why it matters:** {f['message']}",
            f"- **Fix:** {f['fix']}", ""]


def _notes(ctx: Dict) -> List[str]:
    notes = []
    if ctx.get("baseline_suppressed"):
        notes.append(f"{ctx['baseline_suppressed']} existing finding(s) are accepted in the baseline and not shown.")
    for w in ctx.get("warnings", []):
        notes.append(f"⚠️ {w}")
    return notes


# ------------------------------------------------------------------------------------------ PR comment
def render_pr_comment(findings: List[Dict], ctx: Dict) -> str:
    sha = f" sha={ctx['source_sha']}" if ctx.get("source_sha") else ""
    fail_on = ctx.get("fail_on", "none")
    mode = f"blocking on {fail_on}+" if fail_on != "none" else "advisory"
    head = "✅" if not findings else "⚠️"
    lines = [f"{RULE_MARKER}{sha} -->",
             f"## {head} Code review: {len(findings)} finding(s) ({_summary_text(findings)}) · {mode}", "",
             f"Checked {ctx.get('files_checked', 0)} changed file(s) against {ctx.get('rule_count', 0)} fixed rules "
             "(security rules mapped to OWASP Top 10:2025). No AI, no tokens: the same code always gives the same result.", ""]
    owasp = _owasp_counts(findings)
    if owasp:
        lines += ["**OWASP Top 10:2025:** " + ", ".join(f"{k} ×{v}" for k, v in owasp.items()), ""]
    for note in _notes(ctx):
        lines += [note, ""]
    if not findings:
        lines.append("No rule violations in the changed lines. "
                     "(This only means none of the fixed patterns matched; it is not a full review.)")
    for f in findings[:MAX_SHOWN]:
        lines += _finding_block(f)
    if len(findings) > MAX_SHOWN:
        lines.append(f"…and {len(findings) - MAX_SHOWN} more (see the pipeline artifact).")
    lines += ["---", "_Pattern checks find known bad patterns, not logic errors. To suppress a false alarm, add "
              "`// review-ignore: RULE_ID reason` (or `-- ` / `# `) on the line or the line above._"]
    return "\n".join(lines)


# ------------------------------------------------------------------------------------------ full scan (Markdown)
def render_full_markdown(findings: List[Dict], ctx: Dict) -> str:
    sc = ctx.get("score")
    counts = severity_counts(findings)
    lines = ["# Code review: full repository scan", "",
             f"Scanned {ctx.get('files_checked', 0)} file(s) with {ctx.get('rule_count', 0)} fixed rules. "
             "No AI, no tokens. Findings: **" + str(len(findings)) + f"** ({_summary_text(findings)}).", ""]
    if sc:
        lines += [f"**Score: {sc['score']}/100, grade {sc['grade']}**  ", f"_{sc['formula']}_", ""]
    for note in _notes(ctx):
        lines += [note, ""]
    lines += ["| Severity | Findings |", "|---|---|"] + [f"| {s} | {n} |" for s, n in counts.items()]
    owasp = _owasp_counts(findings)
    if owasp:
        lines += ["", "## OWASP Top 10:2025", "", "| Category | Findings |", "|---|---|"] + [f"| {k} | {v} |" for k, v in owasp.items()]
    by_rule = Counter(f["rule_id"] for f in findings).most_common(15)
    if by_rule:
        titles = {f["rule_id"]: f["title"] for f in findings}
        lines += ["", "## Most frequent rules", "", "| Rule | Findings | What |", "|---|---|---|"] + \
                 [f"| `{r}` | {n} | {titles[r]} |" for r, n in by_rule]
    by_file = Counter(f["file"] for f in findings if f["severity"] in ("critical", "high")).most_common(10)
    if by_file:
        lines += ["", "## Files with the most critical and high findings", "", "| File | Critical + high |", "|---|---|"] + \
                 [f"| `{p}` | {n} |" for p, n in by_file]
    top = [f for f in findings if f["severity"] in ("critical", "high")][:MAX_SHOWN]
    if top:
        lines += ["", "## Critical and high findings", ""]
        for f in top:
            lines += _finding_block(f)
    lines += ["", "_The full list is in the HTML, JSON and SARIF reports._"]
    return "\n".join(lines)


# ------------------------------------------------------------------------------------------ HTML (self-contained)
_CSS = """body{font:14px/1.5 system-ui,Segoe UI,Arial,sans-serif;margin:0;background:#f5f7fb;color:#1c2b4a}
header{background:#0d2260;color:#fff;padding:20px 32px}h1{margin:0;font-size:22px}main{max-width:1100px;margin:0 auto;padding:24px}
.cards{display:flex;gap:12px;flex-wrap:wrap;margin:0 0 20px}.card{background:#fff;border-radius:8px;padding:12px 18px;min-width:110px;box-shadow:0 1px 3px #0002}
.card b{display:block;font-size:24px}.critical{color:#c0392b}.high{color:#c47a00}.medium{color:#1a4fa8}.low{color:#00897b}
table{border-collapse:collapse;background:#fff;margin:8px 0 20px}td,th{border:1px solid #dde3f0;padding:6px 12px;text-align:left}
details{background:#fff;border-radius:8px;margin:8px 0;box-shadow:0 1px 3px #0002}summary{cursor:pointer;padding:10px 14px;font-weight:600}
.f{border-top:1px solid #e6ebf5;padding:10px 14px}.sev{font-weight:700;text-transform:uppercase;font-size:12px}
code{background:#eef2fb;padding:1px 5px;border-radius:4px}button{margin-right:6px;padding:5px 12px;border:1px solid #9fb0d4;background:#fff;border-radius:16px;cursor:pointer}
button.on{background:#0d2260;color:#fff}.note{background:#fff7e0;border:1px solid #f0d58a;border-radius:6px;padding:8px 12px;margin:8px 0}"""
_JS = """var on={critical:1,high:1,medium:1,low:1};
function t(s,b){on[s]=!on[s];b.classList.toggle('on',!!on[s]);
 document.querySelectorAll('.f').forEach(function(e){e.style.display=on[e.dataset.sev]?'':'none';});}"""


def render_html(findings: List[Dict], ctx: Dict) -> str:
    e = html.escape
    counts = severity_counts(findings)
    sc = ctx.get("score")
    parts = ["<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>Code review report</title>",
             f"<style>{_CSS}</style></head><body><header><h1>Code review report</h1>",
             f"<div>{e(str(ctx.get('mode_label', 'Scan')))} · {ctx.get('files_checked', 0)} files · "
             f"{ctx.get('rule_count', 0)} fixed rules · no AI, no tokens</div></header><main>"]
    parts.append("<div class=\"cards\">")
    if sc:
        parts.append(f"<div class=\"card\"><b>{sc['grade']}</b>score {sc['score']}/100</div>")
    parts.append(f"<div class=\"card\"><b>{len(findings)}</b>findings</div>")
    parts += [f"<div class=\"card\"><b class=\"{s}\">{n}</b>{s}</div>" for s, n in counts.items()]
    parts.append("</div>")
    if sc:
        parts.append(f"<p><small>{e(sc['formula'])}</small></p>")
    for note in _notes(ctx):
        parts.append(f"<div class=\"note\">{e(note)}</div>")
    owasp = _owasp_counts(findings)
    if owasp:
        parts.append("<h2>OWASP Top 10:2025</h2><table><tr><th>Category</th><th>Findings</th></tr>" +
                     "".join(f"<tr><td>{e(k)}</td><td>{v}</td></tr>" for k, v in owasp.items()) + "</table>")
    parts.append("<h2>Findings by file</h2><p>" + "".join(
        f"<button class=\"on {s}\" onclick=\"t('{s}',this)\">{s}</button>" for s in SEVERITIES) + "</p>")
    by_file: Dict[str, List[Dict]] = {}
    for f in findings:
        by_file.setdefault(f["file"], []).append(f)
    for path, items in sorted(by_file.items(), key=lambda kv: (-max(SEVERITY_ORDER[i["severity"]] for i in kv[1]), kv[0])):
        parts.append(f"<details><summary>{e(path)} ({len(items)})</summary>")
        for f in items:
            tags = " · ".join(e(str(t)) for t in [f["category"], f.get("owasp_label"), f.get("cwe")] if t)
            parts.append(
                f"<div class=\"f\" data-sev=\"{f['severity']}\"><span class=\"sev {f['severity']}\">{f['severity']}</span> "
                f"<code>{e(f['rule_id'])}</code> {e(f['title'])} <small>(line {f['line']})</small><br><small>{tags}</small>"
                f"<br><code>{e(f['evidence'])}</code><br><b>Why:</b> {e(f['message'])}<br><b>Fix:</b> {e(f['fix'])}</div>")
        parts.append("</details>")
    if not findings:
        parts.append("<p>No findings.</p>")
    parts.append(f"</main><script>{_JS}</script></body></html>")
    return "".join(parts)


# ------------------------------------------------------------------------------------------ SARIF 2.1.0
def to_sarif(findings: List[Dict], ctx: Dict) -> Dict:
    rules, index = [], {}
    for f in findings:
        if f["rule_id"] in index:
            continue
        index[f["rule_id"]] = len(rules)
        tags = [t for t in (f["category"], ("OWASP " + f["owasp_label"]) if f.get("owasp_label") else None, f.get("cwe")) if t]
        rules.append({"id": f["rule_id"], "name": f["rule_id"], "shortDescription": {"text": f["title"]},
                      "fullDescription": {"text": f["message"]}, "help": {"text": f["fix"]},
                      "defaultConfiguration": {"level": SARIF_LEVEL[f["severity"]]},
                      "properties": {"tags": tags, "security-severity": SARIF_SECURITY_SEVERITY[f["severity"]]}})
    results = []
    for f in findings:
        result = {"ruleId": f["rule_id"], "ruleIndex": index[f["rule_id"]], "level": SARIF_LEVEL[f["severity"]],
                  "message": {"text": f"{f['title']}. {f['message']} Fix: {f['fix']}"},
                  "locations": [{"physicalLocation": {"artifactLocation": {"uri": f["file"], "uriBaseId": "%SRCROOT%"},
                                                      "region": {"startLine": max(1, int(f["line"]))}}}]}
        if f.get("fingerprint"):
            result["partialFingerprints"] = {"codeReviewAgent/v1": f["fingerprint"]}
        results.append(result)
    return {"$schema": "https://json.schemastore.org/sarif-2.1.0.json", "version": "2.1.0",
            "runs": [{"tool": {"driver": {"name": "code-review-agent", "rules": rules}}, "results": results}]}


# ------------------------------------------------------------------------------------------ JSON
def to_json(findings: List[Dict], ctx: Dict) -> str:
    payload = {"mode": ctx.get("mode"), "files_checked": ctx.get("files_checked", 0), "rules": ctx.get("rule_count", 0),
               "source_sha": ctx.get("source_sha"), "summary": severity_counts(findings),
               "owasp": _owasp_counts(findings), "score": ctx.get("score"),
               "baseline_suppressed": ctx.get("baseline_suppressed", 0), "warnings": ctx.get("warnings", []),
               "findings": findings}
    return json.dumps(payload, indent=2, ensure_ascii=False)
